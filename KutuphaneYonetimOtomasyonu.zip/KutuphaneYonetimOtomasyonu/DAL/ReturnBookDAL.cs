﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;  // Veri tabanı bağlantısı için gerekli kütüphaneyi ekledik.
using System.Data;       // Veri tabanı bağlantısı için gerekli kütüphaneyi ekledik.
using ENTITY;           // Entity katmanını kullandık.

namespace DAL
{
    public class ReturnBookDAL
    {
        public static List<BookStudentData> bookStudentList(BookStudentData book)
        {
            OleDbCommand command = new OleDbCommand("Select k.bookID,o.studentName,o.studentLastN,k.bookName,kk.purchaseBook,kk.deliverBook,kk.checkBook from ((tbl_Book k inner join tbl_RecordBook kk on k.bookID=kk.bookID) inner join tbl_Student o on o.studentID=kk.studentID) where k.bookID = @bookID", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@bookID", book.BookID);
            OleDbDataReader drreader = command.ExecuteReader();
            List<BookStudentData> bookStudent = new List<BookStudentData>();

            while (drreader.Read())
            {
                bookStudent.Add(new BookStudentData
                {
                    BookID = int.Parse(drreader["bookID"].ToString()),
                    StudentName = drreader["studentName"].ToString(),
                    StudentLastN = drreader["studentLastN"].ToString(),
                    BookName = drreader["bookName"].ToString(),
                    PurchaseBook = DateTime.Parse(drreader["purchaseBook"].ToString()),
                    DeliverBook = drreader["deliverBook"].ToString(),
                    CheckBook = bool.Parse(drreader["checkBook"].ToString())
                });
            }

            return bookStudent;
        }

        //Ogrencinin almış olduğu kitaplar tarihsel olarak listelendi. Yine inner join yöntemi ile veriler çekildi
        public static List<TakingBookData> studentIDList(TakingBookData book)
        {
            OleDbCommand command = new OleDbCommand("Select o.studentID,k.bookName,kk.purchaseBook,kk.deliverBook,kk.checkBook from ((tbl_Book k inner join tbl_RecordBook kk on k.bookID=kk.bookID) inner join tbl_Student o on o.studentID=kk.studentID) where o.studentID = @id", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@id", book.StudentID);
            OleDbDataReader read = command.ExecuteReader();
            List<TakingBookData> bookStudent = new List<TakingBookData>();
            while (read.Read())
            {
                bookStudent.Add(new TakingBookData
                {
                    StudentID = int.Parse(read["studentID"].ToString()),
                    BookName = read["bookName"].ToString(),
                    PurchaseBook = DateTime.Parse(read["purchaseBook"].ToString()),
                    DeliverBook = read["deliverBook"].ToString(),
                    CheckBook = bool.Parse(read["checkBook"].ToString())
                });
            }

            return bookStudent;
        }

        //Alinabilir durumdaki kitapların teslim edilme durumlarına göre listeleme işlemi gerçekleştirildi
        public static List<string> purchaseBookList(ReturnBookData book)
        {
            OleDbCommand command = new OleDbCommand("Select bookName from tbl_Book where bookID not in(select bookID from tbl_RecordBook where studentID=@id and checkBook=false)", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@id", book.StudentID);
            OleDbDataReader read = command.ExecuteReader();

            List<string> purchaseList = new List<string>();

            while (read.Read())
            {
                purchaseList.Add(read["bookName"].ToString());
            }

            return purchaseList;
        }

        //Teslim edilmesi gereken kitaplar teslim edilmeme durumuna göre listeye aktarıldı
        public static List<string> deliverBookList(ReturnBookData book)
        {
            OleDbCommand command = new OleDbCommand("Select bookName from tbl_Book where bookID in(select bookID from tbl_RecordBook where studentID=@id and checkBook=false)", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@id", book.StudentID);
            OleDbDataReader read = command.ExecuteReader();

            List<string> deliverList = new List<string>();

            while (read.Read())
            {
                deliverList.Add(read["bookName"].ToString());
            }

            return deliverList;
        }

        //Veritabanından öğrenciye ait ceza bilgisi listeye aktarıldı
        public static List<string> suspendenStudent(ReturnBookData book)
        {
            OleDbCommand command = new OleDbCommand("Select o.studentPunishment from ((tbl_Book k inner join tbl_RecordBook kk on k.bookID=kk.bookID) inner join tbl_Student o on o.studentID=kk.studentID) where o.studentID = @id", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@id", book.StudentID);
            OleDbDataReader read = command.ExecuteReader();

            List<string> punishmentList = new List<string>();

            while (read.Read())
            {
                book.StudentPunshmnt = float.Parse(read["studentPunishment"].ToString());
            }

            return punishmentList;
        }

        //Ceza işlemi gerçekleştirildikten sonra ogrenciye ait ceza verisinde guncelleme yapıldı
        public static int studentPunishmentProcess(ReturnBookData student)
        {
            OleDbCommand command = new OleDbCommand("Update tbl_Student set studentPunishment=@pnshmnt where studentID=@id", DbCon.con);
            DbCon.Connection(command);

            command.Parameters.AddWithValue("@pnshmnt", student.StudentPunshmnt);
            command.Parameters.AddWithValue("@id", student.StudentID);

            return command.ExecuteNonQuery();
        }

        //Kitap adı sorgusu ile ada ait kitapId verisi int döndürüldü
        public static int bookNID(BookStudentData book)
        {
            OleDbCommand command = new OleDbCommand("Select bookID from tbl_Book where bookName=@name", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@name", book.BookName);
            OleDbDataReader read = command.ExecuteReader();

            int id = 0;

            while (read.Read())
            {

                id = int.Parse(read["bookID"].ToString());
            }

            return id;
        }

        //Kitap alındğında veri tabanına veriler eklendi
        public static int purchaseBookProcess(ReturnBookData book)
        {
            OleDbCommand command = new OleDbCommand("insert into tbl_RecordBook(bookID,studentID,purchaseBook) values(@book,student,@purchase)", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@book", book.BookID);
            command.Parameters.AddWithValue("@student", book.StudentID);
            command.Parameters.AddWithValue("@purchase", book.PurchaseBook);
            return command.ExecuteNonQuery();
        }

        //Kitap teslim edildiğinde veriler güncellendi
        public static int deliverBookProcess(ReturnBookData book)
        {
            OleDbCommand command = new OleDbCommand("Update tbl_RecordBook set deliverBook=@deliver,checkBook=@check where bookID=@book and studentID=@student", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@deliver", book.DeliverBook);
            command.Parameters.AddWithValue("@check", book.CheckBook);
            command.Parameters.AddWithValue("@book", book.BookID);
            command.Parameters.AddWithValue("@student", book.StudentID);
            return command.ExecuteNonQuery();
        }

        // Alınma tarihini kitapkayıt tablosundan çekip listeye aktardık
        public static List<string> datePurchaseBook(ReturnBookData book)
        {
            OleDbCommand command = new OleDbCommand("Select purchaseBook from tbl_RecordBook where bookID=@book and studentID=@student", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@book", book.BookID);
            command.Parameters.AddWithValue("@student", book.StudentID);
            OleDbDataReader read = command.ExecuteReader();

            List<string> DPList= new List<string>();

            while (read.Read())
            {
                book.PurchaseBook = DateTime.Parse(read["purchaseBook"].ToString());
            }

            return DPList;
        }

        //Öğrenciye verilmiş kitapların sayısı int olarak döndürüldü
        public static int givenGraphics(ReturnBookData book)
        {
            OleDbCommand command = new OleDbCommand("Select bookName from tbl_Book where bookID in(select bookID from tbl_RecordBook where studentID=@student and checkBook=false)", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@student", book.StudentID);
            OleDbDataReader read = command.ExecuteReader();
            int timer = 0;
            while (read.Read())
            {
                timer++;
            }

            return timer;
        }
                
        //Alınabilir kitapların sayısı int olarak döndürüldü
        public static int purchasableGraphics(ReturnBookData book)
        {
            OleDbCommand command = new OleDbCommand("Select bookName from tbl_Book where bookID not in(select bookID from tbl_RecordBook where studentID=@student and checkBook=false)", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@student", book.StudentID);
            OleDbDataReader read = command.ExecuteReader();
            int timer = 0;
            while (read.Read())
            {
                timer++;
            }

            return timer;
        }

        //Tüm kitapların sayısı int olarak döndürüldü
        public static int allGraphics()
        {
            OleDbCommand command = new OleDbCommand("Select * from tbl_Book", DbCon.con);
            DbCon.Connection(command);
            OleDbDataReader read = command.ExecuteReader();
            int timer = 0;
            while (read.Read())
            {
                timer++;
            }

            return timer;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;  // Veri tabanı bağlantısı için gerekli kütüphaneyi ekledik.
using System.Data;       // Veri tabanı bağlantısı için gerekli kütüphaneyi ekledik.
using ENTITY;           // Entity katmanını kullandık.

namespace DAL
{  
    public class AdminDAL
    {
        //Personelin sistemde kayıtlı olma durumu kontrol edildi
        public static bool checkAdmin(AdminData admin)
        {
            OleDbCommand command = new OleDbCommand("Select * from tbl_Admin where adminIdeN=@admIdeN and adminPass=@admPass", DbCon.con);  // Personelin kontrol edildiği veritabanı sorgusu.
            DbCon.Connection(command);  // command nesnesi için boş bir koleksiyon oluşturduk ve aşağıdaki @ değişkenleri ile koleksiyonu doldurduk.
            command.Parameters.AddWithValue("@admIdeN", admin.admIdeNu);    //@adminIdeN ile parametreyi ekle.
            command.Parameters.AddWithValue("@admPass", admin.admPass);     //@adminPass ile parametreyi ekle.

            OleDbDataReader drreader = command.ExecuteReader();                // Koleksiyona eklediğimiz kodların okunma işlemine soktuk.
            bool total = false;                                             // total değişkenini tanıttık.
            int timer = 0;                                                  // timer değişkenini tanıttık

            while (drreader.Read())     //DataReader okudukça işlemi devam ettir;
            {
                timer++;        // sayacı attırarak tüm koleksiyonu okumasını sağladık.
            }

            if (timer > 0)
            {
                total = true;   // sayaç 0 dan büyükse veri var demektir.
            }

            return total;   // olan veriyi döndürdük.
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;  // Veri tabanı bağlantısı için gerekli kütüphaneyi ekledik.
using System.Data;       // Veri tabanı bağlantısı için gerekli kütüphaneyi ekledik.
using ENTITY;           // Entity katmanını kullandık.

namespace DAL
{
    public class StudentDAL
    {
        
        // Öğrenciye ait tüm bilgilerin listelenmesi gerçekleştirildi
        public static List<StudentData> studentList()
        {
            OleDbCommand command = new OleDbCommand("Select * from tbl_Student", DbCon.con);
            DbCon.Connection(command);
            OleDbDataReader read = command.ExecuteReader();
            List<StudentData> student = new List<StudentData>();

            while (read.Read())
            {
                student.Add(new StudentData
                {
                    StudentID = int.Parse(read["studentID"].ToString()),
                    StudentName = read["studentName"].ToString(),
                    StudentLastN = read["studentLastN"].ToString(),
                    StudentNu = read["studentNu"].ToString(),
                    StudentPass = read["studentPass"].ToString(),
                    StudentSex = read["studentSex"].ToString(),
                    StudentSusp = float.Parse(read["studentPunishment"].ToString())
                });
            }

            return student;
        }

        //Yeni eklenecek öğrenci ile veri tabanındaki herhangi bir öğrencinin numraları çakışmaması için kontrol edildi
        public static bool checkStudentNu(StudentData student)
        {
            OleDbCommand command = new OleDbCommand("Select count(studentNu) FROM tbl_Student Where studentNu=@no", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@no", student.StudentNu);
            int count = Convert.ToInt32(command.ExecuteScalar());

            if (count > 0)
            {
                return false;
            }
            return true;

        }
                
        //Öğrenci id ile veritabanında kayıtlı olma durumu kontrol edildi
        public static bool queryStudent(StudentData student)
        {
            OleDbCommand command = new OleDbCommand("Select * from tbl_Student where studentID=@id", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@id", student.StudentID);

            OleDbDataReader drreader = command.ExecuteReader();
            bool total = false;
            int timer = 0;

            while (drreader.Read())
            {
                timer++;
            }

            if (timer > 0)
            {
                total = true;
            }

            return total;
        }

        // Öğrenci tablosuna girilen öğrenci bilgileri eklendi
        public static int addStudent(StudentData student)
        {
            OleDbCommand command = new OleDbCommand("insert into tbl_Student(studentName,studentLastN,studentNu,studentPass,studentSex) values(@name,@lastn,@no,@pass,@sex)", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@name", student.StudentName);
            command.Parameters.AddWithValue("@lastn", student.StudentLastN);
            command.Parameters.AddWithValue("@no", student.StudentNu);
            command.Parameters.AddWithValue("@pass", student.StudentPass);
            command.Parameters.AddWithValue("@sex", student.StudentSex);

            return command.ExecuteNonQuery();
        }

        // İd ye ait öğrenci , Ogrenci tablosundan silindi
        public static int deleteStudent(StudentData student)
        {
            OleDbCommand command = new OleDbCommand("Delete from tbl_Student where studentID=@id ", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@id", student.StudentID);

            return command.ExecuteNonQuery();
        }

        // Ogrenci Id ye ait bilgilerin güncellenme işlemi gerçekleştirildi
        public static int updateStudent(StudentData student)
        {
            OleDbCommand command = new OleDbCommand("Update tbl_Student set studentName=@name,studentLastN=@lastn,studentNu=@no,studentPass=@pass,studentSex=@sex where studentID=@id", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@name", student.StudentName);
            command.Parameters.AddWithValue("@lastn", student.StudentLastN);
            command.Parameters.AddWithValue("@no", student.StudentNu);
            command.Parameters.AddWithValue("@pass", student.StudentPass);
            command.Parameters.AddWithValue("@sex", student.StudentSex);
            command.Parameters.AddWithValue("@id", student.StudentID);

            return command.ExecuteNonQuery();
        }

        //Öğrencinin tabloda kayıtlı olma durumu kontrol edildi
        public static bool checkStudent(StudentData student)
        {
            OleDbCommand command = new OleDbCommand("Select * from tbl_Student where studentNu=@no and studentPass=@pass", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@no", student.StudentNu);
            command.Parameters.AddWithValue("@pass", student.StudentPass);

            OleDbDataReader read = command.ExecuteReader();
            bool total = false;
            int timer = 0;

            while (read.Read())
            {
                timer++;
            }

            if (timer > 0)
            {
                total = true;
            }

            return total;
        }

        //Ogrenci no ve şifreye ait id çekildi ve int döndürüldü
        public static int studentQueryID(StudentData student)
        {
            OleDbCommand command = new OleDbCommand("Select studentID from tbl_Student where studentNu=@no and studentPass=@pass", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@no", student.StudentNu);
            command.Parameters.AddWithValue("@pass", student.StudentPass);

            OleDbDataReader read = command.ExecuteReader();

            int id = 0;

            while (read.Read())
            {
                id = int.Parse(read["studentID"].ToString());
            }
            return id;
        }


        //Ogrenci id ye ait tüm bilgiler Ogrenci tablosundan çekildi
        public static StudentData studentInfoID(StudentData student)
        {
            OleDbCommand command = new OleDbCommand("Select * from tbl_Student where studentID = @id", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@id", student.StudentID);
            OleDbDataReader read = command.ExecuteReader();

            while (read.Read())
            {
                student.StudentName= read["studentName"].ToString();
                student.StudentLastN = read["studentLastN"].ToString();
                student.StudentNu= read["studentNu"].ToString();
                student.StudentPass = read["studentPass"].ToString();
                student.StudentSex = read["studentSex"].ToString();
                student.StudentSusp = float.Parse(read["studentPunishment"].ToString());
            }

            return student;
        }

    }
}

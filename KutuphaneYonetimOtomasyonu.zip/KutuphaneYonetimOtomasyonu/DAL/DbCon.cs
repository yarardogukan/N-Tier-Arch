﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Data.OleDb;  // gerekli kütüphane eklendi
using System.Data;       // gerekli kütüphane eklendi

namespace DAL
{
    class DbCon
    {
        //Veritabanı ile bağlantı işlemi gerçekleştirildi.

        public static OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\db_Kutuphane.mdb"); // Veritabanı yolu belirtildi.

        //Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\90541\source\repos\KutuphaneYonetimOtomasyonu\KutuphaneYonetimOtomasyonu\bin\Debug\
        public static void Connection(OleDbCommand command)
        {

            if (command.Connection.State != ConnectionState.Open)
            {
                command.Connection.Open();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;  // Veri tabanı bağlantısı için gerekli kütüphaneyi ekledik.
using System.Data;       // Veri tabanı bağlantısı için gerekli kütüphaneyi ekledik.
using ENTITY;           // Entity katmanını kullandık.

namespace DAL
{
    public class BookDAL
    {
        //Veri tabanındaki Kitap tablosundaki veriler listelendi
        public static List<BookData> bookList()
        {
            OleDbCommand command = new OleDbCommand("Select * from tbl_Book", DbCon.con);
            DbCon.Connection(command);
            OleDbDataReader drreader = command.ExecuteReader();
            List<BookData> book = new List<BookData>();

            while (drreader.Read())
            {
                book.Add(new BookData
                {
                    BookID = int.Parse(drreader["bookID"].ToString()),
                    BookName = drreader["bookName"].ToString(),
                    BookType = drreader["bookType"].ToString(),
                    BookPage = drreader["bookPage"].ToString(),
                    BookAuthor = drreader["bookAuthor"].ToString()
                });
            }

            return book;
        }

        //Veri tabanındaki Kitap tablosuna ekleme işlemi gerçekleştirildi
        public static int addBook(BookData book)
        {
            OleDbCommand command = new OleDbCommand("insert into tbl_Book(bookName,bookType,bookPage,bookAuthor) values(@bookN,@bookT,@bookP,@bookA)", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@bookN", book.BookName);
            command.Parameters.AddWithValue("@bookT", book.BookType);
            command.Parameters.AddWithValue("@bookP", book.BookPage);
            command.Parameters.AddWithValue("@bookA", book.BookAuthor);

            return command.ExecuteNonQuery();
        }

        // Kitabın veritabanındaki kitap tablosunda kayıtlı mı, diye id sorgusu ile kontrol edildi.
        public static bool queryBook(BookData book)
        {
            OleDbCommand command = new OleDbCommand("Select * from tbl_Book where bookID=@id", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@id", book.BookID);

            OleDbDataReader drreader = command.ExecuteReader();
            bool total = false;
            int timer = 0;

            while (drreader.Read())
            {
                timer++;
            }

            if (timer > 0)
            {
                total = true;
            }

            return total;
        }

        // Veri tabanındaki kitap tablosunda bulunan id sorgusundaki kitap silindi
        public static int deleteBook(BookData book)
        {
            OleDbCommand command = new OleDbCommand("Delete from tbl_Book where bookID=@id ", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@id", book.BookID);

            return command.ExecuteNonQuery();
        }

        // Veri tabanında bulunan kitap tablosundaki kitap id ile eşleşen kitap güncellendi
        public static int updateBook(BookData book)
        {
            OleDbCommand command = new OleDbCommand("Update tbl_Book set bookName=@name,bookType=@type,bookPage=@page,bookAuthor=@author where bookID=@id", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@name", book.BookName);
            command.Parameters.AddWithValue("@type", book.BookType);
            command.Parameters.AddWithValue("@page", book.BookPage);
            command.Parameters.AddWithValue("@author", book.BookAuthor);
            command.Parameters.AddWithValue("@id", book.BookID);

            return command.ExecuteNonQuery();
        }

        // Sorgudaki id ye sahip kitabın bilgileri kitap tablosundan çekildi
        public static BookData bookIDInfo(BookData book)
        {
            OleDbCommand command = new OleDbCommand("Select * from tbl_Book where bookID = @book", DbCon.con);
            DbCon.Connection(command);
            command.Parameters.AddWithValue("@book", book.BookID);
            OleDbDataReader read = command.ExecuteReader();

            while (read.Read())
            {
                book.BookName= read["bookName"].ToString();
                book.BookType = read["bookType"].ToString();
                book.BookPage = read["bookPage"].ToString();
                book.BookAuthor = read["bookAuthor"].ToString();
            }

            return book;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;      // DAL katmanını kullandık
using ENTITY;   // Entity katmanını kullandık

namespace BL
{
    #region Bilgi 
    //Diğer sınıflardan erişim sağlayabilmek için sınıflarımızı public tanımlıyoruz.
    #endregion
    public class AdminBL
    {
        //Girilen T.C. Kimlik Numarası ve Şifreye ait Personel, veritabanında kayıtlı mı diye DAL katmanı kullanılarak kontrol edilmesi sağlanmıştır.

        public static bool checkAdmin_BL(AdminData admin)
        {
            if (admin.admIdeNu != "" && admin.admPass != "")    // AdminData sınıfından görevliye ait olan TC Kimlik No ve Şifresi bilgilerinin boş olmadığı kontrol edildi.
                return AdminDAL.checkAdmin(admin);              // DAL katmanı kullanılarak, Veritabanından bilgileri girilen görevlinin kontrolü sağlandı.

            else
                return false;                                   // Eğer gelen veri boş ise false değer döndürdü.
        }
    }
}

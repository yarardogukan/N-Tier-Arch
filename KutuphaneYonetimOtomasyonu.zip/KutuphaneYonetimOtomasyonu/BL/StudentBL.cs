﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;      // DAL katmanına erişim sağlandı
using ENTITY;  //   Entity katmanına erişim sağlandı

namespace BL
{
    public class StudentBL
    {
        //Veri tabanındaki tüm öğrenci bilgileri DAL katmanı kullanılarak listeye aktarıldı
        public static List<StudentData> studentList()
        {
            return StudentDAL.studentList();
        }

        public static bool checkStudentNu(StudentData student)
        {
            if (student.StudentNu != "") // Gelen verilerin boş olmadığı kontrol edildi
            {
                return StudentDAL.checkStudentNu(student); // Veritabanından girilen değerlere ait öğrenci kontrol edildi
            }

            else                    //Eğer gelen veri boş ise false döndürdü
                return false;
        }

        //Girilen öğrenci bilgileri DAL katmanı kullanılarak veritabanına eklendi
        public static int addStudent(StudentData student)
        {
            if (student.StudentName != "" && student.StudentLastN != "" && student.StudentNu != "" && student.StudentPass != "" && student.StudentSex != "")
            {

                return StudentDAL.addStudent(student);
            }

            else
                return -1;
        }


        //Girilen id 'ye  ait öğrenci DAL katmanı kullanılarak veri tabanından silindi
        public static int deleteStudent(StudentData student)
        {
            if (student.StudentID != 0)
            {

                return StudentDAL.deleteStudent(student);
            }

            else
                return -1;
        }

        //Girilen id 'ye  ait öğrenci DAL katmanı kullanılarak veri tabanındaki verileri güncellendi
        public static int updateStudent(StudentData student)
        {
            if (student.StudentName != "" && student.StudentLastN != "" && student.StudentNu != "" && student.StudentPass != "" && student.StudentSex != "" && student.StudentID != 0)
            {

                return StudentDAL.updateStudent(student);
            }

            else
                return -1;
        }

        public static bool queryStudent_BL(StudentData student)
        {
            if (student.StudentID!= 0) // Gelen verilerin boş olmadığı kontrol edildi
            {
                return StudentDAL.queryStudent(student); // Veritabanından girilen değerlere ait öğrenci kontrol edildi
            }

            else                    //Eğer gelen veri boş ise false döndürdü
                return false;
        }

        public static bool checkStudent_BL(StudentData student)
        {
            if (student.StudentNu!= "" && student.StudentPass!= "") // Gelen verilerin boş olmadığı kontrol edildi
            {
                return StudentDAL.checkStudent(student); // Veritabanından girilen değerlere ait öğrenci kontrol edildi
            }

            else                    //Eğer gelen veri boş ise false döndürdü
                return true;
        }

        public static int studentQueryID(StudentData student)
        {
            if (student.StudentNu != "" && student.StudentPass!= "") // Gelen verilerin boş olmadığı kontrol edildi
            {
                return StudentDAL.studentQueryID(student); // Veritabanından girilen değerlere ait öğrenci kontrol edildi
            }

            else                    //Eğer gelen veri boş ise false döndürdü
                return -1;
        }

        public static StudentData studentInfoID(StudentData student)
        {
            if (student.StudentID != 0) // Gelen verilerin boş olmadığı kontrol edildi
            {
                return StudentDAL.studentInfoID(student); // Veritabanından girilen değerlere ait öğrenci kontrol edildi
            }

            else                    //Eğer gelen veri boş ise NULL döndürdü
                return null;
        }


    }
}

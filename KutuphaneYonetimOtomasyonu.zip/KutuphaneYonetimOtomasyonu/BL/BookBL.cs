﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;      // DAL katmanına erişim sağlandı
using ENTITY;  //   Entity katmanına erişim sağlandı

namespace BL
{
    public class BookBL
    {
        //Kitap bilgilerinin olduğu liste DAL katmanı kullanılarak aktarıldı.
        public static List<BookData> bookList()
        {

            return BookDAL.bookList();
        }

        //Kitap ekleme işlemi DAL katmanı kullanılarak gerçekleştirildi.
        public static int addBook(BookData book)
        {
            if (book.BookName != "" && book.BookType != "" && book.BookPage != "" && book.BookAuthor != "")
            {

                return BookDAL.addBook(book);
            }

            else
                return -1;
        }

        //Girilen KitapId' ye ait kitap veri tabanında kayıtlı mı diye DAL katmanı kullanılarak kontrol edildi
        public static bool queryBook_BL(BookData book)
        {
            if (book.BookID!= 0) // Gelen verilerin boş olmadığı kontrol edildi
            {
                return BookDAL.queryBook(book); // Veritabanından girilen değerlere ait kitap kontrol edildi
            }

            else                    //Eğer gelen veri boş ise false döndürdü
                return false;
        }

        // Id ' ye ait kitap  DAL katmanı kullanılara silindi
        public static int deleteBook(BookData book)
        {
            if (book.BookID != 0)
            {

                return BookDAL.deleteBook(book);
            }

            else
                return -1;
        }

        // Id' ye kitap DAL katmanı kullanılarak güncellendi
        public static int updateBook(BookData book)
        {
            if (book.BookID != 0 && book.BookName != "" && book.BookType != "" && book.BookPage != "" && book.BookAuthor != "")
            {

                return BookDAL.updateBook(book);
            }

            else
                return -1;
        }

        // DAL katmanı kullanılarak Kitap id ile kitap bilgileri çekildi
        public static BookData bookIDInfo(BookData book)
        {
            if (book.BookID!= 0) // Gelen verilerin boş olmadığı kontrol edildi
            {
                return BookDAL.bookIDInfo(book); // Veritabanından girilen değerlere ait öğrenci kontrol edildi
            }

            else                    //Eğer gelen veri boş ise false döndürdü
                return null;
        }

    }
}

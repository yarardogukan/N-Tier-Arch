﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;      // DAL katmanına erişim sağlandı
using ENTITY;  //   Entity katmanına erişim sağlandı

namespace BL
{
    public class ReturnBookBL
    {
        public static List<BookStudentData> bookStudentList(BookStudentData book)
        {
            if (book.BookID != 0)
                return ReturnBookDAL.bookStudentList(book);
            else
                return null;
        }

        // Id ile öğrencini almış olduğu kitaplar tarihsel bir şekilde  DAL katmanı kullanılarak listelendi
        public static List<TakingBookData> studentIDList(TakingBookData book)
        {

            return ReturnBookDAL.studentIDList(book);
        }

        //Ogrencinin aldiği kitaplar DAL katmanı kullanılarak listelendi
        public static List<string> purchaseBookList(ReturnBookData book)
        {
            return ReturnBookDAL.purchaseBookList(book);
        }

        //Ogrencinin teslim etmesi gereken kitaplar DAL katmanı kullanılarak listelendi
        public static List<string> deliverBookList(ReturnBookData book)
        {

            return ReturnBookDAL.deliverBookList(book);
        }

        // Ogrenciye ait ceza bilgisini  DAL katmanını kullanrak öğrendik
        public static List<string> suspendenStudent(ReturnBookData book)
        {

            return ReturnBookDAL.suspendenStudent(book);
        }

        //Öğrenciye ait güncel ceza DAL katmanı kullanılarak eklendi
        public static int studentPunishmentProcess(ReturnBookData student)
        {
            if (student.StudentPunshmnt>= 0)
            {

                return ReturnBookDAL.studentPunishmentProcess(student);
            }

            else
                return -1;
        }

        // Kitap adı ile kitap Id bilgisi DAL katmanı kullanılarak int döndürüldü
        public static int bookNID(BookStudentData book)
        {
            if (book.BookName != "")
            {

                return ReturnBookDAL.bookNID(book);
            }

            else
                return -1;
        }

        //Kİtap alma işlemi DAL katmanı kullanılarak gerçekleştirildi
        public static int purchaseBookProcess(ReturnBookData book)
        {
            if (book.BookID != 0 && book.StudentID != 0 && book.PurchaseBook != null)
            {

                return ReturnBookDAL.purchaseBookProcess(book);
            }

            else
                return -1;
        }

        //Kitap teslim etme işlemi DAL katmanı kullanılarak gerçekleştirildi
        public static int deliverBookProcess(ReturnBookData book)
        {
            if (book.BookID != 0)
            {

                return ReturnBookDAL.deliverBookProcess(book);
            }

            else
                return -1;
        }

        //kitabın Alinma tarihini DAL katmanı kullanarak öğrendik
        public static List<string> datePurchaseBook(ReturnBookData book)
        {

            return ReturnBookDAL.datePurchaseBook(book);
        }

        // öğrenciye ait alinabilir kitaplarin sayisi DAL katmanı kullanılarak int döndürüldü
        public static int purchasableGraphics(ReturnBookData book)
        {
            if (book.StudentID != 0)
            {
                return ReturnBookDAL.purchasableGraphics(book);
            }
            return 0;
        }

        // öğrenciye ait almış olduğu kitaplarin sayisi DAL katmanı kullanılarak int döndürüldü
        public static int givenGraphics(ReturnBookData book)
        {
            if (book.StudentID != 0)
            {
                return ReturnBookDAL.givenGraphics(book);
            }
            return 0;
        }

        // Tüm kitapların sayisi DAL katmanı kullanılarak int döndürüldü
        public static int allGraphics()
        {
            return ReturnBookDAL.allGraphics();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITY
{

    // Personele ait verilerin diğer katmanlarda kullanabilmek için get set işlemi yapılmıştır.
    public class AdminData
    {
        int adminID;
        string adminName, adminLastN, adminIdeNu, adminPass;

        public int admID { get => adminID; set => adminID = value; }
        public string admName { get => adminName; set => adminName = value; }
        public string admLastN { get => adminLastN; set => adminLastN = value; }
        public string admIdeNu { get => adminIdeNu; set => adminIdeNu = value; }
        public string admPass { get => adminPass; set => adminPass = value; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITY
{
    public class TakingBookData
    {
        //Aldığımız kitapların verilerini diğer katmanlarda kullanabilmek için get set işlemi yapıldı
        int studentID;
        string bookName, deliverBook;
        DateTime purchaseBook;
        bool checkBook;

        public int StudentID { get => studentID; set => studentID = value; }
        public string BookName { get => bookName; set => bookName = value; }
        public DateTime PurchaseBook { get => purchaseBook; set => purchaseBook = value; }
        public string DeliverBook { get => deliverBook; set => deliverBook = value; }
        public bool CheckBook { get => checkBook; set => checkBook = value; }
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITY
{
    //Kitap iade işlemleri için verilerini diğer katmanlarda kullanabilmek amacı ile get set işlemi yapıldı
    public class ReturnBookData
    {
        int takingBookID, studentID, bookID;
        DateTime purchaseBook;
        DateTime deliverBook;
        bool checkBook;
        float studentPunshmnt;

        public int TakingBookID { get => takingBookID; set => takingBookID = value; }
        public int BookID { get => bookID; set => bookID = value; }
        public int StudentID { get => studentID; set => studentID = value; }
        public DateTime PurchaseBook { get => purchaseBook; set => purchaseBook = value; }
        public DateTime DeliverBook { get => deliverBook; set => deliverBook = value; }
        public bool CheckBook { get => checkBook; set => checkBook = value; }
        public float StudentPunshmnt { get => studentPunshmnt; set => studentPunshmnt = value; }
    }
}

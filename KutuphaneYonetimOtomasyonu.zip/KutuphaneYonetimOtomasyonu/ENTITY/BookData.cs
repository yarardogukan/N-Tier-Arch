﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITY
{
    //Kitap verilerini diğer katmanlarda kullanabilmek için get set işlemi yapıldı
    public class BookData
    {
        int bookID;
        string bookName, bookType, bookPage, bookAuthor;
        public int BookID { get => bookID; set => bookID = value; }
        public string BookName { get => bookName; set => bookName = value; }
        public string BookType { get => bookType; set => bookType = value; }
        public string BookPage { get => bookPage; set => bookPage = value; }
        public string BookAuthor { get => bookAuthor; set => bookAuthor = value; }
    }
}

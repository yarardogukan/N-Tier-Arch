﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITY
{
    public class BookStudentData
    {
        //Kitap ve ogrenci için kullanılan ortak verilerini diğer katmanlarda kullanabilmek için get set işlemi yapıldı
        
            int bookID;
            string studentName, studentLastN, bookName, deliverBook;
            DateTime purchaseBook;
            bool checkBook;


            public int BookID { get => bookID; set => bookID = value; }
            public string StudentName { get => studentName; set => studentName = value; }
            public string StudentLastN { get => studentLastN; set => studentLastN = value; }
            public string BookName { get => bookName; set => bookName = value; }
            public DateTime PurchaseBook { get => purchaseBook; set => purchaseBook = value; }
            public string DeliverBook { get => deliverBook; set => deliverBook = value; }
            public bool CheckBook { get => checkBook; set => checkBook = value; }
    }
}

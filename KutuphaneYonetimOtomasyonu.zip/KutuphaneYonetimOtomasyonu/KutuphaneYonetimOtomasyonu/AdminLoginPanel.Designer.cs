﻿
namespace KutuphaneYonetimOtomasyonu
{
    partial class AdminLoginPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminLoginPanel));
            this.lbl_StudentInfo = new System.Windows.Forms.Label();
            this.pBox_Cikis = new System.Windows.Forms.PictureBox();
            this.cBox_Show = new System.Windows.Forms.CheckBox();
            this.btn_AdminLogin = new System.Windows.Forms.Button();
            this.pBox_ExPic2 = new System.Windows.Forms.PictureBox();
            this.pBox_ExPic1 = new System.Windows.Forms.PictureBox();
            this.btn_Back = new System.Windows.Forms.Button();
            this.txt_AdminPass = new System.Windows.Forms.TextBox();
            this.txt_AdminIdeN = new System.Windows.Forms.TextBox();
            this.lblPass = new System.Windows.Forms.Label();
            this.lblIdeNu = new System.Windows.Forms.Label();
            this.lblOgrenci = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lbl_Required = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Cikis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_ExPic2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_ExPic1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_StudentInfo
            // 
            this.lbl_StudentInfo.AutoSize = true;
            this.lbl_StudentInfo.BackColor = System.Drawing.Color.Transparent;
            this.lbl_StudentInfo.Font = new System.Drawing.Font("Times New Roman", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_StudentInfo.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbl_StudentInfo.Location = new System.Drawing.Point(12, 285);
            this.lbl_StudentInfo.Name = "lbl_StudentInfo";
            this.lbl_StudentInfo.Size = new System.Drawing.Size(191, 17);
            this.lbl_StudentInfo.TabIndex = 52;
            this.lbl_StudentInfo.Text = "| Doğukan Yarar - 182119003 | ";
            // 
            // pBox_Cikis
            // 
            this.pBox_Cikis.BackColor = System.Drawing.Color.Transparent;
            this.pBox_Cikis.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pBox_Cikis.Image = ((System.Drawing.Image)(resources.GetObject("pBox_Cikis.Image")));
            this.pBox_Cikis.Location = new System.Drawing.Point(683, 11);
            this.pBox_Cikis.Name = "pBox_Cikis";
            this.pBox_Cikis.Size = new System.Drawing.Size(44, 34);
            this.pBox_Cikis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_Cikis.TabIndex = 51;
            this.pBox_Cikis.TabStop = false;
            this.pBox_Cikis.Click += new System.EventHandler(this.pBox_Cikis_Click);
            // 
            // cBox_Show
            // 
            this.cBox_Show.AutoSize = true;
            this.cBox_Show.BackColor = System.Drawing.Color.Transparent;
            this.cBox_Show.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cBox_Show.ForeColor = System.Drawing.Color.White;
            this.cBox_Show.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cBox_Show.Location = new System.Drawing.Point(481, 149);
            this.cBox_Show.Name = "cBox_Show";
            this.cBox_Show.Size = new System.Drawing.Size(79, 21);
            this.cBox_Show.TabIndex = 50;
            this.cBox_Show.Text = "Göster";
            this.cBox_Show.UseVisualStyleBackColor = false;
            this.cBox_Show.CheckedChanged += new System.EventHandler(this.cBox_Show_CheckedChanged);
            // 
            // btn_AdminLogin
            // 
            this.btn_AdminLogin.BackColor = System.Drawing.Color.DimGray;
            this.btn_AdminLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_AdminLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_AdminLogin.ForeColor = System.Drawing.Color.White;
            this.btn_AdminLogin.Location = new System.Drawing.Point(334, 190);
            this.btn_AdminLogin.Name = "btn_AdminLogin";
            this.btn_AdminLogin.Size = new System.Drawing.Size(75, 32);
            this.btn_AdminLogin.TabIndex = 49;
            this.btn_AdminLogin.Text = "Giriş";
            this.btn_AdminLogin.UseVisualStyleBackColor = false;
            this.btn_AdminLogin.Click += new System.EventHandler(this.btn_AdminLogin_Click);
            // 
            // pBox_ExPic2
            // 
            this.pBox_ExPic2.BackColor = System.Drawing.Color.Transparent;
            this.pBox_ExPic2.Image = ((System.Drawing.Image)(resources.GetObject("pBox_ExPic2.Image")));
            this.pBox_ExPic2.Location = new System.Drawing.Point(578, 102);
            this.pBox_ExPic2.Name = "pBox_ExPic2";
            this.pBox_ExPic2.Size = new System.Drawing.Size(128, 128);
            this.pBox_ExPic2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_ExPic2.TabIndex = 48;
            this.pBox_ExPic2.TabStop = false;
            // 
            // pBox_ExPic1
            // 
            this.pBox_ExPic1.BackColor = System.Drawing.Color.Transparent;
            this.pBox_ExPic1.Image = ((System.Drawing.Image)(resources.GetObject("pBox_ExPic1.Image")));
            this.pBox_ExPic1.Location = new System.Drawing.Point(22, 102);
            this.pBox_ExPic1.Name = "pBox_ExPic1";
            this.pBox_ExPic1.Size = new System.Drawing.Size(128, 128);
            this.pBox_ExPic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_ExPic1.TabIndex = 47;
            this.pBox_ExPic1.TabStop = false;
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.Transparent;
            this.btn_Back.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Back.BackgroundImage")));
            this.btn_Back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_Back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Back.ForeColor = System.Drawing.Color.DimGray;
            this.btn_Back.ImageKey = "reply.png";
            this.btn_Back.Location = new System.Drawing.Point(12, 11);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(70, 34);
            this.btn_Back.TabIndex = 46;
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // txt_AdminPass
            // 
            this.txt_AdminPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_AdminPass.Location = new System.Drawing.Point(347, 147);
            this.txt_AdminPass.Multiline = true;
            this.txt_AdminPass.Name = "txt_AdminPass";
            this.txt_AdminPass.PasswordChar = '*';
            this.txt_AdminPass.Size = new System.Drawing.Size(112, 22);
            this.txt_AdminPass.TabIndex = 45;
            this.txt_AdminPass.Text = "123";
            // 
            // txt_AdminIdeN
            // 
            this.txt_AdminIdeN.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_AdminIdeN.ForeColor = System.Drawing.Color.Black;
            this.txt_AdminIdeN.Location = new System.Drawing.Point(347, 100);
            this.txt_AdminIdeN.Name = "txt_AdminIdeN";
            this.txt_AdminIdeN.Size = new System.Drawing.Size(112, 22);
            this.txt_AdminIdeN.TabIndex = 44;
            this.txt_AdminIdeN.Text = "12345678910";
            this.txt_AdminIdeN.TextChanged += new System.EventHandler(this.txt_AdminIdeN_TextChanged);
            this.txt_AdminIdeN.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_AdminIdeN_KeyPress);
            // 
            // lblPass
            // 
            this.lblPass.AutoSize = true;
            this.lblPass.BackColor = System.Drawing.Color.Transparent;
            this.lblPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblPass.ForeColor = System.Drawing.Color.White;
            this.lblPass.Location = new System.Drawing.Point(185, 149);
            this.lblPass.Name = "lblPass";
            this.lblPass.Size = new System.Drawing.Size(55, 20);
            this.lblPass.TabIndex = 43;
            this.lblPass.Text = "Şifre:";
            // 
            // lblIdeNu
            // 
            this.lblIdeNu.AutoSize = true;
            this.lblIdeNu.BackColor = System.Drawing.Color.Transparent;
            this.lblIdeNu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblIdeNu.ForeColor = System.Drawing.Color.White;
            this.lblIdeNu.Location = new System.Drawing.Point(185, 102);
            this.lblIdeNu.Name = "lblIdeNu";
            this.lblIdeNu.Size = new System.Drawing.Size(130, 20);
            this.lblIdeNu.TabIndex = 42;
            this.lblIdeNu.Text = "TC. Kimlik No:";
            // 
            // lblOgrenci
            // 
            this.lblOgrenci.AutoSize = true;
            this.lblOgrenci.BackColor = System.Drawing.Color.Transparent;
            this.lblOgrenci.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lblOgrenci.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.lblOgrenci.Location = new System.Drawing.Point(274, 13);
            this.lblOgrenci.Name = "lblOgrenci";
            this.lblOgrenci.Size = new System.Drawing.Size(188, 32);
            this.lblOgrenci.TabIndex = 41;
            this.lblOgrenci.Text = "Personel Girişi";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lbl_Required
            // 
            this.lbl_Required.AutoSize = true;
            this.lbl_Required.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Required.ForeColor = System.Drawing.Color.Red;
            this.lbl_Required.Location = new System.Drawing.Point(146, 251);
            this.lbl_Required.Name = "lbl_Required";
            this.lbl_Required.Size = new System.Drawing.Size(73, 17);
            this.lbl_Required.TabIndex = 53;
            this.lbl_Required.Text = "hataMesaj";
            this.lbl_Required.Visible = false;
            // 
            // AdminLoginPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(739, 312);
            this.Controls.Add(this.lbl_StudentInfo);
            this.Controls.Add(this.pBox_Cikis);
            this.Controls.Add(this.cBox_Show);
            this.Controls.Add(this.btn_AdminLogin);
            this.Controls.Add(this.pBox_ExPic2);
            this.Controls.Add(this.pBox_ExPic1);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.txt_AdminPass);
            this.Controls.Add(this.txt_AdminIdeN);
            this.Controls.Add(this.lblPass);
            this.Controls.Add(this.lblIdeNu);
            this.Controls.Add(this.lblOgrenci);
            this.Controls.Add(this.lbl_Required);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AdminLoginPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminLoginPanel";
            this.Load += new System.EventHandler(this.AdminLoginPanel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Cikis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_ExPic2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_ExPic1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_StudentInfo;
        private System.Windows.Forms.PictureBox pBox_Cikis;
        private System.Windows.Forms.CheckBox cBox_Show;
        private System.Windows.Forms.Button btn_AdminLogin;
        private System.Windows.Forms.PictureBox pBox_ExPic2;
        private System.Windows.Forms.PictureBox pBox_ExPic1;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.TextBox txt_AdminPass;
        private System.Windows.Forms.TextBox txt_AdminIdeN;
        private System.Windows.Forms.Label lblPass;
        private System.Windows.Forms.Label lblIdeNu;
        private System.Windows.Forms.Label lblOgrenci;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lbl_Required;
    }
}
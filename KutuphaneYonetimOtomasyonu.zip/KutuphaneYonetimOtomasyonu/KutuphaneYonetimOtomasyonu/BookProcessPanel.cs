﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BL;        // BL katmanını kullanacağımız için ekledik.
using ENTITY;   // Entity katmanını kullanacağımız için ekledik.

namespace KutuphaneYonetimOtomasyonu
{
    public partial class BookProcessPanel : Form
    {
        public BookProcessPanel()
        {
            InitializeComponent();
        }

        int id; // Global bir id değişkeni tanımlandı.

        private void BookProcessPanel_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;                              // label'da kayan yazı oluşturmak için timer'ı başlattık.
            timer2.Enabled = true;

            ToolTip aciklama = new ToolTip();                   // ISBN label etiketinin üzerine gelince şunları göster.
            aciklama.IsBalloon = true;
            aciklama.ToolTipIcon = ToolTipIcon.Info;
            aciklama.ToolTipTitle = "Dikkat!";
            aciklama.SetToolTip(lbl_ISBN, "Kitabın ID numarasıdır.");

            lbl_Required.Visible = false;

            dgv_BookList.DataSource = BookBL.bookList(); // Form açıldığında datagrid'in veri kaynağı olarak veritabanındaki listeyi çektik.

            dgv_BookList.Columns[0].HeaderText = "ISBN";
            dgv_BookList.Columns[1].HeaderText = "Kitabın Adı";
            dgv_BookList.Columns[2].HeaderText = "Kitabın Türü";
            dgv_BookList.Columns[3].HeaderText = "Sayfa Sayısı";
            dgv_BookList.Columns[4].HeaderText = "Kitabın Yazarı";

            UNotNull();
        }

        #region Fonksiyonlarım 
        // Form ekranı için kullanılan fonksiyonlar listelenmiştir.

        private void UNotNull() // Uygulama açıldığında hata vermemesi için güncelleme panelinde bulunan nesnelere boş değer atadık.
        {
            txt_UpdateName.Text = "";
            cBox_UpdateType.Text = null;
            txt_UpdatePage.Text = "";
            txt_UpdateAuthor.Text = "";
            id = 0;
        }
        private void TxtClear() // Ekleme işlemindeki araçları temizler.
        {
            txt_AddName.Text = "";
            cBox_AddType.Text = null;
            txt_AddPage.Text = "";
            txt_AddAuthor.Text = "";
        }


        #endregion

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_StudentInfo.Text = lbl_StudentInfo.Text.Substring(1) + lbl_StudentInfo.Text.Substring(0, 1); // Substring metodu ile label'a yazdığımız değerin timer ile döndürüyoruz.
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            AdminCheckPanel adminCP = new AdminCheckPanel();     // Gidilecek forma geçmek için bir değişken (adminCP) oluşturduk.
            this.Hide();                                         // BookProcess sayfasının kapatılmasını sağladık.
            adminCP.Show();                                      // Oluşturulan değişken formuna gidilmesini sağladık.
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            DialogResult dialog = new DialogResult();   // Kullanıcı uygulamadan çıkmadan önce bir "Evet-Hayır" dialog nesnesiyle karşılaşacaktır.
            dialog = MessageBox.Show("Gerçekten çıkmak istiyor musunuz?", "ÇIKIŞ", MessageBoxButtons.YesNo, MessageBoxIcon.Warning); // MsgBox.Show metodunu dialog nesnesiyle birlikte kullandık.
            if (dialog == DialogResult.Yes) // Eğer sonuç evet ise uygulamadan çıkmasını sağladık
            {
                Application.Exit();
            }
            else    // Eğer cevap hayır ise kulanıcının proje de devam etmesini sağladık.
            {
                return;
            }
        }

        private void dgv_BookList_SelectionChanged(object sender, EventArgs e)
        {
            // Tablo üzerinde tıklanan satırın verilerini güncelleme işlemi yapılan alanındaki araçlara yazdırdık.

            id = int.Parse(dgv_BookList.CurrentRow.Cells[0].Value.ToString());
            txt_UpdateName.Text = dgv_BookList.CurrentRow.Cells[1].Value.ToString();
            cBox_UpdateType.Text = dgv_BookList.CurrentRow.Cells[2].Value.ToString();
            txt_UpdatePage.Text = dgv_BookList.CurrentRow.Cells[3].Value.ToString();
            txt_UpdateAuthor.Text = dgv_BookList.CurrentRow.Cells[4].Value.ToString();
        }

        #region KeyPress Event'leri
        private void txt_AddPage_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Harf girilmesi engellendi. Sadece sayı girişine izin verdik.
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txt_UpdatePage_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Harf girilmesi engellendi. Sadece sayı girişine izin verdik.
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txt_ISBN_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Harf girilmesi engellendi. Sadece sayı girişine izin verdik.
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        #endregion

        private void pBox_ReturnBookInfo_Click(object sender, EventArgs e)
        {
            // PictureBox a tıklanınca... 
            lbl_List.Text = "İADE BİLGİ LİSTESİ";     // Labeldaki yazı değişti
            lbl_PboxReturnBook.ForeColor = Color.Green;        // İade label i aktif rengi aldı
            lbl_pBoxBook.ForeColor = Color.White;       // Bilgi label i pasif rengi aldı
            BookStudentData book = new BookStudentData()
            {
                BookID = id
            };

            lbl_Announcement.Text = "Kitap bilgilendirmesine geri dönmek için Kitap Bilgisi butonuna tıklayınız.";
            dgv_BookList.DataSource = ReturnBookBL.bookStudentList(book);

            UNotNull();
        }

        private void pBox_BookInfo_Click(object sender, EventArgs e)
        {
            lbl_List.Text = "Kitap Bilgi Listesi";
            dgv_BookList.DataSource = BookBL.bookList();
            lbl_pBoxBook.ForeColor = Color.Green;
            lbl_PboxReturnBook.ForeColor = Color.White;       // Bilgi label i pasif rengi aldı
        }

        #region EKLE - SİL - GÜNCELLE İŞLEMLERİ

        private void btn_AdminLogin_Click(object sender, EventArgs e)
        {
            //Ekleme işlemi için textboxların dolu olup olmadığını kontrol ettik
            if (txt_AddName.Text != "" && cBox_AddType.Text != "" && txt_AddPage.Text != "" && txt_AddAuthor.Text != "")
            {
                //Entity katmanındaki değişkenlere textboxtaki verileri aktardık
                BookData book = new BookData()
                {
                    BookName = txt_AddName.Text,
                    BookType = cBox_AddType.Text,
                    BookPage = txt_AddPage.Text,
                    BookAuthor = txt_AddAuthor.Text
                };

                BookBL.addBook(book);  //business katmanındaki kitapEkle fonksiyonuna verileri gönderdik
                lbl_Success.Visible = true;
                timer2.Start(); // Başarılı! yazısını belli bir saniye ekranda göstermesi için timer nesnesini başlattık.
                dgv_BookList.DataSource = BookBL.bookList();// Ekleme işleminden sonra listenin güncel halini ekrana yansıttık

                TxtClear();

            }

            else
            {
                MessageBox.Show("Lütfen gerekli alanları doldurunuz!");
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (txt_ISBN.Text != "")    // ID'nin girileceği textbox'ın boş olup olmadığını kontrol ettik. 
            {
                //Entity katmanındaki KitapId değişkenine textboxtaki veriyi aktardık
                BookData book = new BookData()
                {
                    BookID = int.Parse(txt_ISBN.Text)
                };

                //Girilen id ye ait kitap kontrol edildi
                if (BookBL.queryBook_BL(book) == true)
                {
                    BookBL.deleteBook(book); // Business katmanındaki kitapSİL Fonksiyonuna silme işlemi için verileri gönderdik
                    lbl_Success.Visible = true;
                    timer2.Start(); // Başarılı! yazısını belli bir saniye ekranda göstermesi için timer nesnesini başlattık.
                    dgv_BookList.DataSource = BookBL.bookList(); // Lİstenin güncel halini datagrid e yansıttık
                    txt_ISBN.Text = ""; // Silme işleminden sonra textbox ı temizledik
                }

                else
                    MessageBox.Show("Girdiğiniz ID numarasına ait bir kitap bulunmamaktadır!");

            }
            else
                MessageBox.Show("Gerekli alanları doldurunuz!");
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            //Güncelleme işlemi için textboxların dolu olup olmadığını kontrol ettik.
            if (txt_UpdateName.Text != "" && cBox_UpdateType.Text != "" && txt_UpdatePage.Text != "" && txt_UpdateAuthor.Text != "")
            {
                //Entity katmanındaki değişkenlere araçlardaki verileri aktardık
                BookData book = new BookData()
                {
                    BookName = txt_AddName.Text,
                    BookType = cBox_AddType.Text,
                    BookPage = txt_AddPage.Text,
                    BookAuthor = txt_AddAuthor.Text,
                    BookID = id
                };

                // Girilen id ye ait kitap kontrol edildi
                if (BookBL.queryBook_BL(book) == true)
                {
                    BookBL.updateBook(book);// BL Katmanına güncelleme işlemi için verileri gönderdik
                    lbl_Success.Visible = true;
                    timer2.Start(); // Başarılı! yazısını belli bir saniye ekranda göstermesi için timer nesnesini başlattık.
                    dgv_BookList.DataSource = BookBL.bookList();// Lİstenin güncel halini datagrid e yansıttık
                    UNotNull(); //Araçları temizlemeye yarayan fonksiyonu çağırdık.
                }

                else
                    MessageBox.Show("Lütfen listeden seçim yaptıktan sonra değerleri doldurunuz!");
            }

            else
            {
                MessageBox.Show("Lütfen gerekli alanları doldurunuz");
            }
        }

        #endregion

        int timerAnno = 0;  // Başarılı ya da başarısız labellarının sürekli ekranda kalmamasını sağlamak için timer a değişken tanımladık.  
        private void timer2_Tick(object sender, EventArgs e)
        {
            timerAnno++;
            if (timerAnno == 5)
            {
                timer2.Stop();
                lbl_Success.Visible = false;
            }
        }

        private void cBox_UpdateType_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Yanlışıkla basıldı.
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BL;  // BL katmanını kullandık
using ENTITY; // Entity katmanını kullandık

namespace KutuphaneYonetimOtomasyonu
{
    public partial class StudentInfoPanel : Form
    {
        public StudentInfoPanel()
        {
            InitializeComponent();
        }

        #region Renklendirme ve Listeleme
        public void studentInfoList()
        {
            StudentData student = new StudentData()  // Öğrenci verisinden nesne oluşturuldu.
            {

                StudentID = Convert.ToInt32(lbl_IDStudentInfo.Text)
            };

            // Öğrencinin bilgileri labellara aktarıldı.

            student = StudentBL.studentInfoID(student);
            lbl_Student.Text = "Hoşgeldin  " + student.StudentName;
            lbl_InfoName.Text = student.StudentName;
            lbl_InfoLastN.Text = student.StudentLastN;
            lbl_InfoStudentNu.Text = student.StudentNu;
            lbl_InfoPass.Text = student.StudentPass;
            lbl_InfoSex.Text = student.StudentSex;
            lbl_InfoSusp.Text = student.StudentSusp.ToString();
        }

        public void coloringList()
        {
            for (int i = 0; i < dgv_BookPDList.Rows.Count; i++) // Tablo satırı kadar döndürüldü
            {
                DataGridViewCellStyle color = new DataGridViewCellStyle(); // Renklendirecek Nesne oluşturuldu.

                if (Convert.ToBoolean(dgv_BookPDList.Rows[i].Cells[4].Value) == true) // Kitabın Teslim edilme durumu kontrol edildi.
                {
                    //Satır renklendirildi

                    color.BackColor = Color.Green; // Arkaplan rengi
                    color.ForeColor = Color.White; // Yazı rengi
                }

                else
                {
                    // Teslim edilmeyen kitapların teslim tarihine ne kadar kaldığı öğrenildi
                    TimeSpan total = DateTime.Now - Convert.ToDateTime(dgv_BookPDList.Rows[i].Cells[2].Value);

                    // 15 gün ve üzeri ise satır kırmızı renk yapıldı
                    if (total.TotalDays > 15)
                    {
                        color.BackColor = Color.Red;
                    }

                    // teslim süresine 2 gün kalmış ise satır sarı yapıldı
                    if (total.TotalDays >= 13 && total.TotalDays <= 15)
                    {
                        color.BackColor = Color.Yellow;
                    }
                }
                dgv_BookPDList.Rows[i].DefaultCellStyle = color; // Satırlara renklendirme işlemi gerçekleştirildi
            }
        }

        #endregion
        private void StudentInfoPanel_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer2.Enabled = true;

            studentInfoList(); // Öğrenci bilgilerinin tutulduğu fonksiyon çağrıldı

            TakingBookData takingBook = new TakingBookData()  // Nesne oluşturuldu.
            {
                StudentID = int.Parse(lbl_IDStudentInfo.Text)  // ID ataması yapıldı
            };
            dgv_BookPDList.DataSource = ReturnBookBL.studentIDList(takingBook); // Form açıldığında datagrid üzerine veritabanındaki listeyi aktardık.

            // Bir sütunu gizledik ve diğer sütunların başlıklarını düzenledik
            dgv_BookPDList.Columns[0].Visible = false;              // id başlığının listelenmesini kapattık.
            dgv_BookPDList.Columns[1].HeaderText = "Kitap Adı";     // Tablo başlıklarının isimlerini güncelledik.
            dgv_BookPDList.Columns[2].HeaderText = "Alınma Tarihi";
            dgv_BookPDList.Columns[3].HeaderText = "Teslim Tarihi";
            dgv_BookPDList.Columns[4].HeaderText = "Teslim Edilmiş mi?";

            ReturnBookData returnB = new ReturnBookData()  // Nesne oluşturuldu
            {
                StudentID = int.Parse(lbl_IDStudentInfo.Text)  // Id atamasını yaptık.
            };
            cBox_PurchaseBook.DataSource = ReturnBookBL.purchaseBookList(returnB); // Combobox nesnesine alınabilecek olan kitapları aktardık.
            cBox_DeliverBook.DataSource = ReturnBookBL.deliverBookList(returnB); // Combobox nesnesine teslim edilecek kitapları aktardık.
            coloringList();  // Tablodaki satırları renklendirme fonksiyounu çağrıldı.
        }

        #region Timer Eventleri

        int timerAnno = 0;  // Başarılı ya da başarısız labellarının sürekli ekranda kalmamasını sağlamak için timer a değişken tanımladık.  
        private void timer2_Tick(object sender, EventArgs e)
        {
            timerAnno++;    // sayacı arttırdık.
            if (timerAnno == 5) // sayaç 5 e ulaştığında (interval=1000 olduğundan 5 saniye olacak şekilde)
            {
                timer2.Stop();  // timer'ın çalışmasını durdurduk
                lbl_Success.Visible = false; // 5 saniye sonrasında ise label'ın görünürlüğünü kapattık.
                lbl_Unsuccess.Visible = false; // 5 saniye sonrasında ise label'ın görünürlüğünü kapattık.
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_StudentInfo.Text = lbl_StudentInfo.Text.Substring(1) + lbl_StudentInfo.Text.Substring(0, 1); // Substring metodu ile label'a yazdığımız değerin timer ile döndürüyoruz.
        }

        #endregion

        #region Form Geçişleri

        private void pBox_BookGraphics_Click(object sender, EventArgs e)
        {
            GraphicsPanel g = new GraphicsPanel();          //  Grafik formundan nesne üretildi
            g.lbl_StudentID.Text = lbl_IDStudentInfo.Text; //id ataması yapıldı
            this.Hide();                                    // Bulunduğumuz form ekranı kapatıldı
            g.Show();                                       // Öğrenci nesnesini kullanarak grafik formu açıldı
        }

        private void pBox_FindBook_Click(object sender, EventArgs e)
        {
            SearchBookPanel sB = new SearchBookPanel();  //  Kitap arama formundan nesne üretildi
            sB.lbl_BSStudentID.Text = lbl_IDStudentInfo.Text; //id ataması yapıldı
            this.Hide();                           // Bulunduğumuz form ekranı kapatıldı
            sB.Show();
        }

        private void pBox_Exit_Click(object sender, EventArgs e)
        {
            DialogResult dialog = new DialogResult();   // Uygulamadan çıkılmak istenildiğinde kullanıcıya bir dialog gönderecek nesne tanıtıldı.
            dialog = MessageBox.Show("Gerçekten çıkmak istiyor musunuz?", "ÇIKIŞ", MessageBoxButtons.YesNo, MessageBoxIcon.Warning); // MsgBox.Show metodu, dialog nesnesine aktarıldı ve sonucuna göre işlem yaptırıldı
            if (dialog == DialogResult.Yes) // eğer sonuç evet ise uygulamadan çıkılması sağlandı
            {
                Application.Exit();
            }
            else    // eğer cevap hayır ise uygulamaya geri dönülmesi sağlandı.
            {
                return;
            }
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            StudentLoginPanel sL = new StudentLoginPanel();              //  Öğrenci giriş formundan nesne üretildi
            this.Hide();                                       // Bulunduğumuz form ekranı kapatıldı
            sL.Show();
        }

        #endregion

        #region Buton Eventleri

        private void btn_PayPunishment_Click(object sender, EventArgs e)
        {
            if (txt_Punishment.Text != "")  // Ceza ödenecek textbox nesnesinin boş olmadığı kontrol edildi.
            {
                ReturnBookData studentID = new ReturnBookData()  // id ataması yapılacak nesne oluşturuldu.
                {
                    StudentID = int.Parse(lbl_IDStudentInfo.Text) // id atamasını yaptık.
                };
                ReturnBookBL.suspendenStudent(studentID); // kullanıcının bugüne kadar oluşturduğu ceza bilgisi çekildi.
                if (studentID.StudentPunshmnt != 0)  // ceza durumu 0 değilse, şunları yap.
                {
                    float punishment = studentID.StudentPunshmnt- float.Parse(txt_Punishment.Text); // ödenen ceza tutarı ile önceden olan cezanın farkı alındı.
                    if (punishment >= 0)  // Cezanın eksiye düşmemesi kontrol edildi.
                    {
                        studentID.StudentPunshmnt = punishment; // Fark alındıktan sonra öğrencinin güncel cezası aktarıldı.
                        ReturnBookBL.studentPunishmentProcess(studentID); // Veritabanına güncel ceza bilgisi gönderildi.
                        studentInfoList(); // Ceza ödendikten sonra ceza bilgisi yansıtıldı.
                        MessageBox.Show(txt_Punishment.Text + " TL ödendi."); // Kullanıcıya ödenen ceza bilgisi gösterildi.
                        txt_Punishment.Text = ""; // ödeme işleminden sonra textbox temizlendi.
                    }
                    else
                    {
                        MessageBox.Show("Ödenecek tutar cezadan büyük olamaz!");    // Cezanın eksiye düşmesini istemeyiz, bu yüzden düştüğünde bu hata verildi.
                    }
                }

                else
                {
                    MessageBox.Show("Borcunuz Bulunmamaktadır."); // Öğrencinin 0 TL cezası var ise bu uyarıyı gösterdik.
                    txt_Punishment.Text = ""; // textbox'u temizledik.
                }
            }

            else
            {
                MessageBox.Show("Lütfen ödenecek tutarı giriniz!");     // Textbox'un boş olmaması gerekir.
            }
        }

        private void btn_PickUp_Click(object sender, EventArgs e)
        {
            if (cBox_PurchaseBook.Text != "") //Text in doluluğu kontrol edildi
            {
                TimeSpan passTime = DateTime.Now - dTP_PurchaseBook.Value.Date; //zaman farkı alındı
                if (passTime.TotalDays >= 0)  // Şuanki günden ileri olup olmadığı kontrol edildi
                {

                    BookStudentData bookID = new BookStudentData() //nesne oluşturuldu
                    {
                        BookName = cBox_PurchaseBook.Text //Kitap adı aktarıldı
                    };


                    ReturnBookData book = new ReturnBookData() // nesne oluşturuldu
                    {
                        BookID = ReturnBookBL.bookNID(bookID), // kitap id aktarıldı
                        StudentID = int.Parse(lbl_IDStudentInfo.Text),  // Öğrenci id aktarıldı
                        PurchaseBook = dTP_PurchaseBook.Value.Date  // Alınma tarihi aktarıldı
                    };

                    ReturnBookBL.purchaseBookProcess(book); // Veri tabanında alma işlemi gerçekleştirildi

                    //Güncel liste oluşturulma işlemi.

                    TakingBookData takingBook = new TakingBookData() 
                    {
                        StudentID = int.Parse(lbl_IDStudentInfo.Text) // id ataması yapıldı.
                    };
                    dgv_BookPDList.DataSource = ReturnBookBL.studentIDList(takingBook); // Kitabı alanların listesine göre datagrid e alınan kitapları yansıttık.
                    coloringList(); //Renklendirme fonksiyonunu çağırdık.

                    //güncel kitaplar oluşturulma
                    ReturnBookData returnBook = new ReturnBookData()
                    {
                        StudentID = int.Parse(lbl_IDStudentInfo.Text) // id ataması yapıldı.
                    };
                    cBox_PurchaseBook.DataSource = ReturnBookBL.purchaseBookList(returnBook); // Combobox'a alınan kitapları aktardık.
                    cBox_DeliverBook.DataSource = ReturnBookBL.deliverBookList(returnBook);   // Combobox'a verilen kitapları aktardık.
                    timer2.Start(); // Timer'ı başlattık
                    lbl_Success.Visible = true; //başarılı yazısını ekranda gösterdik.
                    
                }
                else
                {
                    MessageBox.Show("Kitap Alım Tarihi, bugünden ileri bir tarih olamaz!"); // İleri bir tarihden kitap alınamayacağı için böyle seçimlerde hata mesajı verdirttik.
                }
            }
            else
            {
                timer2.Start();
                lbl_Unsuccess.Visible = true;
                MessageBox.Show("Alınabilir kitap şu an mevcut değil. Daha sonra tekrar deneyiniz."); // Combobox'ın boş olması durumunda, hiç bir kitabın kütüphanede kalmadığını ve bu yüzden kitap alınamayacağını kullanıcıya bildiren mesajı yansıttık.
                
            }
        }

        private void btn_GiveUp_Click(object sender, EventArgs e)
        {
            if (cBox_DeliverBook.Text != "")  // Combobox'ın boş olmaması kontrol edildi.
            {

                BookStudentData bookID = new BookStudentData() // ID ataması yapılacak nesne oluşturuldu.
                {
                    BookName = cBox_DeliverBook.Text // bookID ile kitap adı çekildi.
                };


                ReturnBookData book = new ReturnBookData() // Kitabın ve öğrencinin çekildiği nesne oluşturuldu ve bilgiler aktarıldı.
                {
                    BookID = ReturnBookBL.bookNID(bookID),
                    StudentID = int.Parse(lbl_IDStudentInfo.Text),
                    DeliverBook = dTP_DeliverBook.Value.Date,
                    CheckBook = true
                };

                ReturnBookBL.datePurchaseBook(book); // Kitabın alınma tarihi çekildi.
                TimeSpan total = book.DeliverBook - book.PurchaseBook; // Teslim edilen günden, alınma tarihi çıkarıldı ve değişkene atandı.
                if (total.TotalDays >= 0) // Zaman farkının eksiye düşmemesi sağlandı.
                {
                    ReturnBookBL.deliverBookProcess(book); // Teslim işlemi gerçekleştirildi.

                    // Güncel liste oluşturma. (DataGridView)

                    TakingBookData takingBook = new TakingBookData() // Nesne oluşturuldu.
                    {
                        StudentID = int.Parse(lbl_IDStudentInfo.Text) // ID ataması yapıldı.
                    };

                    dgv_BookPDList.DataSource = ReturnBookBL.studentIDList(takingBook); // Güncel liste, datagrid nesnesine aktarıldı.
                    coloringList();  // Tablo satırlarını renklendirme fonksiyonu çağrıldı.

                    // Güncel kitapların gösterilmesi. (Combobox)

                    ReturnBookData returnBook = new ReturnBookData()    // Nesne oluşturulduu.
                    {
                        StudentID = int.Parse(lbl_IDStudentInfo.Text)   // ID ataması yapıldı.
                    };
                    cBox_PurchaseBook.DataSource = ReturnBookBL.purchaseBookList(returnBook);   // Alınabilir kitaplar, combobox'a aktarıldı.
                    cBox_DeliverBook.DataSource = ReturnBookBL.deliverBookList(returnBook);     // Verilebilir kitaplar, combobox'a aktarıldı.

                    if (total.TotalDays > 15)  // Teslim süresi 15 günü geçmiş ise ceza işlemi uygulandı
                    {
                        float pnshmnt = float.Parse(total.TotalDays.ToString()) - 15;  // 15 gün teslim süresini aşanlara hergün için 1 TL ceza kesildi.
                        ReturnBookBL.suspendenStudent(returnBook); // Ceza bilgisi çekildi.
                        returnBook.StudentPunshmnt += pnshmnt; // Eski ceza bilgisinin üzerine şu anki işlenen ceza bilgisi eklendi.
                        ReturnBookBL.studentPunishmentProcess(returnBook); // Veritabanına ceza işlemi gerçekleştirildi.
                        studentInfoList(); // Güncel liste çağrıldı.
                    }

                    timer2.Start(); // 5 saniye ekranda göstermesini sağlayan timer nesnesini çağırdık.
                    lbl_Success.Visible = true; // Başarılı labelını ekranda gösterdik.
                }

                else
                {
                    MessageBox.Show("Teslim tarihi, kitabın alım tarihinden önce olamaz!"); // Bir kitabı almadan teslim edemeyeceğimiz için, bu işlemin yapılmasını engelledik.
                }

            }

            else
            {
                timer2.Start(); // 5 saniye ekranda göstermesini sağlayan timer nesnesini çağırdık.
                lbl_Unsuccess.Visible = true; // Başarısız labelını ekranda gösterdik.
                MessageBox.Show("Teslim edilecek kitabın yok !");   // Combobox boş olduğu için bir kitap teslim edilemez. Bu yüzden sistemin hata vermemesi için kullanıcıya hata mesajı verdirttik.
            }
        }
        
        #endregion
        private void txt_Punishment_KeyPress(object sender, KeyPressEventArgs e)    // Harf girilmesi engellendi. Sadece sayı girişine izin verdik.
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}

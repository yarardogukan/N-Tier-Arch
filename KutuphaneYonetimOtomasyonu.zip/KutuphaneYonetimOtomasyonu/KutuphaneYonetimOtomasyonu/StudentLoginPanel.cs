﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ENTITY;  // Entity katmanını kullanacağımız için ekledik.
using BL;     // BL katmanını kullanacağımız için ekledik.

namespace KutuphaneYonetimOtomasyonu
{
    public partial class StudentLoginPanel : Form
    {
        public StudentLoginPanel()
        {
            InitializeComponent();
        }

        private void btn_StudentLogin_Click(object sender, EventArgs e)
        {
            if (txt_StudentNu.Text != "" && txt_StudentPass.Text != "") //Textlerin boş bırakılmaması kontrol edildi
            {
                StudentData student= new StudentData()       //Entity katmanındaki verilere girilen değerler aktarıldı
                {
                    StudentNu = txt_StudentNu.Text,
                    StudentPass = txt_StudentPass.Text

                };

                if (StudentBL.checkStudent_BL(student) == true) // Veritabanındaki tabloda girilen değerlere ait öğrenci var mı kontrol edildi
                {
                    lbl_StudentLoginID.Text = StudentBL.studentQueryID(student).ToString(); //id ataması yapıldı
                    //Başarılı şekilde giriş yaptıktan sonra yeni forma geçiş yapacaktır.
                    StudentInfoPanel std = new StudentInfoPanel();
                    std.lbl_IDStudentInfo.Text = lbl_StudentLoginID.Text;
                    this.Hide();                         // Şuan bulunduğumuz form kapatıldı
                    std.Show();                 // Oluşturulan nesne ile geçiş yapılacak form ekranı açıldı
                }
                else
                    MessageBox.Show("Verileriniz eşleşmemektedir. Sorun devam ederse lütfen destek alınız!");
            }

            else
            {
                MessageBox.Show("Araç kutuları boş bırakılamaz!");
            }
        }

        private void pBox_Exit_Click(object sender, EventArgs e)
        {
            DialogResult dialog = new DialogResult();           // Bir dialogResult tanımlayarak kullanıcı çıkış yapmak istediğinde soru sordurulmasını tanımladık.
            dialog = MessageBox.Show("Gerçekten çıkmak istiyor musunuz?", "ÇIKIŞ", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);    // Hata mesajını burada verdirttik.
            if (dialog == DialogResult.Yes) // Eğer "Evet" e tıklarsa uygulamadan çıkmasını sağladık. 
            {
                Application.Exit();
            }
            else    // Eğer "Hayır" a tıklarsa uygulama da olduğu yerden devam etmesini sağladık.
            {
                return;
            }
        }

        private void bnt_Back_Click(object sender, EventArgs e)
        {
            Home h = new Home();                                // Gidilecek forma geçmek için bir değişken (h) oluşturduk.
            this.Hide();                                        // AdminLogin sayfasının kapatılmasını sağladık.
            h.Show();                                           // Oluşturulan değişken formuna gidilmesini sağladık.
        }

        private void StudentLoginPanel_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true; // label'da kayan yazı oluşturmak için timer'ı başlattık.
            lbl_StudentLoginID.Visible = false; // ID ataması yapılacak label etiketini gizledik.
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_StudentInfo.Text = lbl_StudentInfo.Text.Substring(1) + lbl_StudentInfo.Text.Substring(0, 1); // Substring metodu ile label'a yazdığımız değerin timer ile döndürüyoruz.
        }

        private void cBox_Show_CheckedChanged(object sender, EventArgs e)
        {
            if (cBox_Show.CheckState == CheckState.Checked)           // Checkbox seçilmiş ise
            {
                txt_StudentPass.UseSystemPasswordChar = true;         // Şifreyi * olmadan yaz
                cBox_Show.Text = "Gizle";                           // Checkbox'un metnini Gizle olarak değiştir.
            }

            else if (cBox_Show.CheckState == CheckState.Unchecked)    // Checkbox seçili değil ise
            {
                txt_StudentPass.UseSystemPasswordChar = false;        // Şifreyi * olarak yaz.
                cBox_Show.Text = "Göster";                          // Checkbox'un metnini Göster olarak değiştir.
            }
        }

        private void txt_StudentNu_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))     // Harf girilmesi engellendi. Sadece sayı girişine izin verdik.
            {
                e.Handled = true;
            }
        }
    }
}

﻿
namespace KutuphaneYonetimOtomasyonu
{
    partial class BookProcessPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BookProcessPanel));
            this.btn_Update = new System.Windows.Forms.Button();
            this.lbl_Announcement = new System.Windows.Forms.Label();
            this.lbl_pBoxBook = new System.Windows.Forms.Label();
            this.pBox_BookInfo = new System.Windows.Forms.PictureBox();
            this.btn_AdminLogin = new System.Windows.Forms.Button();
            this.lbl_PboxReturnBook = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_AddAuthor = new System.Windows.Forms.TextBox();
            this.pBox_ReturnBookInfo = new System.Windows.Forms.PictureBox();
            this.txt_AddPage = new System.Windows.Forms.TextBox();
            this.lbl_List = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dgv_BookList = new System.Windows.Forms.DataGridView();
            this.txt_AddName = new System.Windows.Forms.TextBox();
            this.lbl_AAuthor = new System.Windows.Forms.Label();
            this.lbl_APage = new System.Windows.Forms.Label();
            this.lbl_AType = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btn_Back = new System.Windows.Forms.Button();
            this.lbl_AName = new System.Windows.Forms.Label();
            this.lbl_StudentInfo = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lbl_Success = new System.Windows.Forms.Label();
            this.lbl_Required = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.lbl_ISBN = new System.Windows.Forms.Label();
            this.txt_ISBN = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lbl_UAuthor = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbl_UPage = new System.Windows.Forms.Label();
            this.lbl_UType = new System.Windows.Forms.Label();
            this.cBox_UpdateType = new System.Windows.Forms.ComboBox();
            this.lbl_UName = new System.Windows.Forms.Label();
            this.txt_UpdateAuthor = new System.Windows.Forms.TextBox();
            this.txt_UpdatePage = new System.Windows.Forms.TextBox();
            this.txt_UpdateName = new System.Windows.Forms.TextBox();
            this.lbl_Unsuccess = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cBox_AddType = new System.Windows.Forms.ComboBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pBox_BookInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_ReturnBookInfo)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_BookList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Update
            // 
            this.btn_Update.BackColor = System.Drawing.Color.DimGray;
            this.btn_Update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Update.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Update.ForeColor = System.Drawing.Color.White;
            this.btn_Update.Location = new System.Drawing.Point(299, 113);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(119, 32);
            this.btn_Update.TabIndex = 13;
            this.btn_Update.Text = "GÜNCELLE";
            this.btn_Update.UseVisualStyleBackColor = false;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // lbl_Announcement
            // 
            this.lbl_Announcement.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_Announcement.ForeColor = System.Drawing.Color.White;
            this.lbl_Announcement.Location = new System.Drawing.Point(11, 215);
            this.lbl_Announcement.Name = "lbl_Announcement";
            this.lbl_Announcement.Size = new System.Drawing.Size(755, 55);
            this.lbl_Announcement.TabIndex = 0;
            this.lbl_Announcement.Text = "Not: İade bilgisini öğrenmek istediğiniz kitabın listeden üzerine tıklayıp iade b" +
    "ilgisi butonuna basınız.";
            // 
            // lbl_pBoxBook
            // 
            this.lbl_pBoxBook.AutoSize = true;
            this.lbl_pBoxBook.BackColor = System.Drawing.Color.Transparent;
            this.lbl_pBoxBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_pBoxBook.ForeColor = System.Drawing.Color.White;
            this.lbl_pBoxBook.Location = new System.Drawing.Point(33, 40);
            this.lbl_pBoxBook.Name = "lbl_pBoxBook";
            this.lbl_pBoxBook.Size = new System.Drawing.Size(96, 18);
            this.lbl_pBoxBook.TabIndex = 6;
            this.lbl_pBoxBook.Text = "Kitap Bilgisi";
            // 
            // pBox_BookInfo
            // 
            this.pBox_BookInfo.BackColor = System.Drawing.Color.Transparent;
            this.pBox_BookInfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pBox_BookInfo.Image = ((System.Drawing.Image)(resources.GetObject("pBox_BookInfo.Image")));
            this.pBox_BookInfo.Location = new System.Drawing.Point(59, 3);
            this.pBox_BookInfo.Name = "pBox_BookInfo";
            this.pBox_BookInfo.Size = new System.Drawing.Size(41, 37);
            this.pBox_BookInfo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_BookInfo.TabIndex = 5;
            this.pBox_BookInfo.TabStop = false;
            this.pBox_BookInfo.Click += new System.EventHandler(this.pBox_BookInfo_Click);
            // 
            // btn_AdminLogin
            // 
            this.btn_AdminLogin.BackColor = System.Drawing.Color.DimGray;
            this.btn_AdminLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_AdminLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_AdminLogin.ForeColor = System.Drawing.Color.White;
            this.btn_AdminLogin.Location = new System.Drawing.Point(112, 248);
            this.btn_AdminLogin.Name = "btn_AdminLogin";
            this.btn_AdminLogin.Size = new System.Drawing.Size(75, 32);
            this.btn_AdminLogin.TabIndex = 5;
            this.btn_AdminLogin.Text = "EKLE";
            this.btn_AdminLogin.UseVisualStyleBackColor = false;
            this.btn_AdminLogin.Click += new System.EventHandler(this.btn_AdminLogin_Click);
            // 
            // lbl_PboxReturnBook
            // 
            this.lbl_PboxReturnBook.AutoSize = true;
            this.lbl_PboxReturnBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_PboxReturnBook.ForeColor = System.Drawing.Color.White;
            this.lbl_PboxReturnBook.Location = new System.Drawing.Point(672, 40);
            this.lbl_PboxReturnBook.Name = "lbl_PboxReturnBook";
            this.lbl_PboxReturnBook.Size = new System.Drawing.Size(89, 18);
            this.lbl_PboxReturnBook.TabIndex = 4;
            this.lbl_PboxReturnBook.Text = "İade Bilgisi";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(273, 13);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(297, 29);
            this.label9.TabIndex = 1;
            this.label9.Text = "Kitap Güncelleme İşlemi";
            // 
            // txt_AddAuthor
            // 
            this.txt_AddAuthor.Location = new System.Drawing.Point(112, 204);
            this.txt_AddAuthor.Name = "txt_AddAuthor";
            this.txt_AddAuthor.Size = new System.Drawing.Size(122, 22);
            this.txt_AddAuthor.TabIndex = 4;
            // 
            // pBox_ReturnBookInfo
            // 
            this.pBox_ReturnBookInfo.BackColor = System.Drawing.Color.Transparent;
            this.pBox_ReturnBookInfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pBox_ReturnBookInfo.Image = ((System.Drawing.Image)(resources.GetObject("pBox_ReturnBookInfo.Image")));
            this.pBox_ReturnBookInfo.Location = new System.Drawing.Point(699, 3);
            this.pBox_ReturnBookInfo.Name = "pBox_ReturnBookInfo";
            this.pBox_ReturnBookInfo.Size = new System.Drawing.Size(41, 37);
            this.pBox_ReturnBookInfo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_ReturnBookInfo.TabIndex = 3;
            this.pBox_ReturnBookInfo.TabStop = false;
            this.pBox_ReturnBookInfo.Click += new System.EventHandler(this.pBox_ReturnBookInfo_Click);
            // 
            // txt_AddPage
            // 
            this.txt_AddPage.Location = new System.Drawing.Point(112, 156);
            this.txt_AddPage.Name = "txt_AddPage";
            this.txt_AddPage.Size = new System.Drawing.Size(122, 22);
            this.txt_AddPage.TabIndex = 3;
            this.txt_AddPage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_AddPage_KeyPress);
            // 
            // lbl_List
            // 
            this.lbl_List.AutoSize = true;
            this.lbl_List.BackColor = System.Drawing.Color.Transparent;
            this.lbl_List.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_List.ForeColor = System.Drawing.Color.White;
            this.lbl_List.Location = new System.Drawing.Point(273, 13);
            this.lbl_List.Name = "lbl_List";
            this.lbl_List.Size = new System.Drawing.Size(242, 29);
            this.lbl_List.TabIndex = 1;
            this.lbl_List.Text = "Kitapla İlgili Bilgiler";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.Controls.Add(this.lbl_Announcement);
            this.panel4.Controls.Add(this.lbl_pBoxBook);
            this.panel4.Controls.Add(this.pBox_BookInfo);
            this.panel4.Controls.Add(this.lbl_PboxReturnBook);
            this.panel4.Controls.Add(this.pBox_ReturnBookInfo);
            this.panel4.Controls.Add(this.dgv_BookList);
            this.panel4.Controls.Add(this.lbl_List);
            this.panel4.Location = new System.Drawing.Point(335, 73);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(788, 281);
            this.panel4.TabIndex = 54;
            // 
            // dgv_BookList
            // 
            this.dgv_BookList.AllowUserToAddRows = false;
            this.dgv_BookList.AllowUserToDeleteRows = false;
            this.dgv_BookList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_BookList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_BookList.BackgroundColor = System.Drawing.Color.White;
            this.dgv_BookList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_BookList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgv_BookList.Location = new System.Drawing.Point(15, 61);
            this.dgv_BookList.Name = "dgv_BookList";
            this.dgv_BookList.ReadOnly = true;
            this.dgv_BookList.RowHeadersWidth = 51;
            this.dgv_BookList.RowTemplate.Height = 24;
            this.dgv_BookList.Size = new System.Drawing.Size(758, 152);
            this.dgv_BookList.TabIndex = 2;
            this.dgv_BookList.SelectionChanged += new System.EventHandler(this.dgv_BookList_SelectionChanged);
            // 
            // txt_AddName
            // 
            this.txt_AddName.Location = new System.Drawing.Point(112, 60);
            this.txt_AddName.Name = "txt_AddName";
            this.txt_AddName.Size = new System.Drawing.Size(122, 22);
            this.txt_AddName.TabIndex = 1;
            // 
            // lbl_AAuthor
            // 
            this.lbl_AAuthor.AutoSize = true;
            this.lbl_AAuthor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_AAuthor.ForeColor = System.Drawing.Color.White;
            this.lbl_AAuthor.Location = new System.Drawing.Point(18, 206);
            this.lbl_AAuthor.Name = "lbl_AAuthor";
            this.lbl_AAuthor.Size = new System.Drawing.Size(63, 20);
            this.lbl_AAuthor.TabIndex = 5;
            this.lbl_AAuthor.Text = "Yazar:";
            // 
            // lbl_APage
            // 
            this.lbl_APage.AutoSize = true;
            this.lbl_APage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_APage.ForeColor = System.Drawing.Color.White;
            this.lbl_APage.Location = new System.Drawing.Point(21, 158);
            this.lbl_APage.Name = "lbl_APage";
            this.lbl_APage.Size = new System.Drawing.Size(62, 20);
            this.lbl_APage.TabIndex = 3;
            this.lbl_APage.Text = "Sayfa:";
            // 
            // lbl_AType
            // 
            this.lbl_AType.AutoSize = true;
            this.lbl_AType.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_AType.ForeColor = System.Drawing.Color.White;
            this.lbl_AType.Location = new System.Drawing.Point(21, 108);
            this.lbl_AType.Name = "lbl_AType";
            this.lbl_AType.Size = new System.Drawing.Size(43, 20);
            this.lbl_AType.TabIndex = 2;
            this.lbl_AType.Text = "Tür:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label14.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label14.Location = new System.Drawing.Point(450, 18);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(278, 32);
            this.label14.TabIndex = 55;
            this.label14.Text = "Kitap İşlemleri Sayfası";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(1090, 16);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(44, 34);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 50;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.Transparent;
            this.btn_Back.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Back.BackgroundImage")));
            this.btn_Back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_Back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Back.ForeColor = System.Drawing.Color.DimGray;
            this.btn_Back.ImageKey = "reply.png";
            this.btn_Back.Location = new System.Drawing.Point(12, 16);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(70, 34);
            this.btn_Back.TabIndex = 15;
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // lbl_AName
            // 
            this.lbl_AName.AutoSize = true;
            this.lbl_AName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_AName.ForeColor = System.Drawing.Color.White;
            this.lbl_AName.Location = new System.Drawing.Point(21, 60);
            this.lbl_AName.Name = "lbl_AName";
            this.lbl_AName.Size = new System.Drawing.Size(37, 20);
            this.lbl_AName.TabIndex = 1;
            this.lbl_AName.Text = "Ad:";
            // 
            // lbl_StudentInfo
            // 
            this.lbl_StudentInfo.AutoSize = true;
            this.lbl_StudentInfo.BackColor = System.Drawing.Color.Transparent;
            this.lbl_StudentInfo.Font = new System.Drawing.Font("Times New Roman", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_StudentInfo.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbl_StudentInfo.Location = new System.Drawing.Point(12, 589);
            this.lbl_StudentInfo.Name = "lbl_StudentInfo";
            this.lbl_StudentInfo.Size = new System.Drawing.Size(191, 17);
            this.lbl_StudentInfo.TabIndex = 56;
            this.lbl_StudentInfo.Text = "| Doğukan Yarar - 182119003 | ";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lbl_Success
            // 
            this.lbl_Success.AutoSize = true;
            this.lbl_Success.ForeColor = System.Drawing.Color.Lime;
            this.lbl_Success.Location = new System.Drawing.Point(335, 589);
            this.lbl_Success.Name = "lbl_Success";
            this.lbl_Success.Size = new System.Drawing.Size(142, 17);
            this.lbl_Success.TabIndex = 57;
            this.lbl_Success.Text = "Başarıyla sonuçlandı.";
            this.lbl_Success.Visible = false;
            // 
            // lbl_Required
            // 
            this.lbl_Required.AutoSize = true;
            this.lbl_Required.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbl_Required.Location = new System.Drawing.Point(108, 33);
            this.lbl_Required.Name = "lbl_Required";
            this.lbl_Required.Size = new System.Drawing.Size(190, 17);
            this.lbl_Required.TabIndex = 59;
            this.lbl_Required.Text = "Gerekli * alanları doldurunuz!";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(17, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(245, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Kitap Ekleme İşlemi";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.btn_Delete);
            this.panel2.Controls.Add(this.lbl_ISBN);
            this.panel2.Controls.Add(this.txt_ISBN);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Location = new System.Drawing.Point(12, 391);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(270, 164);
            this.panel2.TabIndex = 52;
            // 
            // btn_Delete
            // 
            this.btn_Delete.BackColor = System.Drawing.Color.DimGray;
            this.btn_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Delete.ForeColor = System.Drawing.Color.White;
            this.btn_Delete.Location = new System.Drawing.Point(113, 93);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(75, 32);
            this.btn_Delete.TabIndex = 7;
            this.btn_Delete.Text = "SİL";
            this.btn_Delete.UseVisualStyleBackColor = false;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // lbl_ISBN
            // 
            this.lbl_ISBN.AutoSize = true;
            this.lbl_ISBN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_ISBN.ForeColor = System.Drawing.Color.White;
            this.lbl_ISBN.Location = new System.Drawing.Point(19, 64);
            this.lbl_ISBN.Name = "lbl_ISBN";
            this.lbl_ISBN.Size = new System.Drawing.Size(64, 20);
            this.lbl_ISBN.TabIndex = 3;
            this.lbl_ISBN.Text = "ISBN: ";
            // 
            // txt_ISBN
            // 
            this.txt_ISBN.Location = new System.Drawing.Point(113, 62);
            this.txt_ISBN.Name = "txt_ISBN";
            this.txt_ISBN.Size = new System.Drawing.Size(122, 22);
            this.txt_ISBN.TabIndex = 6;
            this.txt_ISBN.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_ISBN_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(21, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(224, 29);
            this.label7.TabIndex = 1;
            this.label7.Text = "Kitap Silme İşlemi";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(-1, 159);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(508, 36);
            this.label13.TabIndex = 29;
            this.label13.Text = "Not: Güncellemek istediğiniz kitabın listeden üzerine tıklayınız .\r\n \r\n\r\n";
            // 
            // lbl_UAuthor
            // 
            this.lbl_UAuthor.AutoSize = true;
            this.lbl_UAuthor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_UAuthor.ForeColor = System.Drawing.Color.White;
            this.lbl_UAuthor.Location = new System.Drawing.Point(594, 51);
            this.lbl_UAuthor.Name = "lbl_UAuthor";
            this.lbl_UAuthor.Size = new System.Drawing.Size(63, 20);
            this.lbl_UAuthor.TabIndex = 28;
            this.lbl_UAuthor.Text = "Yazar ";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.btn_Update);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.lbl_UAuthor);
            this.panel3.Controls.Add(this.lbl_UPage);
            this.panel3.Controls.Add(this.lbl_UType);
            this.panel3.Controls.Add(this.cBox_UpdateType);
            this.panel3.Controls.Add(this.lbl_UName);
            this.panel3.Controls.Add(this.txt_UpdateAuthor);
            this.panel3.Controls.Add(this.txt_UpdatePage);
            this.panel3.Controls.Add(this.txt_UpdateName);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Location = new System.Drawing.Point(335, 360);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(788, 195);
            this.panel3.TabIndex = 53;
            // 
            // lbl_UPage
            // 
            this.lbl_UPage.AutoSize = true;
            this.lbl_UPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_UPage.ForeColor = System.Drawing.Color.White;
            this.lbl_UPage.Location = new System.Drawing.Point(423, 51);
            this.lbl_UPage.Name = "lbl_UPage";
            this.lbl_UPage.Size = new System.Drawing.Size(62, 20);
            this.lbl_UPage.TabIndex = 27;
            this.lbl_UPage.Text = "Sayfa ";
            // 
            // lbl_UType
            // 
            this.lbl_UType.AutoSize = true;
            this.lbl_UType.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_UType.ForeColor = System.Drawing.Color.White;
            this.lbl_UType.Location = new System.Drawing.Point(260, 51);
            this.lbl_UType.Name = "lbl_UType";
            this.lbl_UType.Size = new System.Drawing.Size(37, 20);
            this.lbl_UType.TabIndex = 26;
            this.lbl_UType.Text = "Tür";
            // 
            // cBox_UpdateType
            // 
            this.cBox_UpdateType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_UpdateType.FormattingEnabled = true;
            this.cBox_UpdateType.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cBox_UpdateType.Items.AddRange(new object[] {
            "Roman",
            "Tarih",
            "Bilim",
            "Oyku",
            "Siir"});
            this.cBox_UpdateType.Location = new System.Drawing.Point(232, 74);
            this.cBox_UpdateType.Name = "cBox_UpdateType";
            this.cBox_UpdateType.Size = new System.Drawing.Size(100, 24);
            this.cBox_UpdateType.TabIndex = 10;
            this.cBox_UpdateType.SelectedIndexChanged += new System.EventHandler(this.cBox_UpdateType_SelectedIndexChanged);
            // 
            // lbl_UName
            // 
            this.lbl_UName.AutoSize = true;
            this.lbl_UName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_UName.ForeColor = System.Drawing.Color.White;
            this.lbl_UName.Location = new System.Drawing.Point(90, 51);
            this.lbl_UName.Name = "lbl_UName";
            this.lbl_UName.Size = new System.Drawing.Size(37, 20);
            this.lbl_UName.TabIndex = 19;
            this.lbl_UName.Text = "Ad ";
            // 
            // txt_UpdateAuthor
            // 
            this.txt_UpdateAuthor.Location = new System.Drawing.Point(573, 74);
            this.txt_UpdateAuthor.Name = "txt_UpdateAuthor";
            this.txt_UpdateAuthor.Size = new System.Drawing.Size(100, 22);
            this.txt_UpdateAuthor.TabIndex = 12;
            // 
            // txt_UpdatePage
            // 
            this.txt_UpdatePage.Location = new System.Drawing.Point(403, 74);
            this.txt_UpdatePage.Name = "txt_UpdatePage";
            this.txt_UpdatePage.Size = new System.Drawing.Size(100, 22);
            this.txt_UpdatePage.TabIndex = 11;
            this.txt_UpdatePage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_UpdatePage_KeyPress);
            // 
            // txt_UpdateName
            // 
            this.txt_UpdateName.Location = new System.Drawing.Point(59, 74);
            this.txt_UpdateName.Name = "txt_UpdateName";
            this.txt_UpdateName.Size = new System.Drawing.Size(100, 22);
            this.txt_UpdateName.TabIndex = 8;
            // 
            // lbl_Unsuccess
            // 
            this.lbl_Unsuccess.AutoSize = true;
            this.lbl_Unsuccess.ForeColor = System.Drawing.Color.Red;
            this.lbl_Unsuccess.Location = new System.Drawing.Point(387, 588);
            this.lbl_Unsuccess.Name = "lbl_Unsuccess";
            this.lbl_Unsuccess.Size = new System.Drawing.Size(283, 17);
            this.lbl_Unsuccess.TabIndex = 58;
            this.lbl_Unsuccess.Text = "Yapılan işlemlerde bir sorun meydana geldi.";
            this.lbl_Unsuccess.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cBox_AddType);
            this.panel1.Controls.Add(this.btn_AdminLogin);
            this.panel1.Controls.Add(this.txt_AddAuthor);
            this.panel1.Controls.Add(this.txt_AddPage);
            this.panel1.Controls.Add(this.txt_AddName);
            this.panel1.Controls.Add(this.lbl_AAuthor);
            this.panel1.Controls.Add(this.lbl_APage);
            this.panel1.Controls.Add(this.lbl_AType);
            this.panel1.Controls.Add(this.lbl_AName);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 73);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(270, 312);
            this.panel1.TabIndex = 51;
            // 
            // cBox_AddType
            // 
            this.cBox_AddType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_AddType.FormattingEnabled = true;
            this.cBox_AddType.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cBox_AddType.Items.AddRange(new object[] {
            "Roman",
            "Tarih",
            "Bilim",
            "Oyku",
            "Siir"});
            this.cBox_AddType.Location = new System.Drawing.Point(112, 104);
            this.cBox_AddType.Name = "cBox_AddType";
            this.cBox_AddType.Size = new System.Drawing.Size(122, 24);
            this.cBox_AddType.TabIndex = 2;
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // BookProcessPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1146, 622);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.lbl_StudentInfo);
            this.Controls.Add(this.lbl_Success);
            this.Controls.Add(this.lbl_Required);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.lbl_Unsuccess);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BookProcessPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BookProcessPanel";
            this.Load += new System.EventHandler(this.BookProcessPanel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pBox_BookInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_ReturnBookInfo)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_BookList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.Label lbl_Announcement;
        private System.Windows.Forms.Label lbl_pBoxBook;
        private System.Windows.Forms.PictureBox pBox_BookInfo;
        private System.Windows.Forms.Button btn_AdminLogin;
        private System.Windows.Forms.Label lbl_PboxReturnBook;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_AddAuthor;
        private System.Windows.Forms.PictureBox pBox_ReturnBookInfo;
        private System.Windows.Forms.TextBox txt_AddPage;
        private System.Windows.Forms.Label lbl_List;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView dgv_BookList;
        private System.Windows.Forms.TextBox txt_AddName;
        private System.Windows.Forms.Label lbl_AAuthor;
        private System.Windows.Forms.Label lbl_APage;
        private System.Windows.Forms.Label lbl_AType;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Label lbl_AName;
        private System.Windows.Forms.Label lbl_StudentInfo;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lbl_Success;
        private System.Windows.Forms.Label lbl_Required;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Label lbl_ISBN;
        private System.Windows.Forms.TextBox txt_ISBN;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbl_UAuthor;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbl_UPage;
        private System.Windows.Forms.Label lbl_UType;
        private System.Windows.Forms.ComboBox cBox_UpdateType;
        private System.Windows.Forms.Label lbl_UName;
        private System.Windows.Forms.TextBox txt_UpdateAuthor;
        private System.Windows.Forms.TextBox txt_UpdatePage;
        private System.Windows.Forms.TextBox txt_UpdateName;
        private System.Windows.Forms.Label lbl_Unsuccess;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.ComboBox cBox_AddType;
    }
}
﻿
namespace KutuphaneYonetimOtomasyonu
{
    partial class GraphicsPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GraphicsPanel));
            this.lbl_StudentInfo = new System.Windows.Forms.Label();
            this.lbl_StudentID = new System.Windows.Forms.Label();
            this.pBox_Exit = new System.Windows.Forms.PictureBox();
            this.btn_Back = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.BookGraphics = new ZedGraph.ZedGraphControl();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Exit)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_StudentInfo
            // 
            this.lbl_StudentInfo.AutoSize = true;
            this.lbl_StudentInfo.BackColor = System.Drawing.Color.Transparent;
            this.lbl_StudentInfo.Font = new System.Drawing.Font("Times New Roman", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_StudentInfo.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbl_StudentInfo.Location = new System.Drawing.Point(12, 564);
            this.lbl_StudentInfo.Name = "lbl_StudentInfo";
            this.lbl_StudentInfo.Size = new System.Drawing.Size(191, 17);
            this.lbl_StudentInfo.TabIndex = 90;
            this.lbl_StudentInfo.Text = "| Doğukan Yarar - 182119003 | ";
            // 
            // lbl_StudentID
            // 
            this.lbl_StudentID.AutoSize = true;
            this.lbl_StudentID.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_StudentID.Location = new System.Drawing.Point(967, 33);
            this.lbl_StudentID.Name = "lbl_StudentID";
            this.lbl_StudentID.Size = new System.Drawing.Size(92, 17);
            this.lbl_StudentID.TabIndex = 89;
            this.lbl_StudentID.Text = "lbl_StudentID";
            this.lbl_StudentID.Visible = false;
            // 
            // pBox_Exit
            // 
            this.pBox_Exit.BackColor = System.Drawing.Color.Transparent;
            this.pBox_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pBox_Exit.Image = ((System.Drawing.Image)(resources.GetObject("pBox_Exit.Image")));
            this.pBox_Exit.Location = new System.Drawing.Point(1090, 42);
            this.pBox_Exit.Name = "pBox_Exit";
            this.pBox_Exit.Size = new System.Drawing.Size(44, 34);
            this.pBox_Exit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_Exit.TabIndex = 88;
            this.pBox_Exit.TabStop = false;
            this.pBox_Exit.Click += new System.EventHandler(this.pBox_Exit_Click);
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.Transparent;
            this.btn_Back.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Back.BackgroundImage")));
            this.btn_Back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_Back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Back.ForeColor = System.Drawing.Color.DimGray;
            this.btn_Back.ImageKey = "reply.png";
            this.btn_Back.Location = new System.Drawing.Point(12, 42);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(70, 34);
            this.btn_Back.TabIndex = 87;
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label14.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label14.Location = new System.Drawing.Point(411, 54);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(325, 32);
            this.label14.TabIndex = 86;
            this.label14.Text = "Grafiksel Gösterim Sayfası";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // BookGraphics
            // 
            this.BookGraphics.Location = new System.Drawing.Point(168, 115);
            this.BookGraphics.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BookGraphics.Name = "BookGraphics";
            this.BookGraphics.ScrollGrace = 0D;
            this.BookGraphics.ScrollMaxX = 0D;
            this.BookGraphics.ScrollMaxY = 0D;
            this.BookGraphics.ScrollMaxY2 = 0D;
            this.BookGraphics.ScrollMinX = 0D;
            this.BookGraphics.ScrollMinY = 0D;
            this.BookGraphics.ScrollMinY2 = 0D;
            this.BookGraphics.Size = new System.Drawing.Size(814, 407);
            this.BookGraphics.TabIndex = 91;
            // 
            // GraphicsPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1146, 622);
            this.Controls.Add(this.lbl_StudentInfo);
            this.Controls.Add(this.lbl_StudentID);
            this.Controls.Add(this.pBox_Exit);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.BookGraphics);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "GraphicsPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GraphicsPanel";
            this.Load += new System.EventHandler(this.GraphicsPanel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Exit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_StudentInfo;
        public System.Windows.Forms.Label lbl_StudentID;
        private System.Windows.Forms.PictureBox pBox_Exit;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Timer timer1;
        private ZedGraph.ZedGraphControl BookGraphics;
    }
}
﻿
namespace KutuphaneYonetimOtomasyonu
{
    partial class StudentProcessPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StudentProcessPanel));
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.lbl_StudentID = new System.Windows.Forms.Label();
            this.txt_DelStudentID = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lbl_UPass = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbl_USex = new System.Windows.Forms.Label();
            this.cBox_USex = new System.Windows.Forms.ComboBox();
            this.txt_ULastN = new System.Windows.Forms.TextBox();
            this.btn_Update = new System.Windows.Forms.Button();
            this.lbl_UStudentNo = new System.Windows.Forms.Label();
            this.lbl_ULastN = new System.Windows.Forms.Label();
            this.lbl_UName = new System.Windows.Forms.Label();
            this.txt_UPass = new System.Windows.Forms.TextBox();
            this.txt_UStudentNo = new System.Windows.Forms.TextBox();
            this.txt_UName = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_ALastN = new System.Windows.Forms.TextBox();
            this.lbl_Unsuccess = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_ASex = new System.Windows.Forms.Label();
            this.cBox_ASex = new System.Windows.Forms.ComboBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.txt_APass = new System.Windows.Forms.TextBox();
            this.txt_AStudentNu = new System.Windows.Forms.TextBox();
            this.txt_AName = new System.Windows.Forms.TextBox();
            this.lbl_APass = new System.Windows.Forms.Label();
            this.lbl_AStudentNo = new System.Windows.Forms.Label();
            this.lbl_ALastN = new System.Windows.Forms.Label();
            this.lbl_AName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_List = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dgv_StudentList = new System.Windows.Forms.DataGridView();
            this.pBox_Exit = new System.Windows.Forms.PictureBox();
            this.btn_Back = new System.Windows.Forms.Button();
            this.lbl_StudentInfo = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label14 = new System.Windows.Forms.Label();
            this.lbl_Success = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_StudentList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Exit)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.btn_Delete);
            this.panel2.Controls.Add(this.lbl_StudentID);
            this.panel2.Controls.Add(this.txt_DelStudentID);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Location = new System.Drawing.Point(9, 423);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(299, 164);
            this.panel2.TabIndex = 63;
            // 
            // btn_Delete
            // 
            this.btn_Delete.BackColor = System.Drawing.Color.DimGray;
            this.btn_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Delete.ForeColor = System.Drawing.Color.White;
            this.btn_Delete.Location = new System.Drawing.Point(113, 101);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(75, 32);
            this.btn_Delete.TabIndex = 47;
            this.btn_Delete.Text = "SİL";
            this.btn_Delete.UseVisualStyleBackColor = false;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // lbl_StudentID
            // 
            this.lbl_StudentID.AutoSize = true;
            this.lbl_StudentID.Font = new System.Drawing.Font("Times New Roman", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbl_StudentID.ForeColor = System.Drawing.Color.White;
            this.lbl_StudentID.Location = new System.Drawing.Point(10, 72);
            this.lbl_StudentID.Name = "lbl_StudentID";
            this.lbl_StudentID.Size = new System.Drawing.Size(56, 25);
            this.lbl_StudentID.TabIndex = 3;
            this.lbl_StudentID.Text = "ID:  ";
            // 
            // txt_DelStudentID
            // 
            this.txt_DelStudentID.Location = new System.Drawing.Point(113, 70);
            this.txt_DelStudentID.Name = "txt_DelStudentID";
            this.txt_DelStudentID.Size = new System.Drawing.Size(122, 22);
            this.txt_DelStudentID.TabIndex = 2;
            this.txt_DelStudentID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_StudentID_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(21, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(233, 30);
            this.label7.TabIndex = 1;
            this.label7.Text = "Öğrenci Silme İşlemi";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(13, 167);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(534, 36);
            this.label13.TabIndex = 29;
            this.label13.Text = "Not: Güncellemek istediğiniz öğrencinin listeden üzerine tıklayınız .\r\n \r\n\r\n";
            // 
            // lbl_UPass
            // 
            this.lbl_UPass.AutoSize = true;
            this.lbl_UPass.Font = new System.Drawing.Font("Times New Roman", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbl_UPass.ForeColor = System.Drawing.Color.White;
            this.lbl_UPass.Location = new System.Drawing.Point(534, 53);
            this.lbl_UPass.Name = "lbl_UPass";
            this.lbl_UPass.Size = new System.Drawing.Size(55, 25);
            this.lbl_UPass.TabIndex = 28;
            this.lbl_UPass.Text = "Şifre";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.lbl_USex);
            this.panel3.Controls.Add(this.cBox_USex);
            this.panel3.Controls.Add(this.txt_ULastN);
            this.panel3.Controls.Add(this.btn_Update);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.lbl_UPass);
            this.panel3.Controls.Add(this.lbl_UStudentNo);
            this.panel3.Controls.Add(this.lbl_ULastN);
            this.panel3.Controls.Add(this.lbl_UName);
            this.panel3.Controls.Add(this.txt_UPass);
            this.panel3.Controls.Add(this.txt_UStudentNo);
            this.panel3.Controls.Add(this.txt_UName);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Location = new System.Drawing.Point(332, 364);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(788, 195);
            this.panel3.TabIndex = 64;
            // 
            // lbl_USex
            // 
            this.lbl_USex.AutoSize = true;
            this.lbl_USex.Font = new System.Drawing.Font("Times New Roman", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbl_USex.ForeColor = System.Drawing.Color.White;
            this.lbl_USex.Location = new System.Drawing.Point(678, 53);
            this.lbl_USex.Name = "lbl_USex";
            this.lbl_USex.Size = new System.Drawing.Size(86, 25);
            this.lbl_USex.TabIndex = 52;
            this.lbl_USex.Text = "Cinsiyet";
            // 
            // cBox_USex
            // 
            this.cBox_USex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_USex.FormattingEnabled = true;
            this.cBox_USex.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cBox_USex.Items.AddRange(new object[] {
            "Erkek",
            "Kadın"});
            this.cBox_USex.Location = new System.Drawing.Point(670, 80);
            this.cBox_USex.Name = "cBox_USex";
            this.cBox_USex.Size = new System.Drawing.Size(103, 24);
            this.cBox_USex.TabIndex = 51;
            // 
            // txt_ULastN
            // 
            this.txt_ULastN.Location = new System.Drawing.Point(205, 80);
            this.txt_ULastN.Name = "txt_ULastN";
            this.txt_ULastN.Size = new System.Drawing.Size(100, 22);
            this.txt_ULastN.TabIndex = 49;
            // 
            // btn_Update
            // 
            this.btn_Update.BackColor = System.Drawing.Color.DimGray;
            this.btn_Update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Update.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Update.ForeColor = System.Drawing.Color.White;
            this.btn_Update.Location = new System.Drawing.Point(311, 116);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(117, 32);
            this.btn_Update.TabIndex = 48;
            this.btn_Update.Text = "GÜNCELLE";
            this.btn_Update.UseVisualStyleBackColor = false;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // lbl_UStudentNo
            // 
            this.lbl_UStudentNo.AutoSize = true;
            this.lbl_UStudentNo.Font = new System.Drawing.Font("Times New Roman", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbl_UStudentNo.ForeColor = System.Drawing.Color.White;
            this.lbl_UStudentNo.Location = new System.Drawing.Point(368, 53);
            this.lbl_UStudentNo.Name = "lbl_UStudentNo";
            this.lbl_UStudentNo.Size = new System.Drawing.Size(89, 25);
            this.lbl_UStudentNo.TabIndex = 27;
            this.lbl_UStudentNo.Text = "Okul No";
            // 
            // lbl_ULastN
            // 
            this.lbl_ULastN.AutoSize = true;
            this.lbl_ULastN.Font = new System.Drawing.Font("Times New Roman", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbl_ULastN.ForeColor = System.Drawing.Color.White;
            this.lbl_ULastN.Location = new System.Drawing.Point(224, 53);
            this.lbl_ULastN.Name = "lbl_ULastN";
            this.lbl_ULastN.Size = new System.Drawing.Size(66, 25);
            this.lbl_ULastN.TabIndex = 26;
            this.lbl_ULastN.Text = "Soyad";
            // 
            // lbl_UName
            // 
            this.lbl_UName.AutoSize = true;
            this.lbl_UName.Font = new System.Drawing.Font("Times New Roman", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbl_UName.ForeColor = System.Drawing.Color.White;
            this.lbl_UName.Location = new System.Drawing.Point(80, 53);
            this.lbl_UName.Name = "lbl_UName";
            this.lbl_UName.Size = new System.Drawing.Size(44, 25);
            this.lbl_UName.TabIndex = 19;
            this.lbl_UName.Text = "Ad ";
            // 
            // txt_UPass
            // 
            this.txt_UPass.Location = new System.Drawing.Point(515, 80);
            this.txt_UPass.Name = "txt_UPass";
            this.txt_UPass.Size = new System.Drawing.Size(100, 22);
            this.txt_UPass.TabIndex = 16;
            // 
            // txt_UStudentNo
            // 
            this.txt_UStudentNo.Location = new System.Drawing.Point(360, 80);
            this.txt_UStudentNo.Name = "txt_UStudentNo";
            this.txt_UStudentNo.Size = new System.Drawing.Size(100, 22);
            this.txt_UStudentNo.TabIndex = 15;
            this.txt_UStudentNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_UStudentNo_KeyPress);
            // 
            // txt_UName
            // 
            this.txt_UName.Location = new System.Drawing.Point(55, 80);
            this.txt_UName.Name = "txt_UName";
            this.txt_UName.Size = new System.Drawing.Size(100, 22);
            this.txt_UName.TabIndex = 14;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(260, 12);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(298, 30);
            this.label9.TabIndex = 1;
            this.label9.Text = "Öğrenci Güncelleme İşlemi";
            // 
            // txt_ALastN
            // 
            this.txt_ALastN.Location = new System.Drawing.Point(112, 114);
            this.txt_ALastN.Name = "txt_ALastN";
            this.txt_ALastN.Size = new System.Drawing.Size(122, 22);
            this.txt_ALastN.TabIndex = 47;
            // 
            // lbl_Unsuccess
            // 
            this.lbl_Unsuccess.AutoSize = true;
            this.lbl_Unsuccess.ForeColor = System.Drawing.Color.Red;
            this.lbl_Unsuccess.Location = new System.Drawing.Point(384, 612);
            this.lbl_Unsuccess.Name = "lbl_Unsuccess";
            this.lbl_Unsuccess.Size = new System.Drawing.Size(283, 17);
            this.lbl_Unsuccess.TabIndex = 69;
            this.lbl_Unsuccess.Text = "Yapılan işlemlerde bir sorun meydana geldi.";
            this.lbl_Unsuccess.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lbl_ASex);
            this.panel1.Controls.Add(this.cBox_ASex);
            this.panel1.Controls.Add(this.txt_ALastN);
            this.panel1.Controls.Add(this.btn_Add);
            this.panel1.Controls.Add(this.txt_APass);
            this.panel1.Controls.Add(this.txt_AStudentNu);
            this.panel1.Controls.Add(this.txt_AName);
            this.panel1.Controls.Add(this.lbl_APass);
            this.panel1.Controls.Add(this.lbl_AStudentNo);
            this.panel1.Controls.Add(this.lbl_ALastN);
            this.panel1.Controls.Add(this.lbl_AName);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(9, 77);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(299, 337);
            this.panel1.TabIndex = 62;
            // 
            // lbl_ASex
            // 
            this.lbl_ASex.AutoSize = true;
            this.lbl_ASex.Font = new System.Drawing.Font("Times New Roman", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbl_ASex.ForeColor = System.Drawing.Color.White;
            this.lbl_ASex.Location = new System.Drawing.Point(10, 252);
            this.lbl_ASex.Name = "lbl_ASex";
            this.lbl_ASex.Size = new System.Drawing.Size(93, 25);
            this.lbl_ASex.TabIndex = 50;
            this.lbl_ASex.Text = "Cinsiyet:";
            // 
            // cBox_ASex
            // 
            this.cBox_ASex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_ASex.FormattingEnabled = true;
            this.cBox_ASex.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cBox_ASex.Items.AddRange(new object[] {
            "Erkek",
            "Kadın"});
            this.cBox_ASex.Location = new System.Drawing.Point(112, 252);
            this.cBox_ASex.Name = "cBox_ASex";
            this.cBox_ASex.Size = new System.Drawing.Size(122, 24);
            this.cBox_ASex.TabIndex = 49;
            // 
            // btn_Add
            // 
            this.btn_Add.BackColor = System.Drawing.Color.DimGray;
            this.btn_Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Add.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Add.ForeColor = System.Drawing.Color.White;
            this.btn_Add.Location = new System.Drawing.Point(112, 295);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(75, 32);
            this.btn_Add.TabIndex = 46;
            this.btn_Add.Text = "EKLE";
            this.btn_Add.UseVisualStyleBackColor = false;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // txt_APass
            // 
            this.txt_APass.Location = new System.Drawing.Point(112, 206);
            this.txt_APass.Name = "txt_APass";
            this.txt_APass.Size = new System.Drawing.Size(122, 22);
            this.txt_APass.TabIndex = 9;
            // 
            // txt_AStudentNu
            // 
            this.txt_AStudentNu.Location = new System.Drawing.Point(112, 160);
            this.txt_AStudentNu.Name = "txt_AStudentNu";
            this.txt_AStudentNu.Size = new System.Drawing.Size(122, 22);
            this.txt_AStudentNu.TabIndex = 8;
            this.txt_AStudentNu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_AStudentNu_KeyPress);
            // 
            // txt_AName
            // 
            this.txt_AName.Location = new System.Drawing.Point(112, 68);
            this.txt_AName.Name = "txt_AName";
            this.txt_AName.Size = new System.Drawing.Size(122, 22);
            this.txt_AName.TabIndex = 6;
            // 
            // lbl_APass
            // 
            this.lbl_APass.AutoSize = true;
            this.lbl_APass.Font = new System.Drawing.Font("Times New Roman", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbl_APass.ForeColor = System.Drawing.Color.White;
            this.lbl_APass.Location = new System.Drawing.Point(10, 206);
            this.lbl_APass.Name = "lbl_APass";
            this.lbl_APass.Size = new System.Drawing.Size(62, 25);
            this.lbl_APass.TabIndex = 5;
            this.lbl_APass.Text = "Şifre:";
            // 
            // lbl_AStudentNo
            // 
            this.lbl_AStudentNo.AutoSize = true;
            this.lbl_AStudentNo.Font = new System.Drawing.Font("Times New Roman", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbl_AStudentNo.ForeColor = System.Drawing.Color.White;
            this.lbl_AStudentNo.Location = new System.Drawing.Point(10, 160);
            this.lbl_AStudentNo.Name = "lbl_AStudentNo";
            this.lbl_AStudentNo.Size = new System.Drawing.Size(96, 25);
            this.lbl_AStudentNo.TabIndex = 3;
            this.lbl_AStudentNo.Text = "Okul No:";
            // 
            // lbl_ALastN
            // 
            this.lbl_ALastN.AutoSize = true;
            this.lbl_ALastN.Font = new System.Drawing.Font("Times New Roman", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbl_ALastN.ForeColor = System.Drawing.Color.White;
            this.lbl_ALastN.Location = new System.Drawing.Point(10, 114);
            this.lbl_ALastN.Name = "lbl_ALastN";
            this.lbl_ALastN.Size = new System.Drawing.Size(73, 25);
            this.lbl_ALastN.TabIndex = 2;
            this.lbl_ALastN.Text = "Soyad:";
            // 
            // lbl_AName
            // 
            this.lbl_AName.AutoSize = true;
            this.lbl_AName.Font = new System.Drawing.Font("Times New Roman", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_AName.ForeColor = System.Drawing.Color.White;
            this.lbl_AName.Location = new System.Drawing.Point(10, 68);
            this.lbl_AName.Name = "lbl_AName";
            this.lbl_AName.Size = new System.Drawing.Size(45, 25);
            this.lbl_AName.TabIndex = 1;
            this.lbl_AName.Text = "Ad:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(17, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(253, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "Öğrenci Ekleme İşlemi";
            // 
            // lbl_List
            // 
            this.lbl_List.AutoSize = true;
            this.lbl_List.BackColor = System.Drawing.Color.Transparent;
            this.lbl_List.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbl_List.ForeColor = System.Drawing.Color.White;
            this.lbl_List.Location = new System.Drawing.Point(274, 17);
            this.lbl_List.Name = "lbl_List";
            this.lbl_List.Size = new System.Drawing.Size(202, 34);
            this.lbl_List.TabIndex = 1;
            this.lbl_List.Text = "Öğrenci Listesi";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.Controls.Add(this.dgv_StudentList);
            this.panel4.Controls.Add(this.lbl_List);
            this.panel4.Location = new System.Drawing.Point(332, 77);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(788, 281);
            this.panel4.TabIndex = 65;
            // 
            // dgv_StudentList
            // 
            this.dgv_StudentList.AllowUserToAddRows = false;
            this.dgv_StudentList.AllowUserToDeleteRows = false;
            this.dgv_StudentList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_StudentList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_StudentList.BackgroundColor = System.Drawing.Color.White;
            this.dgv_StudentList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_StudentList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgv_StudentList.Location = new System.Drawing.Point(15, 69);
            this.dgv_StudentList.Name = "dgv_StudentList";
            this.dgv_StudentList.ReadOnly = true;
            this.dgv_StudentList.RowHeadersWidth = 51;
            this.dgv_StudentList.RowTemplate.Height = 24;
            this.dgv_StudentList.Size = new System.Drawing.Size(758, 186);
            this.dgv_StudentList.TabIndex = 2;
            this.dgv_StudentList.SelectionChanged += new System.EventHandler(this.dgv_StudentList_SelectionChanged);
            // 
            // pBox_Exit
            // 
            this.pBox_Exit.BackColor = System.Drawing.Color.Transparent;
            this.pBox_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pBox_Exit.Image = ((System.Drawing.Image)(resources.GetObject("pBox_Exit.Image")));
            this.pBox_Exit.Location = new System.Drawing.Point(1093, 23);
            this.pBox_Exit.Name = "pBox_Exit";
            this.pBox_Exit.Size = new System.Drawing.Size(44, 34);
            this.pBox_Exit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_Exit.TabIndex = 61;
            this.pBox_Exit.TabStop = false;
            this.pBox_Exit.Click += new System.EventHandler(this.pBox_Exit_Click);
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.Transparent;
            this.btn_Back.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Back.BackgroundImage")));
            this.btn_Back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_Back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Back.ForeColor = System.Drawing.Color.DimGray;
            this.btn_Back.ImageKey = "reply.png";
            this.btn_Back.Location = new System.Drawing.Point(15, 23);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(70, 34);
            this.btn_Back.TabIndex = 60;
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // lbl_StudentInfo
            // 
            this.lbl_StudentInfo.AutoSize = true;
            this.lbl_StudentInfo.BackColor = System.Drawing.Color.Transparent;
            this.lbl_StudentInfo.Font = new System.Drawing.Font("Times New Roman", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_StudentInfo.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbl_StudentInfo.Location = new System.Drawing.Point(9, 613);
            this.lbl_StudentInfo.Name = "lbl_StudentInfo";
            this.lbl_StudentInfo.Size = new System.Drawing.Size(191, 17);
            this.lbl_StudentInfo.TabIndex = 67;
            this.lbl_StudentInfo.Text = "| Doğukan Yarar - 182119003 | ";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label14.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label14.Location = new System.Drawing.Point(447, 22);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(307, 32);
            this.label14.TabIndex = 66;
            this.label14.Text = "Öğrenci İşlemleri Sayfası";
            // 
            // lbl_Success
            // 
            this.lbl_Success.AutoSize = true;
            this.lbl_Success.ForeColor = System.Drawing.Color.Lime;
            this.lbl_Success.Location = new System.Drawing.Point(332, 613);
            this.lbl_Success.Name = "lbl_Success";
            this.lbl_Success.Size = new System.Drawing.Size(142, 17);
            this.lbl_Success.TabIndex = 68;
            this.lbl_Success.Text = "Başarıyla sonuçlandı.";
            this.lbl_Success.Visible = false;
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // StudentProcessPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1146, 652);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.lbl_Unsuccess);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.pBox_Exit);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.lbl_StudentInfo);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lbl_Success);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "StudentProcessPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StudentProcessPanel";
            this.Load += new System.EventHandler(this.StudentProcessPanel_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_StudentList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Exit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Label lbl_StudentID;
        private System.Windows.Forms.TextBox txt_DelStudentID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbl_UPass;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbl_USex;
        private System.Windows.Forms.ComboBox cBox_USex;
        private System.Windows.Forms.TextBox txt_ULastN;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.Label lbl_UStudentNo;
        private System.Windows.Forms.Label lbl_ULastN;
        private System.Windows.Forms.Label lbl_UName;
        private System.Windows.Forms.TextBox txt_UPass;
        private System.Windows.Forms.TextBox txt_UStudentNo;
        private System.Windows.Forms.TextBox txt_UName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_ALastN;
        private System.Windows.Forms.Label lbl_Unsuccess;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_ASex;
        private System.Windows.Forms.ComboBox cBox_ASex;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.TextBox txt_APass;
        private System.Windows.Forms.TextBox txt_AStudentNu;
        private System.Windows.Forms.TextBox txt_AName;
        private System.Windows.Forms.Label lbl_APass;
        private System.Windows.Forms.Label lbl_AStudentNo;
        private System.Windows.Forms.Label lbl_ALastN;
        private System.Windows.Forms.Label lbl_AName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_List;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView dgv_StudentList;
        private System.Windows.Forms.PictureBox pBox_Exit;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Label lbl_StudentInfo;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lbl_Success;
        private System.Windows.Forms.Timer timer2;
    }
}
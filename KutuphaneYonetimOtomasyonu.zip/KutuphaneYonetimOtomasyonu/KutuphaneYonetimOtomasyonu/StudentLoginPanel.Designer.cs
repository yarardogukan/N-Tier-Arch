﻿
namespace KutuphaneYonetimOtomasyonu
{
    partial class StudentLoginPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StudentLoginPanel));
            this.lblOgrenci = new System.Windows.Forms.Label();
            this.lbl_StudentInfo = new System.Windows.Forms.Label();
            this.lbl_StudentLoginID = new System.Windows.Forms.Label();
            this.pBox_Exit = new System.Windows.Forms.PictureBox();
            this.cBox_Show = new System.Windows.Forms.CheckBox();
            this.bnt_Back = new System.Windows.Forms.Button();
            this.pBox_ExPic2 = new System.Windows.Forms.PictureBox();
            this.pBox_ExPic1 = new System.Windows.Forms.PictureBox();
            this.btn_StudentLogin = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_StudentPass = new System.Windows.Forms.TextBox();
            this.txt_StudentNu = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Exit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_ExPic2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_ExPic1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblOgrenci
            // 
            this.lblOgrenci.AutoSize = true;
            this.lblOgrenci.BackColor = System.Drawing.Color.Transparent;
            this.lblOgrenci.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lblOgrenci.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.lblOgrenci.Location = new System.Drawing.Point(274, 18);
            this.lblOgrenci.Name = "lblOgrenci";
            this.lblOgrenci.Size = new System.Drawing.Size(180, 32);
            this.lblOgrenci.TabIndex = 58;
            this.lblOgrenci.Text = "Öğrenci Girişi";
            // 
            // lbl_StudentInfo
            // 
            this.lbl_StudentInfo.AutoSize = true;
            this.lbl_StudentInfo.BackColor = System.Drawing.Color.Transparent;
            this.lbl_StudentInfo.Font = new System.Drawing.Font("Times New Roman", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_StudentInfo.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbl_StudentInfo.Location = new System.Drawing.Point(12, 290);
            this.lbl_StudentInfo.Name = "lbl_StudentInfo";
            this.lbl_StudentInfo.Size = new System.Drawing.Size(191, 17);
            this.lbl_StudentInfo.TabIndex = 56;
            this.lbl_StudentInfo.Text = "| Doğukan Yarar - 182119003 | ";
            // 
            // lbl_StudentLoginID
            // 
            this.lbl_StudentLoginID.AutoSize = true;
            this.lbl_StudentLoginID.BackColor = System.Drawing.Color.Transparent;
            this.lbl_StudentLoginID.Location = new System.Drawing.Point(602, 263);
            this.lbl_StudentLoginID.Name = "lbl_StudentLoginID";
            this.lbl_StudentLoginID.Size = new System.Drawing.Size(0, 17);
            this.lbl_StudentLoginID.TabIndex = 55;
            // 
            // pBox_Exit
            // 
            this.pBox_Exit.BackColor = System.Drawing.Color.Transparent;
            this.pBox_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pBox_Exit.Image = ((System.Drawing.Image)(resources.GetObject("pBox_Exit.Image")));
            this.pBox_Exit.Location = new System.Drawing.Point(683, 16);
            this.pBox_Exit.Name = "pBox_Exit";
            this.pBox_Exit.Size = new System.Drawing.Size(44, 34);
            this.pBox_Exit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_Exit.TabIndex = 54;
            this.pBox_Exit.TabStop = false;
            this.pBox_Exit.Click += new System.EventHandler(this.pBox_Exit_Click);
            // 
            // cBox_Show
            // 
            this.cBox_Show.AutoSize = true;
            this.cBox_Show.BackColor = System.Drawing.Color.Transparent;
            this.cBox_Show.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cBox_Show.ForeColor = System.Drawing.Color.White;
            this.cBox_Show.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cBox_Show.Location = new System.Drawing.Point(474, 153);
            this.cBox_Show.Name = "cBox_Show";
            this.cBox_Show.Size = new System.Drawing.Size(79, 21);
            this.cBox_Show.TabIndex = 53;
            this.cBox_Show.Text = "Göster";
            this.cBox_Show.UseVisualStyleBackColor = false;
            this.cBox_Show.CheckedChanged += new System.EventHandler(this.cBox_Show_CheckedChanged);
            // 
            // bnt_Back
            // 
            this.bnt_Back.BackColor = System.Drawing.Color.Transparent;
            this.bnt_Back.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bnt_Back.BackgroundImage")));
            this.bnt_Back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.bnt_Back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bnt_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bnt_Back.ForeColor = System.Drawing.Color.DimGray;
            this.bnt_Back.ImageKey = "reply.png";
            this.bnt_Back.Location = new System.Drawing.Point(12, 16);
            this.bnt_Back.Name = "bnt_Back";
            this.bnt_Back.Size = new System.Drawing.Size(70, 34);
            this.bnt_Back.TabIndex = 52;
            this.bnt_Back.UseVisualStyleBackColor = false;
            this.bnt_Back.Click += new System.EventHandler(this.bnt_Back_Click);
            // 
            // pBox_ExPic2
            // 
            this.pBox_ExPic2.BackColor = System.Drawing.Color.Transparent;
            this.pBox_ExPic2.Image = ((System.Drawing.Image)(resources.GetObject("pBox_ExPic2.Image")));
            this.pBox_ExPic2.Location = new System.Drawing.Point(578, 107);
            this.pBox_ExPic2.Name = "pBox_ExPic2";
            this.pBox_ExPic2.Size = new System.Drawing.Size(128, 128);
            this.pBox_ExPic2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_ExPic2.TabIndex = 51;
            this.pBox_ExPic2.TabStop = false;
            // 
            // pBox_ExPic1
            // 
            this.pBox_ExPic1.BackColor = System.Drawing.Color.Transparent;
            this.pBox_ExPic1.Image = ((System.Drawing.Image)(resources.GetObject("pBox_ExPic1.Image")));
            this.pBox_ExPic1.Location = new System.Drawing.Point(22, 107);
            this.pBox_ExPic1.Name = "pBox_ExPic1";
            this.pBox_ExPic1.Size = new System.Drawing.Size(128, 128);
            this.pBox_ExPic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_ExPic1.TabIndex = 50;
            this.pBox_ExPic1.TabStop = false;
            // 
            // btn_StudentLogin
            // 
            this.btn_StudentLogin.BackColor = System.Drawing.Color.DimGray;
            this.btn_StudentLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_StudentLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_StudentLogin.ForeColor = System.Drawing.Color.White;
            this.btn_StudentLogin.Location = new System.Drawing.Point(334, 195);
            this.btn_StudentLogin.Name = "btn_StudentLogin";
            this.btn_StudentLogin.Size = new System.Drawing.Size(75, 32);
            this.btn_StudentLogin.TabIndex = 49;
            this.btn_StudentLogin.Text = "Giriş";
            this.btn_StudentLogin.UseVisualStyleBackColor = false;
            this.btn_StudentLogin.Click += new System.EventHandler(this.btn_StudentLogin_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(185, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 20);
            this.label2.TabIndex = 48;
            this.label2.Text = "Şifre:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(185, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 20);
            this.label1.TabIndex = 47;
            this.label1.Text = "Öğrenci No:";
            // 
            // txt_StudentPass
            // 
            this.txt_StudentPass.Location = new System.Drawing.Point(347, 152);
            this.txt_StudentPass.Multiline = true;
            this.txt_StudentPass.Name = "txt_StudentPass";
            this.txt_StudentPass.PasswordChar = '*';
            this.txt_StudentPass.Size = new System.Drawing.Size(112, 22);
            this.txt_StudentPass.TabIndex = 46;
            this.txt_StudentPass.Text = "1234";
            // 
            // txt_StudentNu
            // 
            this.txt_StudentNu.Location = new System.Drawing.Point(347, 105);
            this.txt_StudentNu.Name = "txt_StudentNu";
            this.txt_StudentNu.Size = new System.Drawing.Size(112, 22);
            this.txt_StudentNu.TabIndex = 45;
            this.txt_StudentNu.Text = "182119003";
            this.txt_StudentNu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_StudentNu_KeyPress);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // StudentLoginPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(739, 312);
            this.Controls.Add(this.lblOgrenci);
            this.Controls.Add(this.lbl_StudentInfo);
            this.Controls.Add(this.lbl_StudentLoginID);
            this.Controls.Add(this.pBox_Exit);
            this.Controls.Add(this.cBox_Show);
            this.Controls.Add(this.bnt_Back);
            this.Controls.Add(this.pBox_ExPic2);
            this.Controls.Add(this.pBox_ExPic1);
            this.Controls.Add(this.btn_StudentLogin);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_StudentPass);
            this.Controls.Add(this.txt_StudentNu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "StudentLoginPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StudentLoginPanel";
            this.Load += new System.EventHandler(this.StudentLoginPanel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Exit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_ExPic2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_ExPic1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblOgrenci;
        private System.Windows.Forms.Label lbl_StudentInfo;
        private System.Windows.Forms.Label lbl_StudentLoginID;
        private System.Windows.Forms.PictureBox pBox_Exit;
        private System.Windows.Forms.CheckBox cBox_Show;
        private System.Windows.Forms.Button bnt_Back;
        private System.Windows.Forms.PictureBox pBox_ExPic2;
        private System.Windows.Forms.PictureBox pBox_ExPic1;
        private System.Windows.Forms.Button btn_StudentLogin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_StudentPass;
        private System.Windows.Forms.TextBox txt_StudentNu;
        private System.Windows.Forms.Timer timer1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BL;        // BL katmanını kullanacağımız için ekledik.
using ENTITY;   // Entity katmanını kullanacağımız için ekledik.

namespace KutuphaneYonetimOtomasyonu
{
    public partial class StudentProcessPanel : Form
    {
        public StudentProcessPanel()
        {
            InitializeComponent();
        }

        int id;
        string ilk_no;

        #region Fonksiyonlar
        private void UNotNull() // Uygulama açıldığında hata vermemesi için güncelleme panelinde bulunan nesnelere boş değer atadık.
        {
            txt_UName.Text = "";
            txt_ULastN.Text = "";
            txt_UPass.Text = "";
            txt_UStudentNo.Text = "";
            cBox_USex.Text = null;
            id = 0;
        }

        private void txtClear() // Ekleme yaptığımız alanlardaki nesneleri temizlemek için oluşturulan fonksiyon.
        {
            txt_ALastN.Text = "";
            txt_AName.Text = "";
            cBox_ASex.Text = null;
            txt_APass.Text = "";
            txt_AStudentNu.Text = "";
        }
        #endregion

        private void StudentProcessPanel_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;  // Kayan yazı için tanımladığımız timer1 eklentisini, Tick eventi çalıştırmak için çağırdık.
            timer2.Enabled = true;  // Başarılı geridönüşünü belli saniye ekranda tutmak için tanımladığımız timer2 eklentisini, Tick eventi çalıştırmak için çağırdık.

            dgv_StudentList.DataSource = StudentBL.studentList(); // Form açıldığında datagrid üzerine veritabanındaki listeyi aktardık.

            // Tablodaki görünümü iyileştirmek için tablo başlıklarını düzenledik.
            dgv_StudentList.Columns[0].HeaderText = "ID";
            dgv_StudentList.Columns[1].HeaderText = "Adı";
            dgv_StudentList.Columns[2].HeaderText = "Soyadı";
            dgv_StudentList.Columns[3].HeaderText = "Okul Numarası";
            dgv_StudentList.Columns[4].HeaderText = "Şifresi";
            dgv_StudentList.Columns[5].HeaderText = "Cinsiyeti";
            dgv_StudentList.Columns[6].HeaderText = "Cezası";

            // Form açıldığında guncelleme kısmındaki textboxların ve gunceleme için gerekli id nin boş kalmasını  sağladık.
            UNotNull();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            AdminCheckPanel adminCP = new AdminCheckPanel();     // Gidilecek forma geçmek için bir değişken (adminCP) oluşturduk.
            this.Hide();                                         // şu anki sayfasının kapatılmasını sağladık.
            adminCP.Show();                                      // Oluşturulan değişken formuna gidilmesini sağladık.
        }

        private void pBox_Exit_Click(object sender, EventArgs e)
        {
            DialogResult dialog = new DialogResult();           // Bir dialogResult tanımlayarak kullanıcı çıkış yapmak istediğinde soru sordurulmasını tanımladık.
            dialog = MessageBox.Show("Gerçekten çıkmak istiyor musunuz?", "ÇIKIŞ", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);    // Hata mesajını burada verdirttik.
            if (dialog == DialogResult.Yes) // Eğer "Evet" e tıklarsa uygulamadan çıkmasını sağladık. 
            {
                Application.Exit();
            }
            else    // Eğer "Hayır" a tıklarsa uygulama da olduğu yerden devam etmesini sağladık.
            {
                return;
            }
        }

        #region CRUD işlemleri
        private void btn_Add_Click(object sender, EventArgs e)      // "EKLE" Butonuna tıklanıldığında yapılacaklar;
        {
            //Ekleme işlemi için textboxların dolu olup olmadığını kontrol ettik
            if (txt_AName.Text != "" && txt_ALastN.Text != "" && txt_AStudentNu.Text != "" && txt_APass.Text != "" && cBox_ASex.Text != "")
            {
                //Entity katmanındaki değişkenlere textboxtaki verileri aktardık
                StudentData student= new StudentData()
                {
                    StudentName = txt_AName.Text,
                    StudentLastN = txt_ALastN.Text,
                    StudentNu = txt_AStudentNu.Text,
                    StudentPass = txt_APass.Text,
                    StudentSex = cBox_ASex.Text
                };
                if (StudentBL.checkStudentNu(student) == true)  // Öğrencinin kayıtlı olma durumu kontrol edildi
                {

                    StudentBL.addStudent(student);  //business katmanındaki ogrenciEkle fonksiyonuna verileri gönderdik
                    lbl_Success.Visible = true;     // Label'ın görünürlüğünü aktif ettik.
                    timer2.Start();                 // Belli bir süre görünmesi için timer2 yi aktif ettik.
                    dgv_StudentList.DataSource = StudentBL.studentList(); // Ekleme işlemi yapıldıktan sonra tablonun güncel halini kullanıcıya yansıttık.

                }

                else
                {
                    MessageBox.Show("Girilen okul numarasına ait farklı bir öğrenci mevcut, lütfen girilen okul numarasını değiştiriniz!"); // false değer dönerse hata verdirttik
                }

                //Ekleme işlemi bitince textboxları temizledik
                txtClear();

            }

            else
            {
                MessageBox.Show("Lütfen gerekli alanları doldurunuz!"); // Araçlar boş kaldığı için ekrana hata yansıttık.
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)   // "SİL" butonuna tıklanıldığında
        {
            
            if (txt_DelStudentID.Text != "")        // ID numarası girilip, silme işlemi yapan textbox'ın boş olup olmadığı kontrol edildi.
            {
                //Entity katmanındaki OgrenciId değişkenine textboxtaki veriyi aktardık
                StudentData student= new StudentData()
                {
                    StudentID = int.Parse(txt_DelStudentID.Text)
                };

                // Girilen ID numarasına göre, öğrencinin var olma durumu kontrol edildi.

                if (StudentBL.queryStudent_BL(student) == true) // Girilen ID numarasına dair öğrenci var mı diye kontrol edildi.
                {
                    StudentBL.deleteStudent(student); // BL katmanındaki deleteStudent fonksiyonuna silme işlemi için verileri gönderdik.
                    lbl_Success.Visible = true;     // Başarılı yazısını kullanıcıya gösteriyoruz.
                    timer2.Start();                 // Yazının 5 saniye kalmasını sağlayan timer eklentisini başlattık.
                    dgv_StudentList.DataSource = StudentBL.studentList(); // Silme işlemi yapıldıktan sonra tablonun güncel halini kullanıcıya yansıttık.
                    txt_DelStudentID.Text = ""; // Silme işleminden sonra textbox ı temizledik
                }

                else
                    MessageBox.Show("Bu ID numarasıyla eşleşen bir kayıt bulunamadı!"); // Kayıt olmadığında kullanıcıya hata verdik.
            }
            else
                MessageBox.Show("Lütfen gerekli alanları doldurunuz!"); // araç kutuları boş bırakıldığında hata yansıttık.
        }

        private void btn_Update_Click(object sender, EventArgs e) // "GÜNCELLE" butonuna tıklanıldığında
        {
            //Güncelleme işlemi için textboxların dolu olup olmadığını kontrol ettik

            if (txt_UName.Text != "" && txt_ULastN.Text != "" && txt_UStudentNo.Text != "" && txt_UPass.Text != "" && cBox_USex.Text != "")
            {
                //Entity katmanındaki değişkenlere textboxtaki verileri aktardık
                StudentData student= new StudentData()
                {
                    StudentName = txt_UName.Text,
                    StudentLastN = txt_ULastN.Text,
                    StudentNu = txt_UStudentNo.Text,
                    StudentPass = txt_UPass.Text,
                    StudentSex = cBox_USex.Text,
                    StudentID = id
                };

                // Girilen ID numarasına göre, öğrencinin var olma durumu kontrol edildi.
                if (StudentBL.queryStudent_BL(student) == true)
                {
                    if (StudentBL.checkStudentNu(student) == true || ilk_no == student.StudentNu.ToString()) // Öğrencinin numarasının kayıtlı olması durumu kontrol edildi ve ilkno değişkenine gelen öğrenci numarası kaydedildi.
                    {
                        StudentBL.updateStudent(student); // Business katmanındaki ogrenciGuncelle Fonksiyonuna guncelleme işlemi için verileri gönderdik
                        lbl_Success.Visible = true;         // Başarılı yazısını kullanıcıya gösteriyoruz.
                        timer2.Start();                  // Yazının 5 saniye kalmasını sağlayan timer eklentisini başlattık.
                        dgv_StudentList.DataSource = StudentBL.studentList(); // Güncelleme işlemi yapıldıktan sonra tablonun güncel halini kullanıcıya yansıttık.
                        UNotNull();                                         //Güncelleme işlemi bitince textboxları temizledik.
                    }
                    else
                    {
                        MessageBox.Show("Bu Okul Numarasına sahip bir öğrenci mevcut. Lütfen okul numarasını değiştiriniz!");   // Eğer okul numarası eşleşiyorsa hata verdirttik.
                    }
                }

                else
                    MessageBox.Show("Lütfen listeden seçim yaptıktan sonra değerleri doldurunuz!"); // Datagrid nesnesi üzerinden tıklama yapılmadan güncelleme işlemi yapılmıyor, bu sebepten ötürü tıklanılma yapmadan işlem yapıldığında hata verdirttik.
            }

            else
            {
                MessageBox.Show("Lütfen gerekli alanları doldurunuz!"); // Araç kutuları boş bırakılamaz.
            }
        }
        #endregion

        #region KeyPress Eventleri 

        // Bazı textboxların içine harf girişini engelleyerek çakışma olmamasını sağladık.
        private void txt_AStudentNu_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txt_StudentID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txt_UStudentNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        #endregion
        private void dgv_StudentList_SelectionChanged(object sender, EventArgs e)
        {
            //Tablo üzerinde tıklanan satırın verilerini guncelleme alanındaki textboxlara yazdırdık.

            id = int.Parse(dgv_StudentList.CurrentRow.Cells[0].Value.ToString());
            txt_UName.Text = dgv_StudentList.CurrentRow.Cells[1].Value.ToString();
            txt_ULastN.Text = dgv_StudentList.CurrentRow.Cells[2].Value.ToString();
            txt_UStudentNo.Text = dgv_StudentList.CurrentRow.Cells[3].Value.ToString();
            txt_UPass.Text = dgv_StudentList.CurrentRow.Cells[4].Value.ToString();
            cBox_USex.Text = dgv_StudentList.CurrentRow.Cells[5].Value.ToString();
            ilk_no = txt_UStudentNo.Text;
        }

        int timerAnno = 0;  // Başarılı ya da başarısız labellarının sürekli ekranda kalmamasını sağlamak için timer a değişken tanımladık.  
        private void timer2_Tick(object sender, EventArgs e)    // Kullancının başarılı yazısını ekranda 5 saniye durmasını sağlayan kod.
        {
            timerAnno++;
            if (timerAnno == 5)
            {
                timer2.Stop();
                lbl_Success.Visible = false;
            }
        }

        private void timer1_Tick(object sender, EventArgs e) // Kayan yazı nesnesi oluşturduk.
        {
            lbl_StudentInfo.Text = lbl_StudentInfo.Text.Substring(1) + lbl_StudentInfo.Text.Substring(0, 1); // Substring metodu ile label'a yazdığımız değerin timer ile döndürüyoruz.
        }
    }
}

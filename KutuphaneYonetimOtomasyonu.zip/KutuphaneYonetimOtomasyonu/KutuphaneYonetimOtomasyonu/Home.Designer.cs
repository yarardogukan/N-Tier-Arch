﻿
namespace KutuphaneYonetimOtomasyonu
{
    partial class Home
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.pBox_Cikis = new System.Windows.Forms.PictureBox();
            this.btn_AdminLogin = new System.Windows.Forms.Button();
            this.lbl_Student = new System.Windows.Forms.Label();
            this.lbl_Admin = new System.Windows.Forms.Label();
            this.pBox_Student = new System.Windows.Forms.PictureBox();
            this.pBox_Admin = new System.Windows.Forms.PictureBox();
            this.lbl_StudentInfo = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_StudentLogin = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Cikis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Student)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Admin)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pBox_Cikis
            // 
            this.pBox_Cikis.BackColor = System.Drawing.Color.Transparent;
            this.pBox_Cikis.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pBox_Cikis.Image = ((System.Drawing.Image)(resources.GetObject("pBox_Cikis.Image")));
            this.pBox_Cikis.Location = new System.Drawing.Point(683, 17);
            this.pBox_Cikis.Name = "pBox_Cikis";
            this.pBox_Cikis.Size = new System.Drawing.Size(44, 34);
            this.pBox_Cikis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_Cikis.TabIndex = 30;
            this.pBox_Cikis.TabStop = false;
            this.pBox_Cikis.Click += new System.EventHandler(this.pBox_Cikis_Click);
            // 
            // btn_AdminLogin
            // 
            this.btn_AdminLogin.BackColor = System.Drawing.Color.DimGray;
            this.btn_AdminLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_AdminLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AdminLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_AdminLogin.ForeColor = System.Drawing.Color.White;
            this.btn_AdminLogin.Location = new System.Drawing.Point(198, 93);
            this.btn_AdminLogin.Name = "btn_AdminLogin";
            this.btn_AdminLogin.Size = new System.Drawing.Size(75, 32);
            this.btn_AdminLogin.TabIndex = 22;
            this.btn_AdminLogin.Text = "Giriş";
            this.btn_AdminLogin.UseVisualStyleBackColor = false;
            this.btn_AdminLogin.Click += new System.EventHandler(this.btn_AdminLogin_Click);
            // 
            // lbl_Student
            // 
            this.lbl_Student.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_Student.AutoSize = true;
            this.lbl_Student.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Student.Cursor = System.Windows.Forms.Cursors.Help;
            this.lbl_Student.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_Student.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lbl_Student.Location = new System.Drawing.Point(193, 14);
            this.lbl_Student.Name = "lbl_Student";
            this.lbl_Student.Size = new System.Drawing.Size(106, 29);
            this.lbl_Student.TabIndex = 20;
            this.lbl_Student.Text = "Öğrenci";
            // 
            // lbl_Admin
            // 
            this.lbl_Admin.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbl_Admin.AutoSize = true;
            this.lbl_Admin.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Admin.Cursor = System.Windows.Forms.Cursors.Help;
            this.lbl_Admin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_Admin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lbl_Admin.Location = new System.Drawing.Point(181, 14);
            this.lbl_Admin.Name = "lbl_Admin";
            this.lbl_Admin.Size = new System.Drawing.Size(118, 29);
            this.lbl_Admin.TabIndex = 19;
            this.lbl_Admin.Text = "Personel";
            // 
            // pBox_Student
            // 
            this.pBox_Student.BackColor = System.Drawing.Color.Transparent;
            this.pBox_Student.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pBox_Student.Image = ((System.Drawing.Image)(resources.GetObject("pBox_Student.Image")));
            this.pBox_Student.Location = new System.Drawing.Point(16, 10);
            this.pBox_Student.Name = "pBox_Student";
            this.pBox_Student.Size = new System.Drawing.Size(128, 128);
            this.pBox_Student.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Student.TabIndex = 18;
            this.pBox_Student.TabStop = false;
            this.pBox_Student.Click += new System.EventHandler(this.pBox_Student_Click);
            // 
            // pBox_Admin
            // 
            this.pBox_Admin.BackColor = System.Drawing.Color.Transparent;
            this.pBox_Admin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pBox_Admin.Image = ((System.Drawing.Image)(resources.GetObject("pBox_Admin.Image")));
            this.pBox_Admin.Location = new System.Drawing.Point(15, 10);
            this.pBox_Admin.Name = "pBox_Admin";
            this.pBox_Admin.Size = new System.Drawing.Size(128, 128);
            this.pBox_Admin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Admin.TabIndex = 17;
            this.pBox_Admin.TabStop = false;
            this.pBox_Admin.Click += new System.EventHandler(this.pBox_Admin_Click);
            // 
            // lbl_StudentInfo
            // 
            this.lbl_StudentInfo.AutoSize = true;
            this.lbl_StudentInfo.BackColor = System.Drawing.Color.Transparent;
            this.lbl_StudentInfo.Font = new System.Drawing.Font("Times New Roman", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_StudentInfo.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbl_StudentInfo.Location = new System.Drawing.Point(12, 281);
            this.lbl_StudentInfo.Name = "lbl_StudentInfo";
            this.lbl_StudentInfo.Size = new System.Drawing.Size(191, 17);
            this.lbl_StudentInfo.TabIndex = 32;
            this.lbl_StudentInfo.Text = "| Doğukan Yarar - 182119003 | ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label4.Location = new System.Drawing.Point(92, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(255, 32);
            this.label4.TabIndex = 31;
            this.label4.Text = "Merkez Kütüphanesi";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label1.Location = new System.Drawing.Point(12, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(229, 32);
            this.label1.TabIndex = 29;
            this.label1.Text = "Düzce Üniversitesi";
            // 
            // btn_StudentLogin
            // 
            this.btn_StudentLogin.BackColor = System.Drawing.Color.DimGray;
            this.btn_StudentLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_StudentLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_StudentLogin.ForeColor = System.Drawing.Color.White;
            this.btn_StudentLogin.Location = new System.Drawing.Point(213, 93);
            this.btn_StudentLogin.Name = "btn_StudentLogin";
            this.btn_StudentLogin.Size = new System.Drawing.Size(75, 32);
            this.btn_StudentLogin.TabIndex = 26;
            this.btn_StudentLogin.Text = "Giriş";
            this.btn_StudentLogin.UseVisualStyleBackColor = false;
            this.btn_StudentLogin.Click += new System.EventHandler(this.btn_StudentLogin_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.pBox_Student);
            this.panel2.Controls.Add(this.lbl_Student);
            this.panel2.Controls.Add(this.btn_StudentLogin);
            this.panel2.Location = new System.Drawing.Point(364, 86);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(348, 157);
            this.panel2.TabIndex = 34;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Cursor = System.Windows.Forms.Cursors.Help;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label3.Location = new System.Drawing.Point(213, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 29);
            this.label3.TabIndex = 27;
            this.label3.Text = "Girişi";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pBox_Admin);
            this.panel1.Controls.Add(this.lbl_Admin);
            this.panel1.Controls.Add(this.btn_AdminLogin);
            this.panel1.Location = new System.Drawing.Point(13, 86);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(334, 157);
            this.panel1.TabIndex = 33;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Cursor = System.Windows.Forms.Cursors.Help;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label2.Location = new System.Drawing.Point(198, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 29);
            this.label2.TabIndex = 23;
            this.label2.Text = "Girişi";
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(739, 312);
            this.Controls.Add(this.pBox_Cikis);
            this.Controls.Add(this.lbl_StudentInfo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Home_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Cikis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Student)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Admin)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pBox_Cikis;
        private System.Windows.Forms.Button btn_AdminLogin;
        private System.Windows.Forms.Label lbl_Student;
        private System.Windows.Forms.Label lbl_Admin;
        private System.Windows.Forms.PictureBox pBox_Student;
        private System.Windows.Forms.PictureBox pBox_Admin;
        private System.Windows.Forms.Label lbl_StudentInfo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_StudentLogin;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}


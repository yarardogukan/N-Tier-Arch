﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KutuphaneYonetimOtomasyonu
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void btn_AdminLogin_Click(object sender, EventArgs e)
        {
            AdminLoginPanel paL = new AdminLoginPanel();                           // Gidilecek forma geçmek için bir değişken (paL) oluşturduk.
            this.Hide();                                                          // Home sayfasının kapatılmasını sağladık.
            paL.Show();                                                          // Oluşturulan değişken formuna gidilmesini sağladık.
        }

        private void btn_StudentLogin_Click(object sender, EventArgs e)
        {
            StudentLoginPanel psL = new StudentLoginPanel();                       // Gidilecek forma geçmek için bir değişken (psL) oluşturduk.
            this.Hide();                                                           // Home sayfasının kapatılmasını sağladık.
            psL.Show();                                                          // Oluşturulan değişken formuna gidilmesini sağladık.
        }

        private void pBox_Admin_Click(object sender, EventArgs e)
        {
            AdminLoginPanel paL = new AdminLoginPanel();                           // Gidilecek forma geçmek için bir değişken (paL) oluşturduk.
            this.Hide();                                                          // Home sayfasının kapatılmasını sağladık.
            paL.Show();                                                          // Oluşturulan değişken formuna gidilmesini sağladık.
        }

        private void pBox_Student_Click(object sender, EventArgs e)
        {
            StudentLoginPanel psL = new StudentLoginPanel();                       // Gidilecek forma geçmek için bir değişken (psL) oluşturduk.
            this.Hide();                                                           // Home sayfasının kapatılmasını sağladık.
            psL.Show();                                                          // Oluşturulan değişken formuna gidilmesini sağladık.
        }

        private void pBox_Cikis_Click(object sender, EventArgs e)
        {
            DialogResult dialog = new DialogResult();   // Kullanıcı uygulamadan çıkmadan önce bir "Evet-Hayır" dialog nesnesiyle karşılaşacaktır.
            dialog = MessageBox.Show("Gerçekten çıkmak istiyor musunuz?", "ÇIKIŞ", MessageBoxButtons.YesNo, MessageBoxIcon.Warning); // MsgBox.Show metodunu dialog nesnesiyle birlikte kullandık.
            if (dialog == DialogResult.Yes) // Eğer sonuç evet ise uygulamadan çıkmasını sağladık
            {
                Application.Exit();
            }
            else    // Eğer cevap hayır ise kulanıcının proje de devam etmesini sağladık.
            {
                return;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_StudentInfo.Text = lbl_StudentInfo.Text.Substring(1) + lbl_StudentInfo.Text.Substring(0, 1); // Substring metodu ile label'a yazdığımız değerin timer ile döndürüyoruz.
        }

        private void Home_Load(object sender, EventArgs e)
        {

            timer1.Enabled = true; // label'da kayan yazı oluşturmak için timer'ı başlattık.

            ToolTip aciklama = new ToolTip();   // Nesnenin üzerine geldiğinde bir konuşma balonu tarzında kullanıcıya, bu işlemin ne yaptığına dair bilgi veren ToolTip nesnesini oluşturuyoruz.
            aciklama.IsBalloon = true;      // Konuşma balonu tarzında daha şık görünmesini sağlıyoruz.
            aciklama.ToolTipIcon = ToolTipIcon.Info;    // Balondaki, ikonu seçiyoruz.
            aciklama.ToolTipTitle = "Dikkat!";  // Balonun, ana başlığını belirliyoruz.
            aciklama.SetToolTip(lbl_Admin, "Görevli işlemlerinin olduğu kısımdır. Görsele ya da butona tıklayınız."); // Üzerine gelindiğinde verilecek mesajı yazıyoruz.
            aciklama.SetToolTip(lbl_Student, "Öğrenci işlemlerinin olduğu kısımdır. Görsele ya da butona tıklayınız."); // Üzerine gelindiğinde verilecek mesajı yazıyoruz.
        }
    }
}

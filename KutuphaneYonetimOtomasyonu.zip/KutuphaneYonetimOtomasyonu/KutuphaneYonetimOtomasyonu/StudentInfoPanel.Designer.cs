﻿
namespace KutuphaneYonetimOtomasyonu
{
    partial class StudentInfoPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StudentInfoPanel));
            this.label15 = new System.Windows.Forms.Label();
            this.cBox_PurchaseBook = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lbl_Unsuccess = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pBox_FindBook = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.lbl_Success = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_PickUp = new System.Windows.Forms.Button();
            this.dTP_PurchaseBook = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pBox_BookGraphics = new System.Windows.Forms.PictureBox();
            this.lbl_Student = new System.Windows.Forms.Label();
            this.lbl_StudentInfo = new System.Windows.Forms.Label();
            this.lbl_IDStudentInfo = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbl_InfoSusp = new System.Windows.Forms.Label();
            this.lbl_InfoSex = new System.Windows.Forms.Label();
            this.lbl_InfoPass = new System.Windows.Forms.Label();
            this.lbl_InfoStudentNu = new System.Windows.Forms.Label();
            this.lbl_InfoLastN = new System.Windows.Forms.Label();
            this.lbl_InfoName = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btn_GiveUp = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.dTP_DeliverBook = new System.Windows.Forms.DateTimePicker();
            this.cBox_DeliverBook = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_Punishment = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_PayPunishment = new System.Windows.Forms.Button();
            this.txt_Punishment = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dgv_BookPDList = new System.Windows.Forms.DataGridView();
            this.lblListe = new System.Windows.Forms.Label();
            this.pBox_Exit = new System.Windows.Forms.PictureBox();
            this.btn_Back = new System.Windows.Forms.Button();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pBox_FindBook)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_BookGraphics)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_BookPDList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Exit)).BeginInit();
            this.SuspendLayout();
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(280, 83);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(90, 22);
            this.label15.TabIndex = 60;
            this.label15.Text = "Kitap Ara";
            // 
            // cBox_PurchaseBook
            // 
            this.cBox_PurchaseBook.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_PurchaseBook.FormattingEnabled = true;
            this.cBox_PurchaseBook.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cBox_PurchaseBook.Location = new System.Drawing.Point(179, 70);
            this.cBox_PurchaseBook.Name = "cBox_PurchaseBook";
            this.cBox_PurchaseBook.Size = new System.Drawing.Size(131, 24);
            this.cBox_PurchaseBook.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(55, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(238, 25);
            this.label6.TabIndex = 0;
            this.label6.Text = "KİTAP TESLİM İŞLEMİ";
            // 
            // lbl_Unsuccess
            // 
            this.lbl_Unsuccess.AutoSize = true;
            this.lbl_Unsuccess.ForeColor = System.Drawing.Color.Red;
            this.lbl_Unsuccess.Location = new System.Drawing.Point(80, 614);
            this.lbl_Unsuccess.Name = "lbl_Unsuccess";
            this.lbl_Unsuccess.Size = new System.Drawing.Size(283, 17);
            this.lbl_Unsuccess.TabIndex = 103;
            this.lbl_Unsuccess.Text = "Yapılan işlemlerde bir sorun meydana geldi.";
            this.lbl_Unsuccess.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(13, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 22);
            this.label2.TabIndex = 14;
            this.label2.Text = "Alım Tarihi :";
            // 
            // pBox_FindBook
            // 
            this.pBox_FindBook.BackColor = System.Drawing.Color.Transparent;
            this.pBox_FindBook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pBox_FindBook.Image = ((System.Drawing.Image)(resources.GetObject("pBox_FindBook.Image")));
            this.pBox_FindBook.Location = new System.Drawing.Point(274, 11);
            this.pBox_FindBook.Name = "pBox_FindBook";
            this.pBox_FindBook.Size = new System.Drawing.Size(100, 67);
            this.pBox_FindBook.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_FindBook.TabIndex = 59;
            this.pBox_FindBook.TabStop = false;
            this.pBox_FindBook.Click += new System.EventHandler(this.pBox_FindBook_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(91, 85);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 22);
            this.label17.TabIndex = 62;
            this.label17.Text = "Grafik";
            // 
            // lbl_Success
            // 
            this.lbl_Success.AutoSize = true;
            this.lbl_Success.ForeColor = System.Drawing.Color.Lime;
            this.lbl_Success.Location = new System.Drawing.Point(28, 615);
            this.lbl_Success.Name = "lbl_Success";
            this.lbl_Success.Size = new System.Drawing.Size(142, 17);
            this.lbl_Success.TabIndex = 102;
            this.lbl_Success.Text = "Başarıyla sonuçlandı.";
            this.lbl_Success.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btn_PickUp);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.dTP_PurchaseBook);
            this.panel1.Controls.Add(this.cBox_PurchaseBook);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(374, 315);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(329, 202);
            this.panel1.TabIndex = 94;
            // 
            // btn_PickUp
            // 
            this.btn_PickUp.BackColor = System.Drawing.Color.DimGray;
            this.btn_PickUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_PickUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_PickUp.ForeColor = System.Drawing.Color.White;
            this.btn_PickUp.Location = new System.Drawing.Point(100, 149);
            this.btn_PickUp.Name = "btn_PickUp";
            this.btn_PickUp.Size = new System.Drawing.Size(116, 32);
            this.btn_PickUp.TabIndex = 86;
            this.btn_PickUp.Text = "AL";
            this.btn_PickUp.UseVisualStyleBackColor = false;
            this.btn_PickUp.Click += new System.EventHandler(this.btn_PickUp_Click);
            // 
            // dTP_PurchaseBook
            // 
            this.dTP_PurchaseBook.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dTP_PurchaseBook.Location = new System.Drawing.Point(179, 117);
            this.dTP_PurchaseBook.Name = "dTP_PurchaseBook";
            this.dTP_PurchaseBook.Size = new System.Drawing.Size(128, 22);
            this.dTP_PurchaseBook.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(13, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 22);
            this.label5.TabIndex = 4;
            this.label5.Text = "Alınabilir Kitap :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(55, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "KİTAP ALMA İŞLEMİ";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.pBox_FindBook);
            this.panel6.Controls.Add(this.label15);
            this.panel6.Controls.Add(this.pBox_BookGraphics);
            this.panel6.Controls.Add(this.label17);
            this.panel6.Location = new System.Drawing.Point(465, 523);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(428, 117);
            this.panel6.TabIndex = 101;
            // 
            // pBox_BookGraphics
            // 
            this.pBox_BookGraphics.BackColor = System.Drawing.Color.Transparent;
            this.pBox_BookGraphics.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pBox_BookGraphics.Image = ((System.Drawing.Image)(resources.GetObject("pBox_BookGraphics.Image")));
            this.pBox_BookGraphics.Location = new System.Drawing.Point(72, 11);
            this.pBox_BookGraphics.Name = "pBox_BookGraphics";
            this.pBox_BookGraphics.Size = new System.Drawing.Size(100, 67);
            this.pBox_BookGraphics.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_BookGraphics.TabIndex = 61;
            this.pBox_BookGraphics.TabStop = false;
            this.pBox_BookGraphics.Click += new System.EventHandler(this.pBox_BookGraphics_Click);
            // 
            // lbl_Student
            // 
            this.lbl_Student.AutoSize = true;
            this.lbl_Student.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Student.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbl_Student.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.lbl_Student.Location = new System.Drawing.Point(436, 14);
            this.lbl_Student.Name = "lbl_Student";
            this.lbl_Student.Size = new System.Drawing.Size(213, 32);
            this.lbl_Student.TabIndex = 100;
            this.lbl_Student.Text = "Hoşgeldin, Name";
            // 
            // lbl_StudentInfo
            // 
            this.lbl_StudentInfo.AutoSize = true;
            this.lbl_StudentInfo.BackColor = System.Drawing.Color.Transparent;
            this.lbl_StudentInfo.Font = new System.Drawing.Font("Times New Roman", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_StudentInfo.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbl_StudentInfo.Location = new System.Drawing.Point(24, 585);
            this.lbl_StudentInfo.Name = "lbl_StudentInfo";
            this.lbl_StudentInfo.Size = new System.Drawing.Size(191, 17);
            this.lbl_StudentInfo.TabIndex = 99;
            this.lbl_StudentInfo.Text = "| Doğukan Yarar - 182119003 | ";
            // 
            // lbl_IDStudentInfo
            // 
            this.lbl_IDStudentInfo.AutoSize = true;
            this.lbl_IDStudentInfo.BackColor = System.Drawing.Color.Transparent;
            this.lbl_IDStudentInfo.ForeColor = System.Drawing.Color.White;
            this.lbl_IDStudentInfo.Location = new System.Drawing.Point(1019, 609);
            this.lbl_IDStudentInfo.Name = "lbl_IDStudentInfo";
            this.lbl_IDStudentInfo.Size = new System.Drawing.Size(115, 17);
            this.lbl_IDStudentInfo.TabIndex = 97;
            this.lbl_IDStudentInfo.Text = "lbl_IDStudentInfo";
            this.lbl_IDStudentInfo.Visible = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.lbl_InfoSusp);
            this.panel4.Controls.Add(this.lbl_InfoSex);
            this.panel4.Controls.Add(this.lbl_InfoPass);
            this.panel4.Controls.Add(this.lbl_InfoStudentNu);
            this.panel4.Controls.Add(this.lbl_InfoLastN);
            this.panel4.Controls.Add(this.lbl_InfoName);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Location = new System.Drawing.Point(12, 79);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(270, 288);
            this.panel4.TabIndex = 96;
            // 
            // lbl_InfoSusp
            // 
            this.lbl_InfoSusp.AutoSize = true;
            this.lbl_InfoSusp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_InfoSusp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl_InfoSusp.Location = new System.Drawing.Point(155, 247);
            this.lbl_InfoSusp.Name = "lbl_InfoSusp";
            this.lbl_InfoSusp.Size = new System.Drawing.Size(47, 18);
            this.lbl_InfoSusp.TabIndex = 13;
            this.lbl_InfoSusp.Text = "Ceza";
            // 
            // lbl_InfoSex
            // 
            this.lbl_InfoSex.AutoSize = true;
            this.lbl_InfoSex.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_InfoSex.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl_InfoSex.Location = new System.Drawing.Point(155, 205);
            this.lbl_InfoSex.Name = "lbl_InfoSex";
            this.lbl_InfoSex.Size = new System.Drawing.Size(68, 18);
            this.lbl_InfoSex.TabIndex = 12;
            this.lbl_InfoSex.Text = "Cinsiyet";
            // 
            // lbl_InfoPass
            // 
            this.lbl_InfoPass.AutoSize = true;
            this.lbl_InfoPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_InfoPass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl_InfoPass.Location = new System.Drawing.Point(155, 169);
            this.lbl_InfoPass.Name = "lbl_InfoPass";
            this.lbl_InfoPass.Size = new System.Drawing.Size(43, 18);
            this.lbl_InfoPass.TabIndex = 11;
            this.lbl_InfoPass.Text = "Şifre";
            // 
            // lbl_InfoStudentNu
            // 
            this.lbl_InfoStudentNu.AutoSize = true;
            this.lbl_InfoStudentNu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_InfoStudentNu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl_InfoStudentNu.Location = new System.Drawing.Point(155, 133);
            this.lbl_InfoStudentNu.Name = "lbl_InfoStudentNu";
            this.lbl_InfoStudentNu.Size = new System.Drawing.Size(30, 18);
            this.lbl_InfoStudentNu.TabIndex = 10;
            this.lbl_InfoStudentNu.Text = "No";
            // 
            // lbl_InfoLastN
            // 
            this.lbl_InfoLastN.AutoSize = true;
            this.lbl_InfoLastN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_InfoLastN.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl_InfoLastN.Location = new System.Drawing.Point(155, 98);
            this.lbl_InfoLastN.Name = "lbl_InfoLastN";
            this.lbl_InfoLastN.Size = new System.Drawing.Size(55, 18);
            this.lbl_InfoLastN.TabIndex = 9;
            this.lbl_InfoLastN.Text = "Soyad";
            // 
            // lbl_InfoName
            // 
            this.lbl_InfoName.AutoSize = true;
            this.lbl_InfoName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_InfoName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl_InfoName.Location = new System.Drawing.Point(155, 57);
            this.lbl_InfoName.Name = "lbl_InfoName";
            this.lbl_InfoName.Size = new System.Drawing.Size(27, 18);
            this.lbl_InfoName.TabIndex = 8;
            this.lbl_InfoName.Text = "Ad";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.FloralWhite;
            this.label14.Location = new System.Drawing.Point(49, 247);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 22);
            this.label14.TabIndex = 7;
            this.label14.Text = "Ceza :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.FloralWhite;
            this.label13.Location = new System.Drawing.Point(49, 205);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(86, 22);
            this.label13.TabIndex = 6;
            this.label13.Text = "Cinsiyet :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.FloralWhite;
            this.label12.Location = new System.Drawing.Point(49, 169);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(59, 22);
            this.label12.TabIndex = 5;
            this.label12.Text = "Şifre :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.FloralWhite;
            this.label11.Location = new System.Drawing.Point(49, 133);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 22);
            this.label11.TabIndex = 4;
            this.label11.Text = "No :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.FloralWhite;
            this.label10.Location = new System.Drawing.Point(49, 98);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 22);
            this.label10.TabIndex = 3;
            this.label10.Text = "Soyad :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.FloralWhite;
            this.label9.Location = new System.Drawing.Point(49, 57);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 22);
            this.label9.TabIndex = 2;
            this.label9.Text = "Ad :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(65, 10);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(132, 30);
            this.label16.TabIndex = 1;
            this.label16.Text = "BİLGİLER";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btn_GiveUp
            // 
            this.btn_GiveUp.BackColor = System.Drawing.Color.DimGray;
            this.btn_GiveUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_GiveUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_GiveUp.ForeColor = System.Drawing.Color.White;
            this.btn_GiveUp.Location = new System.Drawing.Point(129, 149);
            this.btn_GiveUp.Name = "btn_GiveUp";
            this.btn_GiveUp.Size = new System.Drawing.Size(116, 32);
            this.btn_GiveUp.TabIndex = 85;
            this.btn_GiveUp.Text = "VER";
            this.btn_GiveUp.UseVisualStyleBackColor = false;
            this.btn_GiveUp.Click += new System.EventHandler(this.btn_GiveUp_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.btn_GiveUp);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.dTP_DeliverBook);
            this.panel3.Controls.Add(this.cBox_DeliverBook);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(784, 315);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(329, 202);
            this.panel3.TabIndex = 95;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(30, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 22);
            this.label3.TabIndex = 14;
            this.label3.Text = "Teslim Tarihi :";
            // 
            // dTP_DeliverBook
            // 
            this.dTP_DeliverBook.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dTP_DeliverBook.Location = new System.Drawing.Point(179, 117);
            this.dTP_DeliverBook.Name = "dTP_DeliverBook";
            this.dTP_DeliverBook.Size = new System.Drawing.Size(131, 22);
            this.dTP_DeliverBook.TabIndex = 13;
            // 
            // cBox_DeliverBook
            // 
            this.cBox_DeliverBook.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_DeliverBook.FormattingEnabled = true;
            this.cBox_DeliverBook.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cBox_DeliverBook.Location = new System.Drawing.Point(179, 72);
            this.cBox_DeliverBook.Name = "cBox_DeliverBook";
            this.cBox_DeliverBook.Size = new System.Drawing.Size(131, 24);
            this.cBox_DeliverBook.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(7, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(149, 22);
            this.label4.TabIndex = 4;
            this.label4.Text = "Teslim Edilecek :";
            // 
            // lbl_Punishment
            // 
            this.lbl_Punishment.AutoSize = true;
            this.lbl_Punishment.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_Punishment.ForeColor = System.Drawing.Color.White;
            this.lbl_Punishment.Location = new System.Drawing.Point(5, 56);
            this.lbl_Punishment.Name = "lbl_Punishment";
            this.lbl_Punishment.Size = new System.Drawing.Size(152, 22);
            this.lbl_Punishment.TabIndex = 3;
            this.lbl_Punishment.Text = "Ödenecek Tutar :";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btn_PayPunishment);
            this.panel2.Controls.Add(this.lbl_Punishment);
            this.panel2.Controls.Add(this.txt_Punishment);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Location = new System.Drawing.Point(12, 408);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(298, 140);
            this.panel2.TabIndex = 93;
            // 
            // btn_PayPunishment
            // 
            this.btn_PayPunishment.BackColor = System.Drawing.Color.DimGray;
            this.btn_PayPunishment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_PayPunishment.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_PayPunishment.ForeColor = System.Drawing.Color.White;
            this.btn_PayPunishment.Location = new System.Drawing.Point(60, 93);
            this.btn_PayPunishment.Name = "btn_PayPunishment";
            this.btn_PayPunishment.Size = new System.Drawing.Size(142, 32);
            this.btn_PayPunishment.TabIndex = 87;
            this.btn_PayPunishment.Text = "ÖDE";
            this.btn_PayPunishment.UseVisualStyleBackColor = false;
            this.btn_PayPunishment.Click += new System.EventHandler(this.btn_PayPunishment_Click);
            // 
            // txt_Punishment
            // 
            this.txt_Punishment.Location = new System.Drawing.Point(185, 54);
            this.txt_Punishment.Name = "txt_Punishment";
            this.txt_Punishment.Size = new System.Drawing.Size(100, 22);
            this.txt_Punishment.TabIndex = 2;
            this.txt_Punishment.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Punishment_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(16, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(241, 25);
            this.label7.TabIndex = 1;
            this.label7.Text = "CEZA ÖDEME İŞLEMİ";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.dgv_BookPDList);
            this.panel5.Controls.Add(this.lblListe);
            this.panel5.Location = new System.Drawing.Point(311, 79);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(823, 211);
            this.panel5.TabIndex = 98;
            // 
            // dgv_BookPDList
            // 
            this.dgv_BookPDList.AllowUserToAddRows = false;
            this.dgv_BookPDList.AllowUserToDeleteRows = false;
            this.dgv_BookPDList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_BookPDList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_BookPDList.BackgroundColor = System.Drawing.Color.White;
            this.dgv_BookPDList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_BookPDList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgv_BookPDList.Location = new System.Drawing.Point(18, 43);
            this.dgv_BookPDList.Name = "dgv_BookPDList";
            this.dgv_BookPDList.ReadOnly = true;
            this.dgv_BookPDList.RowHeadersWidth = 51;
            this.dgv_BookPDList.RowTemplate.Height = 24;
            this.dgv_BookPDList.Size = new System.Drawing.Size(784, 151);
            this.dgv_BookPDList.TabIndex = 2;
            // 
            // lblListe
            // 
            this.lblListe.AutoSize = true;
            this.lblListe.BackColor = System.Drawing.Color.Transparent;
            this.lblListe.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblListe.ForeColor = System.Drawing.Color.White;
            this.lblListe.Location = new System.Drawing.Point(267, 11);
            this.lblListe.Name = "lblListe";
            this.lblListe.Size = new System.Drawing.Size(297, 29);
            this.lblListe.TabIndex = 1;
            this.lblListe.Text = "ALDIĞIN KİTAP LİSTESİ";
            // 
            // pBox_Exit
            // 
            this.pBox_Exit.BackColor = System.Drawing.Color.Transparent;
            this.pBox_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pBox_Exit.Image = ((System.Drawing.Image)(resources.GetObject("pBox_Exit.Image")));
            this.pBox_Exit.Location = new System.Drawing.Point(1090, 12);
            this.pBox_Exit.Name = "pBox_Exit";
            this.pBox_Exit.Size = new System.Drawing.Size(44, 34);
            this.pBox_Exit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_Exit.TabIndex = 92;
            this.pBox_Exit.TabStop = false;
            this.pBox_Exit.Click += new System.EventHandler(this.pBox_Exit_Click);
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.Transparent;
            this.btn_Back.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Back.BackgroundImage")));
            this.btn_Back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_Back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Back.ForeColor = System.Drawing.Color.DimGray;
            this.btn_Back.ImageKey = "reply.png";
            this.btn_Back.Location = new System.Drawing.Point(12, 12);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(70, 34);
            this.btn_Back.TabIndex = 91;
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // StudentInfoPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1146, 652);
            this.Controls.Add(this.lbl_Unsuccess);
            this.Controls.Add(this.lbl_Success);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.lbl_Student);
            this.Controls.Add(this.lbl_StudentInfo);
            this.Controls.Add(this.lbl_IDStudentInfo);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.pBox_Exit);
            this.Controls.Add(this.btn_Back);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "StudentInfoPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StudentInfoPanel";
            this.Load += new System.EventHandler(this.StudentInfoPanel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pBox_FindBook)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_BookGraphics)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_BookPDList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Exit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cBox_PurchaseBook;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbl_Unsuccess;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pBox_FindBook;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lbl_Success;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_PickUp;
        private System.Windows.Forms.DateTimePicker dTP_PurchaseBook;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pBox_BookGraphics;
        private System.Windows.Forms.Label lbl_Student;
        private System.Windows.Forms.Label lbl_StudentInfo;
        public System.Windows.Forms.Label lbl_IDStudentInfo;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbl_InfoSusp;
        private System.Windows.Forms.Label lbl_InfoSex;
        private System.Windows.Forms.Label lbl_InfoPass;
        private System.Windows.Forms.Label lbl_InfoStudentNu;
        private System.Windows.Forms.Label lbl_InfoLastN;
        private System.Windows.Forms.Label lbl_InfoName;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btn_GiveUp;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dTP_DeliverBook;
        private System.Windows.Forms.ComboBox cBox_DeliverBook;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_Punishment;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_PayPunishment;
        private System.Windows.Forms.TextBox txt_Punishment;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dgv_BookPDList;
        private System.Windows.Forms.Label lblListe;
        private System.Windows.Forms.PictureBox pBox_Exit;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Timer timer2;
    }
}
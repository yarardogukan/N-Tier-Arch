﻿
namespace KutuphaneYonetimOtomasyonu
{
    partial class SearchBookPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchBookPanel));
            this.lbl_StudentInfo = new System.Windows.Forms.Label();
            this.btn_Find = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lbl_BSStudentID = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.dgv_IDBookList = new System.Windows.Forms.DataGridView();
            this.lblSifre = new System.Windows.Forms.Label();
            this.lblNo = new System.Windows.Forms.Label();
            this.lblSoyad = new System.Windows.Forms.Label();
            this.lblAd = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dgv_BookDPDateList = new System.Windows.Forms.DataGridView();
            this.lbl_InfoBookAuthor = new System.Windows.Forms.Label();
            this.lbl_InfoBookPage = new System.Windows.Forms.Label();
            this.lbl_InfoBookType = new System.Windows.Forms.Label();
            this.lbl_KitapIdReq = new System.Windows.Forms.Label();
            this.txt_BookID = new System.Windows.Forms.TextBox();
            this.pBox_Exit = new System.Windows.Forms.PictureBox();
            this.btn_Back = new System.Windows.Forms.Button();
            this.lbl_InfoBookName = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_IDBookList)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_BookDPDateList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Exit)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_StudentInfo
            // 
            this.lbl_StudentInfo.AutoSize = true;
            this.lbl_StudentInfo.BackColor = System.Drawing.Color.Transparent;
            this.lbl_StudentInfo.Font = new System.Drawing.Font("Times New Roman", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_StudentInfo.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbl_StudentInfo.Location = new System.Drawing.Point(11, 615);
            this.lbl_StudentInfo.Name = "lbl_StudentInfo";
            this.lbl_StudentInfo.Size = new System.Drawing.Size(191, 17);
            this.lbl_StudentInfo.TabIndex = 102;
            this.lbl_StudentInfo.Text = "| Doğukan Yarar - 182119003 | ";
            // 
            // btn_Find
            // 
            this.btn_Find.BackColor = System.Drawing.Color.DimGray;
            this.btn_Find.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Find.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Find.ForeColor = System.Drawing.Color.White;
            this.btn_Find.Location = new System.Drawing.Point(275, 98);
            this.btn_Find.Name = "btn_Find";
            this.btn_Find.Size = new System.Drawing.Size(75, 32);
            this.btn_Find.TabIndex = 101;
            this.btn_Find.Text = "ARA";
            this.btn_Find.UseVisualStyleBackColor = false;
            this.btn_Find.Click += new System.EventHandler(this.btn_Find_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label14.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label14.Location = new System.Drawing.Point(422, 13);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(254, 32);
            this.label14.TabIndex = 100;
            this.label14.Text = "Kitap Arama Sayfası";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lbl_BSStudentID
            // 
            this.lbl_BSStudentID.AutoSize = true;
            this.lbl_BSStudentID.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbl_BSStudentID.Location = new System.Drawing.Point(1044, 625);
            this.lbl_BSStudentID.Name = "lbl_BSStudentID";
            this.lbl_BSStudentID.Size = new System.Drawing.Size(92, 17);
            this.lbl_BSStudentID.TabIndex = 99;
            this.lbl_BSStudentID.Text = "lbl_StudentID";
            this.lbl_BSStudentID.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(595, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(276, 39);
            this.label2.TabIndex = 98;
            this.label2.Text = "Kitap Detaylı Bilgi";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.dgv_IDBookList);
            this.panel1.Location = new System.Drawing.Point(14, 150);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(349, 391);
            this.panel1.TabIndex = 96;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(96, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(173, 30);
            this.label7.TabIndex = 46;
            this.label7.Text = "ISBN LİSTESİ";
            // 
            // dgv_IDBookList
            // 
            this.dgv_IDBookList.AllowUserToAddRows = false;
            this.dgv_IDBookList.AllowUserToDeleteRows = false;
            this.dgv_IDBookList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_IDBookList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_IDBookList.BackgroundColor = System.Drawing.Color.White;
            this.dgv_IDBookList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_IDBookList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgv_IDBookList.Location = new System.Drawing.Point(18, 42);
            this.dgv_IDBookList.Name = "dgv_IDBookList";
            this.dgv_IDBookList.ReadOnly = true;
            this.dgv_IDBookList.RowHeadersWidth = 51;
            this.dgv_IDBookList.RowTemplate.Height = 24;
            this.dgv_IDBookList.Size = new System.Drawing.Size(312, 333);
            this.dgv_IDBookList.TabIndex = 45;
            // 
            // lblSifre
            // 
            this.lblSifre.AutoSize = true;
            this.lblSifre.BackColor = System.Drawing.Color.Transparent;
            this.lblSifre.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.lblSifre.ForeColor = System.Drawing.Color.White;
            this.lblSifre.Location = new System.Drawing.Point(826, 235);
            this.lblSifre.Name = "lblSifre";
            this.lblSifre.Size = new System.Drawing.Size(84, 25);
            this.lblSifre.TabIndex = 95;
            this.lblSifre.Text = "Yazar : ";
            // 
            // lblNo
            // 
            this.lblNo.AutoSize = true;
            this.lblNo.BackColor = System.Drawing.Color.Transparent;
            this.lblNo.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.lblNo.ForeColor = System.Drawing.Color.White;
            this.lblNo.Location = new System.Drawing.Point(436, 234);
            this.lblNo.Name = "lblNo";
            this.lblNo.Size = new System.Drawing.Size(142, 25);
            this.lblNo.TabIndex = 94;
            this.lblNo.Text = "Sayfa Sayısı : ";
            // 
            // lblSoyad
            // 
            this.lblSoyad.AutoSize = true;
            this.lblSoyad.BackColor = System.Drawing.Color.Transparent;
            this.lblSoyad.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.lblSoyad.ForeColor = System.Drawing.Color.White;
            this.lblSoyad.Location = new System.Drawing.Point(826, 177);
            this.lblSoyad.Name = "lblSoyad";
            this.lblSoyad.Size = new System.Drawing.Size(79, 25);
            this.lblSoyad.TabIndex = 93;
            this.lblSoyad.Text = "Türü : ";
            // 
            // lblAd
            // 
            this.lblAd.AutoSize = true;
            this.lblAd.BackColor = System.Drawing.Color.Transparent;
            this.lblAd.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.lblAd.ForeColor = System.Drawing.Color.White;
            this.lblAd.Location = new System.Drawing.Point(436, 177);
            this.lblAd.Name = "lblAd";
            this.lblAd.Size = new System.Drawing.Size(123, 25);
            this.lblAd.TabIndex = 92;
            this.lblAd.Text = "Kitap Adı : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(251, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(295, 25);
            this.label1.TabIndex = 59;
            this.label1.Text = "KİTABI ALANLARIN LİSTESİ";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.dgv_BookDPDateList);
            this.panel2.Location = new System.Drawing.Point(373, 305);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(763, 265);
            this.panel2.TabIndex = 97;
            // 
            // dgv_BookDPDateList
            // 
            this.dgv_BookDPDateList.AllowUserToAddRows = false;
            this.dgv_BookDPDateList.AllowUserToDeleteRows = false;
            this.dgv_BookDPDateList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_BookDPDateList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_BookDPDateList.BackgroundColor = System.Drawing.Color.White;
            this.dgv_BookDPDateList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_BookDPDateList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgv_BookDPDateList.Location = new System.Drawing.Point(20, 37);
            this.dgv_BookDPDateList.Name = "dgv_BookDPDateList";
            this.dgv_BookDPDateList.ReadOnly = true;
            this.dgv_BookDPDateList.RowHeadersWidth = 51;
            this.dgv_BookDPDateList.RowTemplate.Height = 24;
            this.dgv_BookDPDateList.Size = new System.Drawing.Size(726, 212);
            this.dgv_BookDPDateList.TabIndex = 58;
            // 
            // lbl_InfoBookAuthor
            // 
            this.lbl_InfoBookAuthor.AutoSize = true;
            this.lbl_InfoBookAuthor.BackColor = System.Drawing.Color.Transparent;
            this.lbl_InfoBookAuthor.Font = new System.Drawing.Font("Times New Roman", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbl_InfoBookAuthor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl_InfoBookAuthor.Location = new System.Drawing.Point(923, 239);
            this.lbl_InfoBookAuthor.Name = "lbl_InfoBookAuthor";
            this.lbl_InfoBookAuthor.Size = new System.Drawing.Size(45, 20);
            this.lbl_InfoBookAuthor.TabIndex = 91;
            this.lbl_InfoBookAuthor.Text = "------";
            // 
            // lbl_InfoBookPage
            // 
            this.lbl_InfoBookPage.AutoSize = true;
            this.lbl_InfoBookPage.BackColor = System.Drawing.Color.Transparent;
            this.lbl_InfoBookPage.Font = new System.Drawing.Font("Times New Roman", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbl_InfoBookPage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl_InfoBookPage.Location = new System.Drawing.Point(592, 239);
            this.lbl_InfoBookPage.Name = "lbl_InfoBookPage";
            this.lbl_InfoBookPage.Size = new System.Drawing.Size(45, 20);
            this.lbl_InfoBookPage.TabIndex = 90;
            this.lbl_InfoBookPage.Text = "------";
            // 
            // lbl_InfoBookType
            // 
            this.lbl_InfoBookType.AutoSize = true;
            this.lbl_InfoBookType.BackColor = System.Drawing.Color.Transparent;
            this.lbl_InfoBookType.Font = new System.Drawing.Font("Times New Roman", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbl_InfoBookType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl_InfoBookType.Location = new System.Drawing.Point(923, 182);
            this.lbl_InfoBookType.Name = "lbl_InfoBookType";
            this.lbl_InfoBookType.Size = new System.Drawing.Size(45, 20);
            this.lbl_InfoBookType.TabIndex = 89;
            this.lbl_InfoBookType.Text = "------";
            // 
            // lbl_KitapIdReq
            // 
            this.lbl_KitapIdReq.AutoSize = true;
            this.lbl_KitapIdReq.BackColor = System.Drawing.Color.Transparent;
            this.lbl_KitapIdReq.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.lbl_KitapIdReq.ForeColor = System.Drawing.Color.White;
            this.lbl_KitapIdReq.Location = new System.Drawing.Point(27, 105);
            this.lbl_KitapIdReq.Name = "lbl_KitapIdReq";
            this.lbl_KitapIdReq.Size = new System.Drawing.Size(64, 25);
            this.lbl_KitapIdReq.TabIndex = 87;
            this.lbl_KitapIdReq.Text = "ISBN";
            // 
            // txt_BookID
            // 
            this.txt_BookID.Location = new System.Drawing.Point(129, 103);
            this.txt_BookID.Name = "txt_BookID";
            this.txt_BookID.Size = new System.Drawing.Size(122, 22);
            this.txt_BookID.TabIndex = 86;
            this.txt_BookID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_BookID_KeyPress);
            // 
            // pBox_Exit
            // 
            this.pBox_Exit.BackColor = System.Drawing.Color.Transparent;
            this.pBox_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pBox_Exit.Image = ((System.Drawing.Image)(resources.GetObject("pBox_Exit.Image")));
            this.pBox_Exit.Location = new System.Drawing.Point(1092, 11);
            this.pBox_Exit.Name = "pBox_Exit";
            this.pBox_Exit.Size = new System.Drawing.Size(44, 34);
            this.pBox_Exit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_Exit.TabIndex = 85;
            this.pBox_Exit.TabStop = false;
            this.pBox_Exit.Click += new System.EventHandler(this.pBox_Exit_Click);
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.Transparent;
            this.btn_Back.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Back.BackgroundImage")));
            this.btn_Back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_Back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Back.ForeColor = System.Drawing.Color.DimGray;
            this.btn_Back.ImageKey = "reply.png";
            this.btn_Back.Location = new System.Drawing.Point(14, 11);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(70, 34);
            this.btn_Back.TabIndex = 84;
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // lbl_InfoBookName
            // 
            this.lbl_InfoBookName.AutoSize = true;
            this.lbl_InfoBookName.BackColor = System.Drawing.Color.Transparent;
            this.lbl_InfoBookName.Font = new System.Drawing.Font("Times New Roman", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lbl_InfoBookName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl_InfoBookName.Location = new System.Drawing.Point(582, 182);
            this.lbl_InfoBookName.Name = "lbl_InfoBookName";
            this.lbl_InfoBookName.Size = new System.Drawing.Size(45, 20);
            this.lbl_InfoBookName.TabIndex = 88;
            this.lbl_InfoBookName.Text = "------";
            // 
            // SearchBookPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1146, 652);
            this.Controls.Add(this.lbl_StudentInfo);
            this.Controls.Add(this.btn_Find);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lbl_BSStudentID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblSifre);
            this.Controls.Add(this.lblNo);
            this.Controls.Add(this.lblSoyad);
            this.Controls.Add(this.lblAd);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.lbl_InfoBookAuthor);
            this.Controls.Add(this.lbl_InfoBookPage);
            this.Controls.Add(this.lbl_InfoBookType);
            this.Controls.Add(this.lbl_KitapIdReq);
            this.Controls.Add(this.txt_BookID);
            this.Controls.Add(this.pBox_Exit);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.lbl_InfoBookName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SearchBookPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SearchBookPanel";
            this.Load += new System.EventHandler(this.SearchBookPanel_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_IDBookList)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_BookDPDateList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Exit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_StudentInfo;
        private System.Windows.Forms.Button btn_Find;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Timer timer1;
        public System.Windows.Forms.Label lbl_BSStudentID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dgv_IDBookList;
        private System.Windows.Forms.Label lblSifre;
        private System.Windows.Forms.Label lblNo;
        private System.Windows.Forms.Label lblSoyad;
        private System.Windows.Forms.Label lblAd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dgv_BookDPDateList;
        private System.Windows.Forms.Label lbl_InfoBookAuthor;
        private System.Windows.Forms.Label lbl_InfoBookPage;
        private System.Windows.Forms.Label lbl_InfoBookType;
        private System.Windows.Forms.Label lbl_KitapIdReq;
        private System.Windows.Forms.TextBox txt_BookID;
        private System.Windows.Forms.PictureBox pBox_Exit;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Label lbl_InfoBookName;
    }
}
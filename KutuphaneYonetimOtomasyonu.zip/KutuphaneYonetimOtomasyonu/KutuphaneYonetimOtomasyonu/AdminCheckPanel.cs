﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KutuphaneYonetimOtomasyonu
{
    public partial class AdminCheckPanel : Form
    {
        public AdminCheckPanel()
        {
            InitializeComponent();
        }

        private void AdminCheckPanel_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true; // label'da kayan yazı oluşturmak için timer'ı başlattık.

            ToolTip aciklama = new ToolTip();   // Nesnenin üzerine geldiğinde bir konuşma balonu tarzında kullanıcıya, bu işlemin ne yaptığına dair bilgi veren ToolTip nesnesini oluşturuyoruz.
            aciklama.IsBalloon = true;      // Konuşma balonu tarzında daha şık görünmesini sağlıyoruz.
            aciklama.ToolTipIcon = ToolTipIcon.Info;    // Balondaki, ikonu seçiyoruz.
            aciklama.ToolTipTitle = "Dikkat!";  // Balonun, ana başlığını belirliyoruz.
            aciklama.SetToolTip(lbl_Book, "Kitap işlemlerinin olduğu kısımdır. Görsele ya da butona tıklayınız."); // Üzerine gelindiğinde verilecek mesajı yazıyoruz.
            aciklama.SetToolTip(lbl_Student, "Öğrenci işlemlerinin olduğu kısımdır. Görsele ya da butona tıklayınız."); // Üzerine gelindiğinde verilecek mesajı yazıyoruz.
        }

        private void btn_AdminBookProcess_Click(object sender, EventArgs e)
        {
            BookProcessPanel bP = new BookProcessPanel();             // Gidilecek forma geçmek için bir değişken (bP) oluşturduk.
            this.Hide();                                    // AdminCheckPanel sayfasının kapatılmasını sağladık.
            bP.Show();                                      // Oluşturulan değişken formuna gidilmesini sağladık.
        }

        private void pBox_Student_Click(object sender, EventArgs e)
        {
            StudentProcessPanel sP = new StudentProcessPanel();       // Gidilecek forma geçmek için bir değişken (sP) oluşturduk.
            this.Hide();                                    // AdminCheckPanel sayfasının kapatılmasını sağladık.
            sP.Show();                                      // Oluşturulan değişken formuna gidilmesini sağladık.
        }

        private void btn_AdminStudentProcess_Click(object sender, EventArgs e)
        {
            StudentProcessPanel sP = new StudentProcessPanel();       // Gidilecek forma geçmek için bir değişken (sP) oluşturduk.
            this.Hide();                                    // AdminCheckPanel sayfasının kapatılmasını sağladık.
            sP.Show();                                      // Oluşturulan değişken formuna gidilmesini sağladık.
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            DialogResult dialog = new DialogResult();   // Kullanıcı uygulamadan çıkmadan önce bir "Evet-Hayır" dialog nesnesiyle karşılaşacaktır.
            dialog = MessageBox.Show("Gerçekten çıkmak istiyor musunuz?", "ÇIKIŞ", MessageBoxButtons.YesNo, MessageBoxIcon.Warning); // MsgBox.Show metodunu dialog nesnesiyle birlikte kullandık.
            if (dialog == DialogResult.Yes) // Eğer sonuç evet ise uygulamadan çıkmasını sağladık
            {
                Application.Exit();
            }
            else    // Eğer cevap hayır ise kulanıcının proje de devam etmesini sağladık.
            {
                return;
            }
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            Home h = new Home();                                // Gidilecek forma geçmek için bir değişken (h) oluşturduk.
            this.Hide();                                        // AdminCheckPanel sayfasının kapatılmasını sağladık.
            h.Show();                                           // Oluşturulan değişken formuna gidilmesini sağladık.
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_StudentInfo.Text = lbl_StudentInfo.Text.Substring(1) + lbl_StudentInfo.Text.Substring(0, 1); // Substring metodu ile label'a yazdığımız değerin timer ile döndürüyoruz.
        }

        private void pBox_Book_Click(object sender, EventArgs e)
        {
            BookProcessPanel bP = new BookProcessPanel();             // Gidilecek forma geçmek için bir değişken (bP) oluşturduk.
            this.Hide();                                             // AdminCheckPanel sayfasının kapatılmasını sağladık.
            bP.Show();                                              // Oluşturulan değişken formuna gidilmesini sağladık.
        }
    }
}

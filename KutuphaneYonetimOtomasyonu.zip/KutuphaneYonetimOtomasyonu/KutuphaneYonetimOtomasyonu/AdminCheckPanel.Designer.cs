﻿
namespace KutuphaneYonetimOtomasyonu
{
    partial class AdminCheckPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminCheckPanel));
            this.btn_Exit = new System.Windows.Forms.PictureBox();
            this.btn_Back = new System.Windows.Forms.Button();
            this.pBox_Book = new System.Windows.Forms.PictureBox();
            this.lbl_Book = new System.Windows.Forms.Label();
            this.pBox_Student = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_AdminBookProcess = new System.Windows.Forms.Button();
            this.lblOgrenci = new System.Windows.Forms.Label();
            this.btn_AdminStudentProcess = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_Student = new System.Windows.Forms.Label();
            this.lbl_StudentInfo = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.btn_Exit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Book)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Student)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Exit
            // 
            this.btn_Exit.BackColor = System.Drawing.Color.Transparent;
            this.btn_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Exit.Image = ((System.Drawing.Image)(resources.GetObject("btn_Exit.Image")));
            this.btn_Exit.Location = new System.Drawing.Point(683, 12);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(44, 34);
            this.btn_Exit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btn_Exit.TabIndex = 42;
            this.btn_Exit.TabStop = false;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.Transparent;
            this.btn_Back.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Back.BackgroundImage")));
            this.btn_Back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_Back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Back.ForeColor = System.Drawing.Color.DimGray;
            this.btn_Back.ImageKey = "reply.png";
            this.btn_Back.Location = new System.Drawing.Point(12, 12);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(70, 34);
            this.btn_Back.TabIndex = 41;
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // pBox_Book
            // 
            this.pBox_Book.BackColor = System.Drawing.Color.Transparent;
            this.pBox_Book.Image = ((System.Drawing.Image)(resources.GetObject("pBox_Book.Image")));
            this.pBox_Book.Location = new System.Drawing.Point(15, 10);
            this.pBox_Book.Name = "pBox_Book";
            this.pBox_Book.Size = new System.Drawing.Size(128, 128);
            this.pBox_Book.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Book.TabIndex = 28;
            this.pBox_Book.TabStop = false;
            this.pBox_Book.Click += new System.EventHandler(this.pBox_Book_Click);
            // 
            // lbl_Book
            // 
            this.lbl_Book.AutoSize = true;
            this.lbl_Book.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Book.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_Book.ForeColor = System.Drawing.Color.White;
            this.lbl_Book.Location = new System.Drawing.Point(198, 10);
            this.lbl_Book.Name = "lbl_Book";
            this.lbl_Book.Size = new System.Drawing.Size(73, 29);
            this.lbl_Book.TabIndex = 29;
            this.lbl_Book.Text = "Kitap";
            // 
            // pBox_Student
            // 
            this.pBox_Student.BackColor = System.Drawing.Color.Transparent;
            this.pBox_Student.Image = ((System.Drawing.Image)(resources.GetObject("pBox_Student.Image")));
            this.pBox_Student.Location = new System.Drawing.Point(14, 10);
            this.pBox_Student.Name = "pBox_Student";
            this.pBox_Student.Size = new System.Drawing.Size(128, 128);
            this.pBox_Student.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Student.TabIndex = 27;
            this.pBox_Student.TabStop = false;
            this.pBox_Student.Click += new System.EventHandler(this.pBox_Student_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.btn_AdminBookProcess);
            this.panel1.Controls.Add(this.pBox_Book);
            this.panel1.Controls.Add(this.lbl_Book);
            this.panel1.Location = new System.Drawing.Point(13, 77);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(312, 157);
            this.panel1.TabIndex = 44;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(183, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 29);
            this.label3.TabIndex = 31;
            this.label3.Text = "İşlemleri";
            // 
            // btn_AdminBookProcess
            // 
            this.btn_AdminBookProcess.BackColor = System.Drawing.Color.DimGray;
            this.btn_AdminBookProcess.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_AdminBookProcess.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_AdminBookProcess.ForeColor = System.Drawing.Color.White;
            this.btn_AdminBookProcess.Location = new System.Drawing.Point(196, 92);
            this.btn_AdminBookProcess.Name = "btn_AdminBookProcess";
            this.btn_AdminBookProcess.Size = new System.Drawing.Size(75, 32);
            this.btn_AdminBookProcess.TabIndex = 30;
            this.btn_AdminBookProcess.Text = "Giriş";
            this.btn_AdminBookProcess.UseVisualStyleBackColor = false;
            this.btn_AdminBookProcess.Click += new System.EventHandler(this.btn_AdminBookProcess_Click);
            // 
            // lblOgrenci
            // 
            this.lblOgrenci.AutoSize = true;
            this.lblOgrenci.BackColor = System.Drawing.Color.Transparent;
            this.lblOgrenci.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lblOgrenci.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.lblOgrenci.Location = new System.Drawing.Point(272, 14);
            this.lblOgrenci.Name = "lblOgrenci";
            this.lblOgrenci.Size = new System.Drawing.Size(233, 32);
            this.lblOgrenci.TabIndex = 43;
            this.lblOgrenci.Text = "Görevli Anasayfası";
            // 
            // btn_AdminStudentProcess
            // 
            this.btn_AdminStudentProcess.BackColor = System.Drawing.Color.DimGray;
            this.btn_AdminStudentProcess.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_AdminStudentProcess.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_AdminStudentProcess.ForeColor = System.Drawing.Color.White;
            this.btn_AdminStudentProcess.Location = new System.Drawing.Point(195, 92);
            this.btn_AdminStudentProcess.Name = "btn_AdminStudentProcess";
            this.btn_AdminStudentProcess.Size = new System.Drawing.Size(75, 32);
            this.btn_AdminStudentProcess.TabIndex = 31;
            this.btn_AdminStudentProcess.Text = "Giriş";
            this.btn_AdminStudentProcess.UseVisualStyleBackColor = false;
            this.btn_AdminStudentProcess.Click += new System.EventHandler(this.btn_AdminStudentProcess_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.lbl_Student);
            this.panel2.Controls.Add(this.btn_AdminStudentProcess);
            this.panel2.Controls.Add(this.pBox_Student);
            this.panel2.Location = new System.Drawing.Point(371, 77);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(312, 157);
            this.panel2.TabIndex = 45;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(181, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 29);
            this.label4.TabIndex = 33;
            this.label4.Text = "İşlemleri";
            // 
            // lbl_Student
            // 
            this.lbl_Student.AutoSize = true;
            this.lbl_Student.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Student.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_Student.ForeColor = System.Drawing.Color.White;
            this.lbl_Student.Location = new System.Drawing.Point(180, 10);
            this.lbl_Student.Name = "lbl_Student";
            this.lbl_Student.Size = new System.Drawing.Size(106, 29);
            this.lbl_Student.TabIndex = 32;
            this.lbl_Student.Text = "Öğrenci";
            // 
            // lbl_StudentInfo
            // 
            this.lbl_StudentInfo.AutoSize = true;
            this.lbl_StudentInfo.BackColor = System.Drawing.Color.Transparent;
            this.lbl_StudentInfo.Font = new System.Drawing.Font("Times New Roman", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_StudentInfo.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbl_StudentInfo.Location = new System.Drawing.Point(12, 274);
            this.lbl_StudentInfo.Name = "lbl_StudentInfo";
            this.lbl_StudentInfo.Size = new System.Drawing.Size(191, 17);
            this.lbl_StudentInfo.TabIndex = 46;
            this.lbl_StudentInfo.Text = "| Doğukan Yarar - 182119003 | ";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // AdminCheckPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(739, 312);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblOgrenci);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.lbl_StudentInfo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AdminCheckPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminCheckPanel";
            this.Load += new System.EventHandler(this.AdminCheckPanel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.btn_Exit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Book)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Student)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox btn_Exit;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.PictureBox pBox_Book;
        private System.Windows.Forms.Label lbl_Book;
        private System.Windows.Forms.PictureBox pBox_Student;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_AdminBookProcess;
        private System.Windows.Forms.Label lblOgrenci;
        private System.Windows.Forms.Button btn_AdminStudentProcess;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_Student;
        private System.Windows.Forms.Label lbl_StudentInfo;
        private System.Windows.Forms.Timer timer1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KutuphaneYonetimOtomasyonu
{
    public partial class Opening : Form
    {
        public Opening()
        {
            InitializeComponent();
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            DialogResult dialog = new DialogResult();   // Kullanıcı uygulamadan çıkmadan önce bir "Evet-Hayır" dialog nesnesiyle karşılaşacaktır.
            dialog = MessageBox.Show("Gerçekten çıkmak istiyor musunuz?", "ÇIKIŞ", MessageBoxButtons.YesNo, MessageBoxIcon.Warning); // MsgBox.Show metodunu dialog nesnesiyle birlikte kullandık.
            if (dialog == DialogResult.Yes) // Eğer sonuç evet ise uygulamadan çıkmasını sağladık
            {
                Application.Exit();
            }
            else    // Eğer cevap hayır ise kulanıcının proje de devam etmesini sağladık.
            {
                return;
            }
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            this.timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.progressBar1.Increment(1);
            lbl_Value.Text = "%" + progressBar1.Value.ToString();
            if (progressBar1.Value >= progressBar1.Maximum)
            {
                timer1.Stop();
                Home h = new Home();
                this.Hide();
                h.Show();
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            lbl_StudentInfo.Text = lbl_StudentInfo.Text.Substring(1) + lbl_StudentInfo.Text.Substring(0, 1); // Substring metodu ile label'a yazdığımız değerin timer ile döndürüyoruz.
        }

        private void Opening_Load(object sender, EventArgs e)
        {
            
        }
    }
}

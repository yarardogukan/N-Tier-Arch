﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BL;        // BL katmanını kullanacağımız için ekledik.
using ENTITY;   // Entity katmanını kullanacağımız için ekledik.

namespace KutuphaneYonetimOtomasyonu
{
    public partial class SearchBookPanel : Form
    {
        public SearchBookPanel()
        {
            InitializeComponent();
        }

        private void SearchBookPanel_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;  // Timer'ın Tick Eventinin çalışmasını sağladık.
            lbl_BSStudentID.Visible = false;    // Öğrenci ID'sini label a yazdırdık.
            dgv_IDBookList.DataSource = BookBL.bookList(); // Form açıldığında Datagrid üzerine veritabanındaki listeyi aktardık.
            
            //İstenmeyen bilgilerin tabloda görünümünü kapattık.
            dgv_IDBookList.Columns[2].Visible = false;
            dgv_IDBookList.Columns[3].Visible = false;
            dgv_IDBookList.Columns[4].Visible = false;
            dgv_IDBookList.Columns[0].HeaderText = "ISBN";  // Tablo adlarını değiştirdik.
            dgv_IDBookList.Columns[1].HeaderText = "Kitabın Adı";
        }

        private void btn_Find_Click(object sender, EventArgs e) // Ara butonuna basıldığında
        {
            if (txt_BookID.Text != "")  // Aranacak kitabın ISBN numarasının boş olmadığını kontrol ettik.
            {
                BookData book= new BookData()  // Book nesnesine veriyi aktardık.
                {
                    BookID = int.Parse(txt_BookID.Text)  // ID aktarıldı.
                };

                book = BookBL.bookIDInfo(book);  // Çekilen ID bilgisini veriye aktardık.
                lbl_InfoBookName.Text = book.BookName;
                lbl_InfoBookType.Text = book.BookType;
                lbl_InfoBookPage.Text = book.BookPage;
                lbl_InfoBookAuthor.Text = book.BookAuthor;

                BookStudentData bookStudent = new BookStudentData()  // BookStudent nesnesine veriyi aktardık.
                {
                    BookID = int.Parse(txt_BookID.Text)  // ID aktarıldı.
                };

                if (BookBL.queryBook_BL(book) != false)  // Kitabın mevcut olup olmadığı kontrol edildi.
                {
                    dgv_BookDPDateList.DataSource = ReturnBookBL.bookStudentList(bookStudent);  // Güncel liste, datagrid nesnesine aktarıldı.
                    
                    //Sütun başlıkları düzenlendi
                    dgv_BookDPDateList.Columns[0].HeaderText = "ISBN";
                    dgv_BookDPDateList.Columns[1].HeaderText = "Öğrencinin Adı";
                    dgv_BookDPDateList.Columns[2].HeaderText = "Öğrencinin Soyadı";
                    dgv_BookDPDateList.Columns[3].HeaderText = "Kitabın Adı";
                    dgv_BookDPDateList.Columns[4].HeaderText = "Alım Tarihi";
                    dgv_BookDPDateList.Columns[5].HeaderText = "Teslim Tarihi";
                    dgv_BookDPDateList.Columns[6].HeaderText = "Teslim Edilmiş mi?";
                }

                else
                    MessageBox.Show("Girilen ISBN numarasına ait bir kitap mevcut değildir!");  // Eğer kitap yok ise bu hata mesajını verdirttik.
            }

            else
                MessageBox.Show("Lütfen ISBN Numarasını giriniz!"); // Textbox boş olduğunda arama yapamayacağından hata verdirttik.
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_StudentInfo.Text = lbl_StudentInfo.Text.Substring(1) + lbl_StudentInfo.Text.Substring(0, 1); // Substring metodu ile label'a yazdığımız değerin timer ile döndürüyoruz.
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            StudentInfoPanel stI = new StudentInfoPanel();              // StudentInfoPanel formundan nesne üretildi.
            stI.lbl_IDStudentInfo.Text = lbl_BSStudentID.Text;          // Öğrencinin ID'sini kullanmak için ID'sini aktardık.
            this.Hide();                                                // Bulunduğumuz form ekranı kapatttık.
            stI.Show();                                                 // stI nesnesini kullanarak bir sonraki forma geçiş yapıldı.
        }

        private void pBox_Exit_Click(object sender, EventArgs e)
        {
            DialogResult dialog = new DialogResult();   // Kullanıcı uygulamadan çıkmadan önce bir "Evet-Hayır" dialog nesnesiyle karşılaşacaktır.
            dialog = MessageBox.Show("Gerçekten çıkmak istiyor musunuz?", "ÇIKIŞ", MessageBoxButtons.YesNo, MessageBoxIcon.Warning); // MsgBox.Show metodunu dialog nesnesiyle birlikte kullandık.
            if (dialog == DialogResult.Yes) // Eğer sonuç evet ise uygulamadan çıkmasını sağladık
            {
                Application.Exit();
            }
            else    // Eğer cevap hayır ise kulanıcının proje de devam etmesini sağladık.
            {
                return;
            }
        }

        private void txt_BookID_KeyPress(object sender, KeyPressEventArgs e)    // Harf girilmesi engellendi. Sadece sayı girişine izin verdik.
        {   
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}

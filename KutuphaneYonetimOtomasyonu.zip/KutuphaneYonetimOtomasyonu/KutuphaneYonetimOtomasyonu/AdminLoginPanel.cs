﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ENTITY;   // Entity katmanını kullanacağımız için ekledik.
using BL;      // BL katmanını kullanacağımız için ekledik.

namespace KutuphaneYonetimOtomasyonu
{

    public partial class AdminLoginPanel : Form
    {
        
        public AdminLoginPanel()
        {
            InitializeComponent();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            Home h = new Home();                                // Gidilecek forma geçmek için bir değişken (h) oluşturduk.
            this.Hide();                                        // AdminLogin sayfasının kapatılmasını sağladık.
            h.Show();                                           // Oluşturulan değişken formuna gidilmesini sağladık.
        }

        private void AdminLoginPanel_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true; // label'da kayan yazı oluşturmak için timer'ı başlattık.

            ToolTip aciklama = new ToolTip();
            aciklama.IsBalloon = true;
            aciklama.ToolTipIcon = ToolTipIcon.Info;
            aciklama.ToolTipTitle = "Dikkat!";
            aciklama.SetToolTip(txt_AdminIdeN, "Ör: 012345678910 | 11 hane kullandığınızdan emin olunuz!");
        }

        private void pBox_Cikis_Click(object sender, EventArgs e)
        {
            DialogResult dialog = new DialogResult();   // Kullanıcı uygulamadan çıkmadan önce bir "Evet-Hayır" dialog nesnesiyle karşılaşacaktır.
            dialog = MessageBox.Show("Gerçekten çıkmak istiyor musunuz?", "ÇIKIŞ", MessageBoxButtons.YesNo, MessageBoxIcon.Warning); // MsgBox.Show metodunu dialog nesnesiyle birlikte kullandık.
            if (dialog == DialogResult.Yes) // Eğer sonuç evet ise uygulamadan çıkmasını sağladık
            {
                Application.Exit();
            }
            else    // Eğer cevap hayır ise kulanıcının proje de devam etmesini sağladık.
            {
                return;
            }
        }

        private void btn_AdminLogin_Click(object sender, EventArgs e)
        {
            if (txt_AdminIdeN.Text.Length < 11)   // TC Kimlik Numarasının 11 haneden az olması durumunda hata verdirilmesini sağladık.
            {
                MessageBox.Show("T.C. Kimlik Numaranız 11 haneden az olamaz!");
            }

            else
            {
                if (txt_AdminIdeN.Text != "" && txt_AdminPass.Text != "")   // Metin kutularının boş olmadığını kontrol ettik.
                {
                    AdminData admin = new AdminData()                       // Textbox'lara girilen veriler, Entity katmanındaki değişkenlere atandı.
                    {
                        admIdeNu = txt_AdminIdeN.Text,
                        admPass = txt_AdminPass.Text
                    };

                    if (AdminBL.checkAdmin_BL(admin) == true)                 // Girilen değerler veritabanında var ise yeni admin paneline girişini sağladık.
                    {
                        AdminCheckPanel adminCP = new AdminCheckPanel();    // Gidilecek forma geçmek için bir değişken (adminCP) oluşturduk.
                        this.Hide();                                        // AdminLogin sayfasının kapatılmasını sağladık.
                        adminCP.Show();                                     // Oluşturulan değişken formuna gidilmesini sağladık.
                    }

                    else
                    {
                        MessageBox.Show("Verileriniz eşleşmemektedir. Sorun devam ederse lütfen destek alınız!"); // Veritabanında kayıt yok ise hata mesajı ver.
                    }

                }
                else    // Doldurulması gereken alanlar boş ise;
                {
                    lbl_Required.Visible = true;        // Uyarı label etiketini göster.
                    lbl_Required.Text = "T.C. Kimlik Numarası ya da şifre boş bırakılamaz!";
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_StudentInfo.Text = lbl_StudentInfo.Text.Substring(1) + lbl_StudentInfo.Text.Substring(0, 1); // Substring metodu ile label'a yazdığımız değerin timer ile döndürüyoruz.
        }

        private void cBox_Show_CheckedChanged(object sender, EventArgs e)
        {
            if (cBox_Show.CheckState == CheckState.Checked)           // Checkbox seçilmiş ise
            {
                txt_AdminPass.UseSystemPasswordChar = true;         // Şifreyi * olmadan yaz
                cBox_Show.Text = "Gizle";                           // Checkbox'un metnini Gizle olarak değiştir.
            }

            else if (cBox_Show.CheckState == CheckState.Unchecked)    // Checkbox seçili değil ise
            {
                txt_AdminPass.UseSystemPasswordChar = false;        // Şifreyi * olarak yaz.
                cBox_Show.Text = "Göster";                          // Checkbox'un metnini Göster olarak değiştir.
            }
        }

        private void txt_AdminIdeN_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))     // Harf girilmesi engellendi. Sadece sayı girişine izin verdik.
            {
                e.Handled = true;
            }
        }

        private void txt_AdminIdeN_TextChanged(object sender, EventArgs e)  // 11 haneden fazla girilmemesini sağladık.
        {
            txt_AdminIdeN.MaxLength = 11;
        }
    }
}
